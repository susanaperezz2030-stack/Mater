# Plan de mejora integral — Dental Master / Mater

## Objetivo

Mejorar de forma amplia el sitio público y el panel empresarial en diseño, accesibilidad, fiabilidad de los flujos de citas y CRM, seguridad de la experiencia administrativa, documentación y comprobaciones automatizadas. Los cambios se harán primero en una copia de trabajo del repositorio. No se publicarán, no se modificarán secretos ni datos D1 reales y no se harán migraciones de producción como parte de este plan.

## Enfoque de diseño

- **Movimiento:** clínica boutique contemporánea: sobria, cálida y editorial, con detalles de lujo discretos, no una plantilla SaaS genérica.
- **Principios:** jerarquía visual clara; navegación consistente entre portada y páginas interiores; legibilidad y contraste primero; interfaces táctiles cómodas y estados de carga/error honestos.
- **Color:** preservar la base cálida del tema actual (carbón, marfil y acento champán), usando tokens semánticos en lugar de colores cian heredados. Mantener los temas alternativos compatibles.
- **Composición:** portada con un hero de marca completo; páginas interiores con introducciones compactas, específicas de cada ruta, y contenido principal visible sin repetir el hero genérico.
- **Elementos distintivos:** tipografía editorial para titulares, acento lineal/champán para acciones y una navegación móvil compacta con objetivos táctiles consistentes.
- **Interacción y movimiento:** feedback visible al guardar, reservar, filtrar o cambiar de paso; animaciones breves y respetuosas con `prefers-reduced-motion`; foco y teclado funcionales en menús y diálogos.
- **Sistema tipográfico:** conservar las familias ya utilizadas; consolidar escala de tamaños, anchos de lectura, espaciado y estados de foco para escritorio y móvil.
- **Esencia de marca:** experiencia clara y cuidada para una clínica dental; personalidad confiable, serena y moderna. Voz concreta, amable y sin promesas clínicas no verificadas.

## Estructura del proyecto existente

- `index.html` y páginas raíz (`servicios.html`, `casos.html`, `equipo.html`, `financiacion.html`, `opiniones.html`, `preguntas.html`, `contacto.html`): sitio público multipágina.
- `style.css`, `navigation.css`, `multipage.css`, `ultimate.css` y `assets/themes/`: estilos base, navegación, rutas interiores, mejoras visuales y temas.
- `app.js`, `siteData.js` y `modules/`: lógica del sitio, datos visibles, almacenamiento, CRM, agenda, automatizaciones y panel.
- `functions/api/`: endpoints Cloudflare Pages, autorización, autenticación y acceso a D1.
- `db/` y `scripts/`: esquema, seeds, preparación de páginas y preflight de despliegue.
- `tests/` y `docs/`: pruebas y guías de operación/seguridad/despliegue.
- `dist/`: salida generada; se actualizará mediante el procedimiento de build del proyecto y no se tratará como una fuente independiente.

## Alcance de implementación

### A. Diseño, navegación, móvil y accesibilidad

- Eliminar la repetición del hero genérico en páginas interiores y dar a cada ruta un título y una introducción propios, conservando el hero de marca en la portada.
- Consolidar las reglas duplicadas de navegación y tamaños responsive; comprobar anchos móviles comunes y tabletas, elevar objetivos táctiles a un mínimo práctico de 44 × 44 px y reservar correctamente el espacio de las barras fijas.
- Corregir el patrón semántico de filtros (botones agrupados con `aria-pressed`, o patrón de pestañas completo si se justifica), etiquetar el filtro seleccionado y hacer sus estados accesibles.
- Mejorar el diálogo de cita: foco inicial, contención de Tab/Shift+Tab, cierre coherente con Escape, devolución del foco y anuncio accesible del paso actual.
- Añadir etiquetas accesibles específicas para enlaces de consulta por tratamiento y controles del comparador; revisar orden de encabezados, contraste, estados de foco y movimiento reducido.
- Evitar pantallas vacías si no carga JavaScript en las secciones principales, añadiendo fallbacks útiles o mensajes visibles para tratamientos, casos, reseñas y FAQ.

### B. Fiabilidad de citas, CRM y almacenamiento

- Distinguir explícitamente modo demo local de modo con API. No convertir respuestas HTTP fallidas (`400`, `401`, `403`, `409`, `5xx`) en lecturas/escrituras locales que aparenten éxito.
- Corregir el tratamiento de conflictos de horario para que un `409` no se presente como reserva confirmada; mostrar al usuario un mensaje accionable y conservar el formulario cuando sea posible.
- Hacer que las escrituras remotas conserven los datos del registro, confirmen éxito y actualicen de forma consistente la vista local; evitar sustituir objetos de cita por una respuesta `{ok:true}`.
- Permitir actualizar registros procedentes solo de D1 y normalizar nombres de campos de base de datos (`follow_up`, `created_at`) al modelo del cliente y de vuelta.
- Separar el alta pública de leads (estado inicial validado en servidor) de la edición autorizada del CRM; validar allowlist, longitudes y estados en altas/cambios.
- Definir y aplicar transiciones válidas de citas sin permitir reactivar accidentalmente citas canceladas o confirmar citas ya completadas; hacer que las fechas y la zona horaria sean coherentes y configurables/documentadas.
- Hacer que la interfaz de automatizaciones refleje con precisión las capacidades reales: no afirmar que se enviaron emails/SMS si solo se registró una simulación. Corregir marcas de tiempo/IDs de logs y dejar documentadas las integraciones que requieren proveedor y programación externa.
- Evitar guardar en `localStorage` las copias de datos personales cuando la API del servidor es la fuente activa; mantener el funcionamiento offline/demo claramente separado y conservar la autorización server-side como única barrera de seguridad.

### C. Panel de administración y seguridad

- Aclarar en el login que la cuenta se identifica por correo electrónico y mejorar mensajes para credenciales incorrectas, autenticación no configurada y API no disponible, sin revelar secretos.
- Alinear la visibilidad de pestañas y acciones con los roles admitidos por el middleware; esto mejora la experiencia pero no sustituye permisos en servidor.
- No presentar el alta/baja local de usuarios como si cambiara cuentas de producción: limitarla al modo demo, eliminar contraseñas prellenadas y mostrar el procedimiento real de cuentas configuradas en Cloudflare. Las cuentas de producción deben seguir almacenándose como hashes PBKDF2 en la configuración protegida.
- Asegurar que una sesión cliente antigua o manipulada no se interprete como autorización; el servidor debe continuar validando cookies firmadas y roles para cada recurso privado.
- Fortalecer validaciones del servidor y respuestas de error; documentar requisitos pendientes de protección contra fuerza bruta/MFA y protección anti-spam de formularios que dependen de configuración de Cloudflare o servicios externos.
- Revisar la CSP y otros encabezados: restringir orígenes innecesarios cuando sea compatible con el sitio, añadir protección de encuadre coherente y actualizar documentación para que no prometa directivas inexistentes. Mantener compatibilidad con scripts y estilos actuales, retirando inline/eval de forma gradual si la arquitectura lo requiere.
- Revisar y reemplazar datos seed que parezcan información real por ejemplos inequívocamente ficticios y neutros; no incluir datos de pacientes o notas clínicas reales en el bundle.

### D. Pruebas, documentación y entrega

- Añadir pruebas para errores API sin fallback exitoso, conflicto de cita `409`, persistencia correcta tras actualizaciones, normalización de campos, permisos por rol, estados de citas y controles accesibles del diálogo/filtros cuando la suite lo permita.
- Ejecutar las pruebas existentes y afectadas; distinguir validación local simulada de staging real con D1 y configuración de Cloudflare.
- Actualizar README y guías de seguridad/despliegue para describir correctamente demo local, límites de automatizaciones, cuentas administrativas, datos guardados y precondiciones de publicación.
- Regenerar `dist/` a partir de fuentes con el script del proyecto y comprobar coherencia de páginas/recursos generados.
- Entregar una copia comprimida actualizada y un resumen de cambios. No hacer `git push`, despliegue, cambios en Cloudflare, migraciones ni alteraciones de datos reales sin autorización explícita posterior.

## Límites importantes

- No usar ni incluir la contraseña corta escrita anteriormente en el chat. Para una cuenta real se necesitará una contraseña nueva, larga y única; el secreto se configura fuera del repositorio y no se compartirá por chat.
- No se habilitará el modo demo en producción ni se publicarán datos clínicos/sensibles.
- Las mejoras que requieran credenciales, secretos, integración Turnstile, proveedor de email/SMS, zona horaria real de la clínica o decisiones clínicas/legales se dejarán preparadas y documentadas, sin inventar valores ni simular que ya están activas.

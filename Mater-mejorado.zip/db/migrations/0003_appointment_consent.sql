-- Consentimiento registrado solo para solicitudes enviadas después de la aceptación explícita.
-- Los registros existentes conservan 0/NULL; no se infiere ni se reconstruye consentimiento anterior.
ALTER TABLE appointments ADD COLUMN consent_given INTEGER NOT NULL DEFAULT 0 CHECK(consent_given IN (0,1));
ALTER TABLE appointments ADD COLUMN consent_at TEXT;

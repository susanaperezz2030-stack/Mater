-- DENTAL MASTER ENTERPRISE — Cloudflare D1 (SQLite) schema
-- Apply with: wrangler d1 execute <DB_NAME> --file=db/schema.sql

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('administrator','manager','receptionist','marketing')),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS leads (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  treatment TEXT,
  source TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  notes TEXT,
  assignee TEXT,
  follow_up TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS lead_events (
  id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL,
  event TEXT NOT NULL,
  at TEXT DEFAULT (datetime('now')),
  data TEXT
);

CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY,
  service TEXT NOT NULL,
  specialist TEXT,
  location TEXT,
  date TEXT NOT NULL,
  slot TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  notes TEXT,
  consent_given INTEGER NOT NULL DEFAULT 0 CHECK(consent_given IN (0,1)),
  consent_at TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  cancel_reason TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_appt_date_slot ON appointments(date, slot, status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_appt_unique_active_slot
  ON appointments(date, slot, COALESCE(location, ''))
  WHERE status <> 'cancelled';

CREATE TABLE IF NOT EXISTS automations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  trigger TEXT NOT NULL,
  condition TEXT,
  action TEXT NOT NULL,
  action_detail TEXT,
  enabled INTEGER DEFAULT 1,
  last_run TEXT
);

CREATE TABLE IF NOT EXISTS automation_logs (
  id TEXT PRIMARY KEY,
  automation_id TEXT,
  automation_name TEXT,
  trigger TEXT,
  action TEXT,
  payload TEXT,
  at TEXT DEFAULT (datetime('now')),
  ok INTEGER DEFAULT 1,
  error TEXT
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS analytics_events (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  page TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  at TEXT DEFAULT (datetime('now')),
  data TEXT
);

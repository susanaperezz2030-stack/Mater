import assert from 'node:assert/strict';

const store = new Map();
globalThis.localStorage = {
  getItem: (key) => store.has(key) ? store.get(key) : null,
  setItem: (key, value) => store.set(key, String(value)),
  removeItem: (key) => store.delete(key),
};
const calls = [];
const failures = new Map();
const networkFailures = new Set();
globalThis.fetch = async (path, options = {}) => {
  const url = String(path); const method = options.method || 'GET';
  const body = options.body ? JSON.parse(options.body) : null;
  calls.push({ path: url, method, body });
  if (networkFailures.has(`${method} ${url}`)) throw new Error('simulated network failure');
  if (failures.has(`${method} ${url}`)) return failures.get(`${method} ${url}`);
  if (url === '/api/leads' && method === 'GET') return new Response(JSON.stringify([{ id: 'd1-lead', name: 'D1 Patient', phone: '+1 555 0100', status: 'new', follow_up: '2099-01-01', created_at: '2099-01-01T00:00:00Z' }]), { status: 200 });
  if (url === '/api/appointments' && method === 'GET') return new Response(JSON.stringify([{ id: 'd1-appt', name: 'D1 Patient', date: '2099-02-02', slot: 'Mañana (09:00–14:00)', status: 'pending' }]), { status: 200 });
  if (url === '/api/session' && method === 'GET') return new Response(JSON.stringify({ ok: true, session: { id: 'api-user', name: 'API User', role: 'manager' } }), { status: 200 });
  if (url === '/api/leads' && method === 'POST') return new Response(JSON.stringify({ id: 'saved-lead', ...body, createdAt: '2099-01-02T00:00:00Z' }), { status: 201 });
  if (url === '/api/intake/leads' && method === 'POST') return new Response(JSON.stringify({ id: 'public-lead', ...body, status: 'new', createdAt: '2099-01-02T00:00:00Z' }), { status: 201 });
  if (url === '/api/leads' && method === 'PUT') return new Response(JSON.stringify({ id: body.id, name: body.name || 'Persisted lead', phone: body.phone || '+1 555 0100', status: body.status || 'new', updatedAt: '2099-01-02T00:00:00Z' }), { status: 200 });
  if (url === '/api/leads' && method === 'DELETE') return new Response(JSON.stringify({ ok: true, lead: { id: body.id, name: 'Deleted persisted lead' } }), { status: 200 });
  if (url === '/api/appointments' && method === 'POST') return new Response(JSON.stringify({ id: 'saved-appt', ...body, status: 'pending', createdAt: '2099-01-02T00:00:00Z' }), { status: 201 });
  if (url === '/api/appointments' && method === 'PUT') return new Response(JSON.stringify({ id: body.id, service: body.service || 'veneers', name: body.name || 'Updated patient', phone: body.phone || '+1 555 0100', date: body.date || '2099-02-02', slot: body.slot || 'Mañana (09:00–14:00)', location: body.location || '', status: body.status || 'confirmed', cancelReason: body.cancelReason || '' }), { status: 200 });
  if (url === '/api/intake/appointments' && method === 'POST') return new Response(JSON.stringify({ id: 'public-appt', ...body, status: 'pending' }), { status: 201 });
  return new Response(JSON.stringify({ ok: false, error: 'not_found' }), { status: 404 });
};
globalThis.window = { location: { protocol: 'https:', hostname: 'clinic.example' }, localStorage: globalThis.localStorage, fetch: globalThis.fetch };
await import('../modules/storage-adapter.js');
const S = window.DMEStorage;
assert.equal(S.isLocalDemo(), false);
assert.equal(store.size, 0, 'API mode does not seed personal/demo records into localStorage');

const leads = await S.getLeads();
assert.equal(leads[0].followUp, '2099-01-01');
assert.equal(leads[0].createdAt, '2099-01-01T00:00:00Z');
assert.deepEqual(await S.getAppointments(), [{ id: 'd1-appt', name: 'D1 Patient', date: '2099-02-02', slot: 'Mañana (09:00–14:00)', status: 'pending' }]);
const savedLead = await S.saveLead({ name: 'New D1 lead', phone: '+1 555 0101', notes: 'preserve these notes' });
assert.equal(savedLead.id, 'saved-lead');
assert.equal(savedLead.notes, 'preserve these notes');
const publicLead = await S.savePublicLead({ name: 'Web lead', phone: '+1 555 0102' });
assert.equal(publicLead.id, 'public-lead');
const changedLead = await S.updateLead('saved-lead', { name: 'Changed persisted lead' });
assert.equal(changedLead.id, 'saved-lead');
assert.equal(changedLead.name, 'Changed persisted lead');
assert.equal((await S.deleteLead('saved-lead')).name, 'Deleted persisted lead');
const savedAppt = await S.saveAppointment({ name: 'New D1 appointment', phone: '+1 555 0103', service: 'general', date: '2099-02-03', slot: 'Mañana (09:00–14:00)' });
assert.equal(savedAppt.ok, true);
assert.equal(savedAppt.appointment.id, 'saved-appt');
assert.equal(savedAppt.appointment.name, 'New D1 appointment');
const publicAppt = await S.savePublicAppointment({ name: 'Public patient', phone: '+1 555 0104', service: 'general', date: '2099-02-04', slot: 'Mañana (09:00–14:00)', consent: true });
assert.equal(publicAppt.id, 'public-appt');
const canceled = await S.cancelAppointment('saved-appt', 'patient request');
assert.equal(canceled.cancelReason, 'patient request');

for (const [method, path, status] of [
  ['GET', '/api/leads', 401], ['POST', '/api/leads', 403], ['PUT', '/api/appointments', 409],
  ['DELETE', '/api/leads', 400], ['POST', '/api/appointments', 503],
]) {
  failures.set(`${method} ${path}`, new Response(JSON.stringify({ ok: false, error: `failure_${status}` }), { status }));
  const operation = path === '/api/leads' && method === 'GET' ? () => S.getLeads()
    : path === '/api/leads' && method === 'POST' ? () => S.saveLead({ name: 'Fail', phone: '+1 555 0199' })
      : path === '/api/appointments' && method === 'PUT' ? () => S.saveAppointment({ id: 'x', status: 'cancelled' })
        : path === '/api/leads' && method === 'DELETE' ? () => S.deleteLead('x')
          : () => S.saveAppointment({ name: 'Fail', phone: '+1 555 0199', service: 'general', date: '2099-02-05', slot: 'Mañana (09:00–14:00)' });
  await assert.rejects(operation(), (error) => error.status === status && error.message.includes(String(status)));
  failures.delete(`${method} ${path}`);
}
assert.equal((await S.session()).id, 'api-user', 'session is validated remotely');
failures.set('GET /api/session', new Response(JSON.stringify({ ok: false, error: 'authentication_required' }), { status: 401 }));
store.set('dme_session', JSON.stringify({ id: 'stale-local-session' }));
assert.equal(await S.session(), null);
assert.equal(store.has('dme_session'), false, '401 removes stale local session');

assert.ok(calls.some((call) => call.path === '/api/leads' && call.method === 'GET'));
assert.ok(calls.some((call) => call.path === '/api/leads' && call.method === 'POST'));
assert.ok(calls.some((call) => call.path === '/api/appointments' && call.method === 'POST'));
assert.ok(calls.some((call) => call.path === '/api/intake/leads' && call.method === 'POST'));
assert.ok(calls.some((call) => call.path === '/api/intake/appointments' && call.method === 'POST'));
assert.ok(calls.every((call) => !call.path.includes('/functions/') && !/chat/i.test(call.path)));
assert.equal(store.has('dme_leads'), false, 'API personal data was not copied to localStorage');

// Local demo only falls back for a missing route or network failure; all application HTTP errors remain errors.
failures.set('GET /api/leads', new Response(JSON.stringify({ error: 'not_found' }), { status: 404 }));
await assert.rejects(() => S.getLeads(), (error) => error.status === 404, 'remote 404 is never treated as demo data');
window.location.hostname = 'localhost';
assert.equal(S.isLocalDemo(), true);
assert.ok((await S.getLeads()).length > 0, 'missing local endpoint enables demo fallback');
failures.set('GET /api/leads', new Response(JSON.stringify({ error: 'authentication_required' }), { status: 401 }));
await assert.rejects(() => S.getLeads(), (error) => error.status === 401);
failures.delete('GET /api/leads');
networkFailures.add('GET /api/leads');
assert.ok((await S.getLeads()).length > 0, 'local network failure enables demo fallback');
networkFailures.delete('GET /api/leads');
const localSaved = await S.saveLead({ name: 'Offline local lead', phone: '+1 555 0105' });
assert.ok(localSaved.id);
failures.set('GET /api/appointments', new Response(JSON.stringify({ ok: false, error: 'not_found' }), { status: 404 }));
failures.set('PUT /api/appointments', new Response(JSON.stringify({ ok: false, error: 'not_found' }), { status: 404 }));
const demoBeforeCancel = (await S.getAppointments()).find((appointment) => appointment.id === 'a1');
const demoCancelled = await S.cancelAppointment('a1', 'demo cancellation');
failures.delete('GET /api/appointments');
failures.delete('PUT /api/appointments');
assert.equal(demoCancelled.name, demoBeforeCancel.name, 'demo cancellation preserves the patient name');
assert.equal(demoCancelled.service, demoBeforeCancel.service, 'demo cancellation preserves the service');
assert.equal(demoCancelled.email, demoBeforeCancel.email, 'demo cancellation preserves the email');
assert.equal(demoCancelled.status, 'cancelled');
failures.set('PUT /api/appointments', new Response(JSON.stringify({ ok: false, error: 'not_found' }), { status: 404 }));
await assert.rejects(() => S.saveAppointment({ id: 'a3', status: 'confirmed' }), (error) => error.code === 'invalid_status_transition', 'completed appointments cannot be reactivated');
failures.delete('PUT /api/appointments');
S.runAutomationsFor('lead.created', { id: 'private-lead', name: 'Synthetic Sensitive Name', phone: '+1 555 0199', notes: 'private note' });
const automationLog = S.getAutomationLogs()[0];
assert.equal(automationLog.simulated, true, 'automation log is explicitly marked as a simulation');
assert.equal(automationLog.outcome, 'simulated');
assert.ok(!JSON.stringify(automationLog).includes('Synthetic Sensitive Name'), 'automation logs do not copy patient PII');
console.log('STORAGE ROUTE TESTS PASSED: API-first CRUD, public intake, error handling, session validation, local-only demo fallback');

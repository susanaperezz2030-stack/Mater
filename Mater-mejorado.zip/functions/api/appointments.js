const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const SLOTS = new Set(['Mañana (09:00–14:00)', 'Tarde (14:00–18:00)', 'Última hora (18:00–20:00)']);
const STATUSES = new Set(['pending', 'confirmed', 'completed', 'cancelled']);
const FIELD_ALIASES = { cancel_reason: 'cancelReason', created_at: 'createdAt', updated_at: 'updatedAt' };
const PUBLIC_FIELDS = new Set(['service', 'specialist', 'location', 'date', 'slot', 'name', 'phone', 'email', 'notes']);
const INTAKE_FIELDS = new Set([...PUBLIC_FIELDS, 'consent']);
const UPDATE_FIELDS = new Set([...PUBLIC_FIELDS, 'status', 'cancelReason', 'id', 'createdAt', 'updatedAt', 'consentGiven', 'consentAt']);
const MAX_BODY = 12 * 1024;
const isIsoDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00.000Z`)) && new Date(`${value}T00:00:00.000Z`).toISOString().slice(0, 10) === value;
function todayInTimeZone(timeZone = 'UTC') {
  try {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
    const part = (type) => parts.find((item) => item.type === type)?.value || '';
    return `${part('year')}-${part('month')}-${part('day')}`;
  } catch { return new Date().toISOString().slice(0, 10); }
}
const isPhone = (value) => /^[+\d() .-]{7,30}$/.test(value);
const isEmail = (value) => !value || (value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value));
const uniqueConflict = (error) => /unique constraint|idx_appt_unique_active_slot|constraint failed/i.test(String(error?.message || error));
function normalize(row) {
  if (!row) return null;
  const out = {};
  for (const [key, value] of Object.entries(row)) out[FIELD_ALIASES[key] || key.replace(/_([a-z])/g, (_, c) => c.toUpperCase())] = value;
  if (Object.hasOwn(out, 'consentGiven')) out.consentGiven = out.consentGiven === true || out.consentGiven === 1;
  return out;
}
function bodyObject(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const result = {};
  for (const [key, value] of Object.entries(body)) {
    const canonical = FIELD_ALIASES[key] || key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    if (Object.hasOwn(result, canonical) && result[canonical] !== value) return null;
    result[canonical] = value;
  }
  return result;
}
async function parse(request) {
  if (Number(request.headers.get('Content-Length') || 0) > MAX_BODY) return { tooLarge: true };
  try {
    const text = await request.text();
    if (new TextEncoder().encode(text).byteLength > MAX_BODY) return { tooLarge: true };
    return { body: bodyObject(JSON.parse(text)) };
  } catch { return { malformed: true }; }
}
function validText(value, max, required = false) { return typeof value === 'string' && value.length <= max && value.trim() === value && (!required || !!value); }
function validatePayload(body, fields, creating = false) {
  if (Object.keys(body).some((key) => !fields.has(key))) return false;
  const limits = { service: [80, creating], specialist: [120, false], location: [80, false], date: [10, creating], slot: [60, creating], name: [120, creating], phone: [30, creating], email: [254, false], notes: [500, false], cancelReason: [300, false] };
  for (const [field, [max, required]] of Object.entries(limits)) {
    if (!Object.hasOwn(body, field)) continue;
    if (body[field] === null && !required) continue;
    if (!validText(body[field], max, required)) return false;
  }
  for (const field of ['createdAt', 'updatedAt']) {
    if (Object.hasOwn(body, field) && (!validText(body[field], 40) || !Number.isFinite(Date.parse(body[field])))) return false;
  }
  const value = (field) => body[field];
  if (Object.hasOwn(body, 'phone') && !isPhone(value('phone'))) return false;
  if (Object.hasOwn(body, 'email') && !isEmail(value('email'))) return false;
  if (Object.hasOwn(body, 'date') && !isIsoDate(value('date'))) return false;
  if (Object.hasOwn(body, 'slot') && !SLOTS.has(value('slot'))) return false;
  if (Object.hasOwn(body, 'status') && !STATUSES.has(value('status'))) return false;
  if (Object.hasOwn(body, 'consent') && typeof body.consent !== 'boolean') return false;
  if (Object.hasOwn(body, 'consentGiven') && typeof body.consentGiven !== 'boolean') return false;
  if (Object.hasOwn(body, 'consentAt') && body.consentAt !== null && !validText(body.consentAt, 40)) return false;
  return true;
}
function unavailable(env) { return !env.DB ? json({ ok: false, error: 'database_unavailable' }, 503) : null; }
async function getById(DB, id) { return normalize(await DB.prepare('SELECT * FROM appointments WHERE id=?').bind(id).first()); }
async function findCollision(DB, record, exceptId = '') {
  return DB.prepare('SELECT id FROM appointments WHERE status <> ? AND date = ? AND slot = ? AND IFNULL(location, \'\') = ? AND id <> ?')
    .bind('cancelled', record.date, record.slot, record.location || '', exceptId).first();
}
function invalid(error) { return json({ ok: false, error }, 400); }

export async function onRequestGet({ env }) {
  const error = unavailable(env); if (error) return error;
  const { results } = await env.DB.prepare('SELECT * FROM appointments ORDER BY datetime(created_at) DESC').all();
  return json(results.map(normalize));
}

// Authenticated route; public forms use /api/intake/appointments.
export async function onRequestPost({ request, env }) {
  const error = unavailable(env); if (error) return error;
  const parsed = await parse(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const body = parsed.body;
  if (!body || parsed.malformed || !validatePayload(body, PUBLIC_FIELDS, true)) return invalid('invalid_appointment');
  if (body.date < todayInTimeZone(env.CLINIC_TIME_ZONE || 'UTC')) return invalid('date_in_past');
  const record = { id: crypto.randomUUID(), service: body.service, specialist: body.specialist || '', location: body.location || '', date: body.date, slot: body.slot, name: body.name, phone: body.phone, email: body.email || '', notes: body.notes || '', consentGiven: false, consentAt: null, status: 'pending', createdAt: new Date().toISOString() };
  if (await findCollision(env.DB, record)) return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
  try {
    await env.DB.prepare('INSERT INTO appointments (id,service,specialist,location,date,slot,name,phone,email,notes,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(record.id, record.service, record.specialist, record.location, record.date, record.slot, record.name, record.phone, record.email, record.notes, record.status, record.createdAt).run();
  } catch (cause) {
    if (uniqueConflict(cause)) return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
    throw cause;
  }
  return json(record, 201);
}

export async function onRequestPut({ request, env }) {
  const error = unavailable(env); if (error) return error;
  const parsed = await parse(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const body = parsed.body;
  if (!body || parsed.malformed || !validText(body.id, 100, true) || !validatePayload(body, UPDATE_FIELDS)) return invalid('invalid_appointment_update');
  const current = await getById(env.DB, body.id);
  if (!current) return json({ ok: false, error: 'appointment_not_found' }, 404);
  const next = { ...current };
  for (const field of PUBLIC_FIELDS) if (Object.hasOwn(body, field)) next[field] = body[field];
  if (Object.hasOwn(body, 'cancelReason')) next.cancelReason = body.cancelReason;
  if (Object.hasOwn(body, 'status')) next.status = body.status;
  if (!next.service || !next.date || !next.slot || !next.name || !isPhone(next.phone) || !isEmail(next.email || '')) return invalid('invalid_appointment_update');
  if (body.date && body.date !== current.date && body.date < todayInTimeZone(env.CLINIC_TIME_ZONE || 'UTC')) return invalid('date_in_past');

  const moved = next.date !== current.date || next.slot !== current.slot || (next.location || '') !== (current.location || '');
  const allowedTransitions = {
    pending: new Set(['pending', 'confirmed', 'cancelled']),
    confirmed: new Set(['confirmed', 'completed', 'cancelled']),
    completed: new Set(['completed']),
    cancelled: new Set(['cancelled']),
  };
  if (!allowedTransitions[current.status]?.has(next.status)) return invalid('invalid_status_transition');
  if (current.status === 'confirmed' && next.status === 'pending' && !moved) return invalid('invalid_status_transition');
  if ((next.date !== current.date || next.slot !== current.slot || (next.location || '') !== (current.location || '')) && await findCollision(env.DB, next, next.id)) {
    return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
  }
  const updatedAt = new Date().toISOString();
  try {
    await env.DB.prepare('UPDATE appointments SET service=?,specialist=?,location=?,date=?,slot=?,name=?,phone=?,email=?,notes=?,status=?,cancel_reason=?,updated_at=? WHERE id=?')
      .bind(next.service, next.specialist || '', next.location || '', next.date, next.slot, next.name, next.phone, next.email || '', next.notes || '', next.status, next.cancelReason || '', updatedAt, next.id).run();
  } catch (cause) {
    if (uniqueConflict(cause)) return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
    throw cause;
  }
  const updated = await getById(env.DB, next.id);
  return updated ? json(updated) : json({ ok: false, error: 'appointment_not_found' }, 404);
}

export async function createPublicAppointment({ request, env }) {
  const error = unavailable(env); if (error) return error;
  const parsed = await parse(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const body = parsed.body;
  if (!body || parsed.malformed || !validatePayload(body, INTAKE_FIELDS, true) || body.consent !== true) return invalid('consent_required');
  if (body.date < todayInTimeZone(env.CLINIC_TIME_ZONE || 'UTC')) return invalid('date_in_past');
  const now = new Date().toISOString();
  const record = { id: crypto.randomUUID(), service: body.service, specialist: body.specialist || '', location: body.location || '', date: body.date, slot: body.slot, name: body.name, phone: body.phone, email: body.email || '', notes: body.notes || '', consentGiven: true, consentAt: now, status: 'pending', createdAt: now };
  if (await findCollision(env.DB, record)) return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
  try {
    await env.DB.prepare('INSERT INTO appointments (id,service,specialist,location,date,slot,name,phone,email,notes,consent_given,consent_at,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(record.id, record.service, record.specialist, record.location, record.date, record.slot, record.name, record.phone, record.email, record.notes, 1, record.consentAt, record.status, record.createdAt).run();
  } catch (cause) {
    if (uniqueConflict(cause)) return json({ ok: false, error: 'slot_taken', conflict: true }, 409);
    throw cause;
  }
  return json(record, 201);
}

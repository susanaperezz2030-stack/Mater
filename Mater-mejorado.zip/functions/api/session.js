const encoder = new TextEncoder();
const decoder = new TextDecoder();

function base64url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/g, '');
}
function unbase64url(value) {
  const normalized = value.replaceAll('-', '+').replaceAll('_', '/');
  const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
async function hmacKey(secret) {
  return crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}

export async function signSession(payload, secret) {
  if (typeof secret !== 'string' || secret.length < 32) throw new Error('SESSION_SECRET must contain at least 32 characters');
  const body = base64url(encoder.encode(JSON.stringify(payload)));
  const key = await hmacKey(secret);
  const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(body)));
  return `${body}.${base64url(signature)}`;
}

export async function verifySession(token, secret, now = Date.now()) {
  try {
    if (typeof secret !== 'string' || secret.length < 32 || typeof token !== 'string') return null;
    const parts = token.split('.');
    if (parts.length !== 2) return null;
    const key = await hmacKey(secret);
    const valid = await crypto.subtle.verify('HMAC', key, unbase64url(parts[1]), encoder.encode(parts[0]));
    if (!valid) return null;
    const payload = JSON.parse(decoder.decode(unbase64url(parts[0])));
    if (!payload || !Number.isFinite(payload.exp) || payload.exp <= Math.floor(now / 1000)) return null;
    if (!['administrator', 'manager', 'receptionist', 'marketing'].includes(payload.role)) return null;
    return payload;
  } catch {
    return null;
  }
}

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

// Cloudflare Pages handler: never accepts client-side session claims as proof of identity.
export async function onRequestGet({ request, env }) {
  const token = (request.headers.get('Cookie') || '').split(';').map((part) => part.trim())
    .find((part) => part.startsWith('dme_session='))?.slice('dme_session='.length);
  const session = await verifySession(token, env?.SESSION_SECRET);
  if (!session) return json({ ok: false, error: 'authentication_required' }, 401);
  return json({ ok: true, session: { id: session.id, name: session.name, email: session.email, role: session.role, expiresAt: session.exp } });
}

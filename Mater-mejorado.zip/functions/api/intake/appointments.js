import { createPublicAppointment } from '../appointments.js';

const methodNotAllowed = () => new Response(JSON.stringify({ ok: false, error: 'method_not_allowed' }), {
  status: 405, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', Allow: 'POST' },
});

export function onRequestGet() { return methodNotAllowed(); }
export function onRequestPut() { return methodNotAllowed(); }
export function onRequestDelete() { return methodNotAllowed(); }
export function onRequestPost(context) { return createPublicAppointment(context); }

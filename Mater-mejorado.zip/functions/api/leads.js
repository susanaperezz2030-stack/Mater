const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const LEAD_STATES = new Set(['new', 'contacted', 'appointment_requested', 'appointment_confirmed', 'consultation_done', 'treatment_pending', 'converted', 'lost']);
const SOURCES = new Set(['web', 'whatsapp', 'google_ads', 'instagram', 'facebook_ads', 'referral', 'phone', 'exit_intent']);
const FIELDS = { follow_up: 'followUp', created_at: 'createdAt', updated_at: 'updatedAt' };
const MAX_BODY = 12 * 1024;
function normalize(row) {
  if (!row) return null;
  const out = {};
  for (const [key, value] of Object.entries(row)) out[FIELDS[key] || key.replace(/_([a-z])/g, (_, c) => c.toUpperCase())] = value;
  return out;
}
function bodyObject(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const out = {};
  for (const [key, value] of Object.entries(body)) {
    const canonical = FIELDS[key] || key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    if (Object.hasOwn(out, canonical) && out[canonical] !== value) return null;
    out[canonical] = value;
  }
  return out;
}
function validText(value, max, { required = false, phone = false, email = false, date = false } = {}) {
  if (typeof value !== 'string' || value.length > max || value.trim() !== value || (required && !value)) return false;
  if (phone && !/^[+\d() .-]{7,30}$/.test(value)) return false;
  if (email && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return false;
  if (date && value && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00.000Z`)) || new Date(`${value}T00:00:00.000Z`).toISOString().slice(0, 10) !== value)) return false;
  return true;
}
function invalid(error = 'invalid_lead') { return json({ ok: false, error }, 400); }
function readBody(request) {
  const length = Number(request.headers.get('Content-Length') || 0);
  if (length > MAX_BODY) return Promise.resolve({ tooLarge: true });
  return request.text().then((text) => {
    if (new TextEncoder().encode(text).byteLength > MAX_BODY) return { tooLarge: true };
    try { return { body: bodyObject(JSON.parse(text)) }; } catch { return { malformed: true }; }
  }).catch(() => ({ malformed: true }));
}
function validateFields(fields, { creating = false, publicOnly = false } = {}) {
  const publicFields = new Set(['name', 'phone', 'email', 'treatment', 'source', 'notes']);
  const editableFields = new Set(['name', 'phone', 'email', 'treatment', 'source', 'status', 'notes', 'assignee', 'followUp']);
  for (const key of Object.keys(fields)) {
    if (!publicOnly && ['id', 'createdAt', 'updatedAt'].includes(key)) continue;
    if (!(publicOnly ? publicFields : editableFields).has(key)) return false;
  }
  if (creating && (!Object.hasOwn(fields, 'name') || !Object.hasOwn(fields, 'phone'))) return false;
  const limits = { name: [120, true], phone: [30, true], email: [254, false], treatment: [80, false], source: [40, false], notes: [500, false], assignee: [100, false], followUp: [10, false] };
  for (const [key, [limit, required]] of Object.entries(limits)) {
    if (!Object.hasOwn(fields, key)) continue;
    if (fields[key] === null && !(creating && required)) continue;
    if (!validText(fields[key], limit, { required: creating && required, phone: key === 'phone', email: key === 'email', date: key === 'followUp' })) return false;
  }
  for (const key of ['createdAt', 'updatedAt']) {
    if (Object.hasOwn(fields, key) && (!validText(fields[key], 40) || !Number.isFinite(Date.parse(fields[key])))) return false;
  }
  if (Object.hasOwn(fields, 'status') && !LEAD_STATES.has(fields.status)) return false;
  if (Object.hasOwn(fields, 'source') && fields.source && !SOURCES.has(fields.source)) return false;
  return true;
}
async function getById(DB, id) {
  return normalize(await DB.prepare('SELECT * FROM leads WHERE id=?').bind(id).first());
}
function dbUnavailable(env) { return !env.DB ? json({ ok: false, error: 'database_unavailable' }, 503) : null; }

export async function onRequestGet({ env }) {
  const unavailable = dbUnavailable(env); if (unavailable) return unavailable;
  const { results } = await env.DB.prepare('SELECT * FROM leads ORDER BY datetime(created_at) DESC').all();
  return json(results.map(normalize));
}

// This route is protected by _middleware.js; public callers use /api/intake/leads.
export async function onRequestPost({ request, env }) {
  const unavailable = dbUnavailable(env); if (unavailable) return unavailable;
  const parsed = await readBody(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const lead = parsed.body;
  if (!lead || parsed.malformed || !validateFields(lead, { creating: true })) return invalid();
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  const record = { id, name: lead.name, phone: lead.phone, email: lead.email || '', treatment: lead.treatment || '', source: lead.source || 'web', status: lead.status || 'new', notes: lead.notes || '', assignee: lead.assignee || '', followUp: lead.followUp || '', createdAt: now };
  await env.DB.prepare('INSERT INTO leads (id,name,phone,email,treatment,source,status,notes,assignee,follow_up,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
    .bind(record.id, record.name, record.phone, record.email, record.treatment, record.source, record.status, record.notes, record.assignee, record.followUp, now).run();
  return json(record, 201);
}

export async function onRequestPut({ request, env }) {
  const unavailable = dbUnavailable(env); if (unavailable) return unavailable;
  const parsed = await readBody(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const body = parsed.body;
  if (!body || parsed.malformed || !validText(body.id, 100, { required: true }) || !validateFields(body)) return invalid('invalid_lead_update');
  const current = await getById(env.DB, body.id);
  if (!current) return json({ ok: false, error: 'lead_not_found' }, 404);
  const updates = {};
  for (const field of ['name', 'phone', 'email', 'treatment', 'source', 'status', 'notes', 'assignee', 'followUp']) if (Object.hasOwn(body, field)) updates[field] = body[field];
  const next = { ...current, ...updates, updatedAt: new Date().toISOString() };
  await env.DB.prepare('UPDATE leads SET name=?,phone=?,email=?,treatment=?,source=?,status=?,notes=?,assignee=?,follow_up=?,updated_at=? WHERE id=?')
    .bind(next.name, next.phone, next.email || '', next.treatment || '', next.source || '', next.status, next.notes || '', next.assignee || '', next.followUp || '', next.updatedAt, next.id).run();
  const updated = await getById(env.DB, body.id);
  return updated ? json(updated) : json({ ok: false, error: 'lead_not_found' }, 404);
}

export async function onRequestDelete({ request, env }) {
  const unavailable = dbUnavailable(env); if (unavailable) return unavailable;
  const parsed = await readBody(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const body = parsed.body;
  if (!body || parsed.malformed || Object.keys(body).some((key) => !['id'].includes(key)) || !validText(body.id, 100, { required: true })) return invalid('invalid_lead_delete');
  const existing = await getById(env.DB, body.id);
  if (!existing) return json({ ok: false, error: 'lead_not_found' }, 404);
  await env.DB.prepare('DELETE FROM leads WHERE id=?').bind(body.id).run();
  return json({ ok: true, lead: existing });
}

export async function createPublicLead({ request, env }) {
  const unavailable = dbUnavailable(env); if (unavailable) return unavailable;
  const parsed = await readBody(request);
  if (parsed.tooLarge) return json({ ok: false, error: 'payload_too_large' }, 413);
  const lead = parsed.body;
  if (!lead || parsed.malformed || !validateFields(lead, { creating: true, publicOnly: true })) return invalid();
  const id = crypto.randomUUID(); const now = new Date().toISOString();
  const record = { id, name: lead.name, phone: lead.phone, email: lead.email || '', treatment: lead.treatment || '', source: lead.source || 'web', status: 'new', notes: lead.notes || '', assignee: '', followUp: '', createdAt: now };
  await env.DB.prepare('INSERT INTO leads (id,name,phone,email,treatment,source,status,notes,assignee,follow_up,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
    .bind(record.id, record.name, record.phone, record.email, record.treatment, record.source, record.status, record.notes, '', '', now).run();
  return json(record, 201);
}

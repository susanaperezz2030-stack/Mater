# Seguridad, privacidad y datos de salud

## Alcance

Dental Master Ultimate es una herramienta de sitio, captación y gestión de contactos/citas; no es un sistema clínico (HIS/EHR) ni una historia clínica electrónica. **Su uso no certifica, garantiza ni acredita cumplimiento HIPAA, RGPD u otra normativa.** La clínica debe evaluar sus obligaciones, contratos, base jurídica y medidas con asesoría competente antes de tratar datos personales.

El CRM y la agenda pueden procesar nombre, teléfono, correo, tratamiento de interés, fecha/franja, especialista/sede y notas libres. El formulario público ahora solicita una preferencia de contacto/logística, no síntomas ni historia clínica; no introduzcas diagnósticos, alergias, imágenes diagnósticas ni otros datos de salud protegidos en notas libres. Gestiona los datos clínicos en un sistema independiente apropiado y autorizado.

## Demo local y privacidad del navegador

La demo local utiliza datos ficticios. En este modo, el adaptador puede conservar en `localStorage` del navegador registros de prueba de CRM, citas, usuarios demo, preferencias, eventos y logs, según la función utilizada. `localStorage` no es una bóveda: no cifra por sí mismo esos datos, cualquier persona con acceso al perfil/navegador puede verlos y scripts del mismo origen pueden leerlos. Los datos no se sincronizan entre navegadores; borrar almacenamiento del sitio puede eliminarlos, pero no equivale a un procedimiento formal de borrado de producción.

No uses la demo, perfiles compartidos ni equipos públicos para información personal real. La UI identifica las cuentas locales como demo. El CRUD de usuarios de esa pantalla solo cambia el navegador local; no aprovisiona identidades ni permisos en Cloudflare.

En modo con API, las operaciones remotas deben fallar con error visible cuando el servidor no las acepta; la UI no debe reinterpretar un fallo remoto como un guardado local satisfactorio. La persistencia remota depende de la configuración de Cloudflare y D1 `DB`. Verifica la configuración efectiva antes de cargar datos reales.

## Controles implementados y límites

El código de Pages Functions revisado implementa sesiones firmadas HMAC con cookie `HttpOnly`, `Secure`, `SameSite=Strict` y expiración de 8 horas; la configuración de cuentas proviene del secreto `USERS` y usa hashes PBKDF2. El middleware valida rol para operaciones API de leads/CRM (administrator, manager), citas (administrator, manager, receptionist), automatizaciones (administrator, manager) y ajustes (administrator). También rechaza orígenes cruzados en los endpoints de mutación que pasan por ese middleware. Estos controles no sustituyen una revisión de seguridad del despliegue ni prueban que una configuración particular esté activa.

La ruta pública de citas exige `consent: true` y guarda `consent_given` junto con el instante UTC `consent_at`. En D1 existente es imprescindible aplicar primero `db/migrations/0003_appointment_consent.sql` en staging; las citas previas quedan con `consent_given=0` y `consent_at=NULL`, pues no se infiere aceptación retrospectivamente. La casilla constituye una señal técnica de aceptación de este formulario, no una evaluación legal, no prueba consentimiento para marketing ni sustituye avisos, contratos o registros adicionales que pueda exigir la jurisdicción.

En el panel, las pestañas se limitan por rol y la sesión se revalida al montar y abrir una pestaña. Esa autorización de cliente es solo presentación: la seguridad de los datos depende siempre de la autorización del servidor. La gestión de usuarios de producción no se realiza desde la UI; la cuenta se configura en `USERS` en Cloudflare.

El código revisado no proporciona revocación central de cada sesión emitida: borrar la cookie al cerrar sesión no invalida por sí solo una copia robada del token antes de su vencimiento. **MFA, limitación de intentos/login y rate limiting de formularios públicos, Turnstile u otra defensa anti-bot/anti-spam y monitorización de abuso quedan pendientes de configuración/implementación.** No asumas que están activos.

Las reglas de automatización registran ejecuciones y logs; el nombre de una acción email/SMS/WhatsApp no acredita entrega. Este proyecto no muestra una integración de proveedor que envíe realmente esas comunicaciones. El formulario público puede usar el endpoint Formspree configurado en el sitio; comprueba el destino, el acceso, la retención, los acuerdos y el consentimiento pertinentes con ese proveedor antes de utilizarlo.

## HIPAA y otros marcos

No se afirma que este producto o su despliegue sea HIPAA-compliant. La existencia de HTTPS, hashes de contraseña, cookies firmadas o un proveedor con opciones empresariales no constituye por sí misma cumplimiento. Si se considera tratar PHI, se necesita una evaluación específica del entorno, contrato/BAA cuando corresponda, controles organizativos y técnicos adecuados, gestión de incidentes, acceso mínimo, retención/borrado y validación jurídica. No conectes PHI basándote solo en esta documentación.

Tampoco se afirma conformidad RGPD. Antes de producción, determina responsable/encargados, base jurídica, transparencia y consentimiento cuando aplique, retención, ejercicio de derechos, transferencias y obligaciones locales. Completa y verifica con datos reales de la entidad los avisos legales y de privacidad; una casilla o banner por sí solos no demuestran conformidad.

## Antes de producción

- Configura `SESSION_SECRET` y `USERS` como secretos de Cloudflare, en el entorno correcto; nunca los guardes en Git ni en el navegador. Usa hashes PBKDF2 y cuentas individuales con privilegio mínimo.
- Revisa roles de servidor, middleware, sesiones, esquema/migraciones y binding D1 en staging. No conectes pruebas a D1 de producción ni apliques migraciones sin copia de seguridad y autorización.
- Implementa y verifica rate limiting de intentos de acceso y formularios, Turnstile/anti-spam donde corresponda, MFA, monitorización y respuesta ante abuso; hoy son pendientes, no capacidades incluidas.
- Confirma qué datos recoge cada formulario, a qué endpoint/proveedor se envían, quién puede acceder, cuánto tiempo se conservan y cómo se atienden solicitudes de acceso/borrado.
- Desactiva credenciales y datos de demo, limita las notas y excluye datos clínicos. Valida los consentimientos, avisos, contratos y requisitos de la jurisdicción con asesoría adecuada.
- Prueba flujos y permisos en staging con datos sintéticos. Una prueba contra SQLite en memoria o localhost no verifica Cloudflare ni D1 reales.

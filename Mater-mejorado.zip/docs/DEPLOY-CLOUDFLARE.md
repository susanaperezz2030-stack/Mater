# Configuración y despliegue en Cloudflare Pages

Esta guía describe la configuración del proyecto; no despliega, modifica secretos, crea una D1 ni ejecuta migraciones. Las Pages Functions viven en `functions/` en la raíz del repositorio y usan las rutas `/api/*`. El build estático de las páginas se prepara en `dist/`.

## Antes de tocar un proyecto existente

Primero identifica el proyecto Pages y su entorno correcto. Si Wrangler va a ser la fuente de configuración, revisa/sincroniza la configuración existente antes de cambiar `wrangler.toml`:

```bash
pnpm install
pnpm exec wrangler login
pnpm run pages:sync-config
```

`pages:sync-config` descarga la configuración actual del proyecto y puede reemplazar `wrangler.toml`. Conserva los valores reales de proyecto, `pages_build_output_dir = "./dist"` y el binding D1 existente `DB`; no inventes ni reemplaces `database_id`, no crees una base nueva y no copies `functions/` dentro de `dist/`. El comando `pnpm run check:cloudflare` valida el archivo local, pero no acredita por sí solo que el Dashboard tenga los mismos bindings.

No se ha conectado ni modificado una cuenta Cloudflare o una D1 real en este trabajo. No despliegues si no tienes autorización expresa para el proyecto/entorno y para la operación.

## Requisitos de aplicación

1. Configura el binding D1 `DB` del proyecto Pages para la base existente correcta. El código de Functions usa ese binding para CRM, agenda y otros recursos persistidos. La disponibilidad y el esquema deben comprobarse en staging antes de cualquier tráfico real.
2. Configura `SESSION_SECRET` como secreto del entorno Pages con al menos 32 caracteres aleatorios. Genéralo fuera del repositorio, por ejemplo con `openssl rand -base64 48`; no lo guardes en Git, documentación, cliente o tickets.
3. Configura `USERS` como secreto JSON con los usuarios de producción, sus roles y hashes `passwordHash` PBKDF2. El formato esperado incluye `id`, `name`, `email`, `passwordHash` y `role`; roles admitidos: `administrator`, `manager`, `receptionist`, `marketing`. Para generar el hash se incluye `pnpm run hash-password` (requiere terminal interactiva y longitud mínima indicada por el script). No escribas contraseñas en claro en `USERS`.
4. Configura la misma zona IANA de la clínica en `siteData.js > settings.timeZone` y en la variable Pages `CLINIC_TIME_ZONE` (por ejemplo, solo si es la zona real: `America/Chicago`). El valor de respaldo en el código es `UTC`; la clínica debe fijar y verificar su zona antes de operar citas para que la fecha mínima del navegador y la validación del servidor coincidan.

Ejemplo estructural, **no es una cuenta/clave válida**:

```json
[{"id":"admin-1","name":"Administración","email":"admin@tuclinica.com","passwordHash":"pbkdf2$310000$...$...","role":"administrator"}]
```

El login necesita una configuración válida de `USERS` y `SESSION_SECRET`; si falta, no se debe abrir como demo. `DEMO_MODE=true` habilita credenciales de demostración del backend y no debe habilitarse en producción. La UI no administra cuentas reales: la pestaña Usuarios informa de `USERS` y su formulario CRUD está limitado a la demo local.

## Roles y endpoints

La UI muestra pestañas según rol: administrator (todas), manager (overview, CRM, appointments, automations, content, analytics), receptionist (appointments) y marketing (content, analytics). La pestaña Usuarios es solo administrator y solo permite guardar cuentas ficticias localmente en modo demo.

La API aplica middleware server-side a las rutas privadas: leads/CRM para administrator/manager; citas para administrator/manager/receptionist; automatizaciones para administrator/manager; ajustes para administrator. La visibilidad de una pestaña no reemplaza la autorización del servidor. Valida este mapa contra el código y el entorno desplegado antes de introducir datos reales. Las páginas de contenido y analítica del cliente no implican que exista una API de usuarios.

`_headers` define la CSP aplicada por Cloudflare Pages: `default-src 'self'`, límites específicos a los CDNs usados (unpkg, jsDelivr, cdnjs, Google Fonts/Tag Manager), `connect-src` para Formspree y las conexiones de analítica declaradas, `frame-src` para Google Maps, `object-src 'none'`, `base-uri 'self'` y `frame-ancestors 'self'`. `unsafe-eval` se ha retirado. Se conserva `unsafe-inline` porque la plantilla aún contiene scripts y estilos inline; migrarlos a archivos/nonce permitiría endurecer más. Revisa la CSP cada vez que se añada o cambie un proveedor; las cabeceras del archivo solo se aplican si se publican efectivamente con Pages.

El backend revisado emite una sesión firmada en cookie con duración de 8 horas. Cerrar sesión borra la cookie en el navegador, pero no aporta revocación central anticipada del token. Las funciones actuales no incluyen MFA, limitación de intentos/rate limiting de formularios ni Turnstile/anti-spam: esos controles quedan pendientes y deben resolverse antes de exponer el sitio a abuso o a datos reales.

## D1, esquema y migraciones

Consulta `db/schema.sql` y las migraciones antes de operar. Para una base existente, revisa y aplica `db/migrations/0003_appointment_consent.sql` en staging antes de activar intake; añade `consent_given` y `consent_at` sin declarar aceptadas las citas antiguas. No ejecutes migraciones ni `wrangler d1 execute` contra producción ni alteres el índice de disponibilidad sin copia de seguridad, revisión, aprobación y plan de recuperación. La migración heredada `db/migrations/0002_remove_plaintext_user_passwords.sql` también requiere revisión y ejecución manual en staging; no la ejecutes si el esquema ya está migrado ni contra producción sin aprobación. El alta de cuentas de Cloudflare se hace en el secreto `USERS`, no en una tabla desde el panel.

No habilites automatizaciones suponiendo que se envían emails/SMS/WhatsApp: los flujos y logs registran eventos simulados; no hay aquí una integración funcional de entrega. El formulario público puede enviar a Formspree según la configuración del sitio; valida proveedor, destino, términos, retención, consentimiento y controles aplicables por separado.

## Preparación y validación local

```bash
pnpm run prepare:pages
pnpm run check:cloudflare
pnpm run test:validator
pnpm run test:functions
pnpm run test:storage
```

Para servir Functions localmente, `pnpm run dev:pages` prepara `dist/` y levanta Pages localmente. Usa datos sintéticos y configuración aislada; no conectes pruebas a la D1 de producción. Las pruebas de Functions pueden emplear D1 simulado y no validan secretos, permisos efectivos del Dashboard, envío de correo/SMS ni una D1 real.

## Publicar (solo con autorización)

El script `pnpm run deploy` ejecuta el preflight, prepara `dist/` y publica con Wrangler Pages. Antes de ejecutarlo, verifica con la persona responsable que el proyecto y entorno son los correctos, que la configuración sincronizada conserva la D1 esperada, que se autoriza publicar y que las comprobaciones de staging se completaron. Esta documentación no ejecuta el comando ni constituye autorización de despliegue.

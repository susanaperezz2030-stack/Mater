# Dental Master Ultimate

Edición Ultimate del proyecto dental: sitio público multipágina, temas visuales, panel de administración, CRM de leads, agenda y asistente FAQ local bilingüe. `index.html` y `admin.html` están en la raíz del proyecto.

## Incluye

- Sitio público con páginas independientes y recursos preparados en `dist/`.
- Panel con pestañas por rol, CRM de contactos y agenda. El servidor debe volver a autorizar todas las operaciones protegidas: ocultar una pestaña en el navegador no sustituye al control de acceso.
- Asistente FAQ en español e inglés que responde localmente con coincidencia de palabras clave; no usa un servicio remoto de IA.
- Pages Functions en `functions/` para autenticación, CRM, citas, automatizaciones y ajustes. La persistencia de datos depende del binding D1 `DB` y de la configuración correcta de Cloudflare.

## Modos de uso y datos

**Demo local.** Inicia el sitio con `python3 -m http.server 8000` y abre `http://localhost:8000/` o `/admin.html`. Cuando el adaptador identifica el modo de demo local (`DMEStorage.isLocalDemo()`), puede usar datos ficticios y funciones almacenadas en el `localStorage` de ese navegador. La demo no sincroniza otros navegadores o dispositivos y no es una cuenta ni un entorno de producción. No introduzcas datos reales de pacientes en ella. El panel etiqueta la gestión local de usuarios como demo.

**Cloudflare Pages.** Para el panel de producción se requieren el binding D1 `DB`, el secreto `SESSION_SECRET` y el secreto `USERS` con cuentas y hashes PBKDF2. Las cuentas de producción se configuran en Cloudflare, no en el formulario local de usuarios del panel. Sin configuración válida, el login debe fallar; no se debe habilitar `DEMO_MODE` en producción. La interfaz presenta errores de operaciones remotas en lugar de comunicar un guardado local como si fuera éxito. Las rutas/API protegidas requieren autorización de servidor; consulta también el middleware y valida permisos con la configuración efectiva del despliegue. Configura la misma zona IANA real en `siteData.js > settings.timeZone` y la variable Pages `CLINIC_TIME_ZONE`.

Las páginas y formularios pueden contener nombre, teléfono, email, fecha/hora solicitadas, tratamiento de interés y notas. No incluyas diagnósticos, historias clínicas, imágenes médicas ni otros datos de salud sensibles. Las notas libres no deben usarse para datos clínicos. El intake público de citas exige aceptación explícita de la política y registra `consent_given`/`consent_at`; en D1 existente hay que aplicar `db/migrations/0003_appointment_consent.sql` en staging primero. Las filas históricas no se marcan como aceptadas. La casilla no equivale a una evaluación de validez legal ni autoriza marketing.

## Autenticación y límites funcionales

El inicio de sesión solicita explícitamente correo electrónico y contraseña. Los usuarios de producción se cargan desde `USERS`; la pantalla de Usuarios solo permite CRUD de datos ficticios cuando el adaptador identifica una demo local. En producción explica la configuración de Cloudflare y no simula altas o bajas remotas.

Los flujos de automatización y sus pruebas registran eventos/logs; el registro de una acción etiquetada como email, SMS o WhatsApp **no significa que un mensaje real se haya enviado**. No se proporciona aquí un proveedor de entrega conectado. El formulario público puede usar el endpoint Formspree configurado en el sitio; verifica sus términos, destinatario, retención, acceso y consentimiento antes de producción. La FAQ es local y no transmite preguntas a un proveedor de IA.

## Despliegue

El proyecto incluye `wrangler.toml`, scripts de preparación y `dist/`. Antes de usar Wrangler en un proyecto Pages existente, sincroniza y revisa su configuración real para conservar el binding D1 `DB`; no reemplaces el ID real, crees otra base ni ejecutes migraciones sobre producción sin autorización y respaldo. No se ha desplegado este cambio ni se ha conectado a la D1 real.

Consulta [`docs/DEPLOY-CLOUDFLARE.md`](docs/DEPLOY-CLOUDFLARE.md) para pasos y límites. Para seguridad y privacidad, consulta [`docs/SECURITY-HIPAA.md`](docs/SECURITY-HIPAA.md); este software no certifica ni garantiza cumplimiento HIPAA, RGPD u otra normativa.

## Pruebas

```bash
pnpm install
pnpm run test:validator
pnpm run test:functions
pnpm run test:storage
pnpm run test:assistant
pnpm run test:assistant-e2e  # requiere servidor local activo
pnpm run test:e2e            # requiere servidor local activo
pnpm test                    # suite completa
```

Las pruebas del backend emplean un binding D1 simulado cuando así se indique; un resultado local no acredita configuración de Cloudflare, entrega de comunicaciones ni comportamiento con una D1 real. Antes de publicar, verifica la configuración autorizada, el binding y el esquema, los textos/datos de la clínica y los consentimientos aplicables.

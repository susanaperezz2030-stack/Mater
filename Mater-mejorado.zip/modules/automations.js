/**
 * Dental Master Enterprise — Automation Demo
 * Simulated triggers and logs only; no email, SMS, WhatsApp or notification is sent.
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function render(container) {
    if (!container) return;
    const autos = S.getAutomations();
    const logs = S.getAutomationLogs();

    container.innerHTML = `
      <div class="auto-panel">
        <div class="auto-col">
          <h3>Reglas de demostración</h3>
          <p class="dme-notice" role="note"><small><strong>Solo simulación local.</strong> Este panel no envía emails, SMS, WhatsApp ni avisos; tampoco ejecuta campañas programadas en segundo plano.</small></p>
          <p class="dme-muted"><small>Activa o desactiva reglas ficticias y registra pruebas manuales para previsualizar el comportamiento.</small></p>
          <div class="auto-list" id="autoList"></div>
        </div>
        <div class="auto-col">
          <div class="dme-row dme-row-between"><h3>Historial de simulaciones</h3><button id="autoRunStalled" class="dme-btn dme-btn-xs" title="Simula la regla de seguimientos estancados">Simular chequeo diario</button></div>
          <div class="auto-logs" id="autoLogs"></div>
        </div>
      </div>
      <p class="dme-notice"><small><strong>Sin proveedor de entrega:</strong> los nombres de acciones email/SMS/WhatsApp describen una idea de flujo, no una integración. No conectes datos de pacientes ni interpretes un registro simulado como mensaje entregado.</small></p>`;

    function renderList() {
      container.querySelector('#autoList').innerHTML = autos.map((a) => `
        <article class="auto-card">
          <div class="auto-head">
            <div><strong>${esc(a.name)}</strong><div class="dme-muted"><small>Disparador: <code>${esc(a.trigger)}</code> · Acción: <code>${esc(a.action)}</code></small></div></div>
            <label class="dme-switch"><input type="checkbox" data-id="${esc(a.id)}" ${a.enabled ? 'checked' : ''}><span class="dme-switch-track"></span></label>
          </div>
          <p class="auto-desc"><small>${esc(a.actionDetail)}</small></p>
          <div class="auto-foot"><small class="dme-muted">Última simulación local: ${a.lastRun ? esc(a.lastRun) : '—'}</small><button class="dme-btn dme-btn-xs js-auto-test" data-id="${esc(a.id)}">Simular ahora</button></div>
        </article>`).join('');
    }

    function renderLogs() {
      container.querySelector('#autoLogs').innerHTML = logs.length === 0
        ? '<p class="dme-empty">Sin ejecuciones todavía. Genera un lead o una cita para ver los flujos en acción.</p>'
        : logs.map((l) => `<div class="auto-log simulated"><span>${esc(l.at)}</span><strong>${esc(l.automationName || l.automationId)}</strong><small>${esc(l.action)} · Simulación local; no enviado</small></div>`).join('');
    }

    container.querySelector('#autoList').onclick = (e) => {
      const sw = e.target.closest('input[type=checkbox]');
      if (sw) { const a = autos.find((x) => x.id === sw.dataset.id); if (a) { a.enabled = sw.checked; S.saveAutomation(a); renderList(); } }
      const btn = e.target.closest('.js-auto-test');
      if (btn) { const a = autos.find((x) => x.id === btn.dataset.id); if (a) { S.runAutomationsFor(a.trigger, { simulated: true }); renderList(); renderLogs(); } }
    };
    container.querySelector('#autoRunStalled').onclick = () => { S.runAutomationsFor('schedule.daily', { simulated: true }); renderList(); renderLogs(); };
    renderList(); renderLogs();
  }

  global.DMEAutomations = { render };
})(typeof window !== 'undefined' ? window : globalThis);

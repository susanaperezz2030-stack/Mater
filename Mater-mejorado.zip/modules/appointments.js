/**
 * Dental Master Enterprise — Smart Appointment Management
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const STATUS = { pending: 'Pendiente', confirmed: 'Confirmada', completed: 'Realizada', cancelled: 'Cancelada' };
  const NEXT = { pending: ['confirmed', 'cancelled'], confirmed: ['completed', 'cancelled'] };
  function todayInTimeZone(timeZone = 'UTC') {
    try {
      const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
      const part = (type) => parts.find((item) => item.type === type)?.value || '';
      return `${part('year')}-${part('month')}-${part('day')}`;
    } catch { return new Date().toISOString().slice(0, 10); }
  }

  function errorText(error, action) {
    const status = Number(error && (error.status || error.statusCode));
    if (status === 409 || error?.conflict) return 'Conflicto de horario (409): la franja ya no está disponible. Actualiza la lista y elige otra.';
    if (status === 401 || status === 403) return 'Tu sesión no está autorizada o ha caducado. Vuelve a iniciar sesión.';
    if (status === 400) return `El servidor rechazó los datos de la cita. Revisa los campos e inténtalo de nuevo.`;
    return `No se pudo ${action}. No se han aplicado cambios en esta vista; inténtalo de nuevo.`;
  }

  async function render(container, cfg, session) {
    if (!container) return;
    if (!session || !['administrator', 'manager', 'receptionist'].includes(session.role)) {
      container.innerHTML = '<p class="dme-notice" role="alert">Inicia sesión con un rol autorizado para consultar la agenda.</p>';
      return;
    }
    let list;
    try {
      list = await S.getAppointments();
      if (!Array.isArray(list)) throw new Error('invalid_appointments_response');
    } catch (error) {
      container.innerHTML = '<div class="dme-notice" role="alert"></div>';
      container.querySelector('.dme-notice').textContent = errorText(error, 'cargar las citas');
      return;
    }
    const todayKey = todayInTimeZone(cfg?.settings?.timeZone || 'UTC');
    list.sort((a, b) => `${a.date || ''} ${a.slot || ''}`.localeCompare(`${b.date || ''} ${b.slot || ''}`));

    container.innerHTML = `
      <div class="appt-toolbar">
        <input type="date" id="apptDateFilter" class="dme-input" aria-label="Filtrar por fecha">
        <select id="apptStatusFilter" class="dme-select" aria-label="Filtrar por estado"><option value="">Todos los estados</option><option value="pending">Pendientes</option><option value="confirmed">Confirmadas</option><option value="completed">Realizadas</option><option value="cancelled">Canceladas</option></select>
        <button id="apptNewBtn" class="dme-btn dme-btn-primary">+ Nueva cita</button>
      </div>
      <div id="apptFeedback" class="dme-notice" role="status" hidden></div>
      <div class="appt-list" id="apptList"></div>
      <div id="apptModal" class="dme-modal" aria-hidden="true"></div>`;

    function notify(message, error = false) {
      const box = container.querySelector('#apptFeedback');
      if (!box) return;
      box.hidden = !message;
      box.textContent = message || '';
      box.setAttribute('role', error ? 'alert' : 'status');
    }
    function filter(items) {
      const d = container.querySelector('#apptDateFilter')?.value || '';
      const st = container.querySelector('#apptStatusFilter')?.value || '';
      return items.filter((a) => (d ? a.date === d : true) && (st ? a.status === st : true));
    }
    function renderList() {
      const listEl = container.querySelector('#apptList');
      if (!listEl) return;
      const f = filter(list);
      listEl.innerHTML = f.length === 0
        ? '<p class="dme-empty">No hay citas con estos filtros.</p>'
        : f.map((a) => `
          <article class="appt-card appt-${esc(a.status)}">
            <div class="appt-main">
              <div class="appt-date"><strong>${esc(a.date)}</strong><span>${esc(a.slot)}</span></div>
              <div class="appt-info">
                <h4>${esc(a.name)} <span class="dme-badge appt-badge-${esc(a.status)}">${esc(STATUS[a.status] || a.status)}</span></h4>
                <p><a href="tel:${esc(a.phone)}">${esc(a.phone)}</a> · ${esc(a.email || '')} · Tratamiento: <b>${esc(a.service)}</b>${a.location ? ` · Sede: ${esc(a.location)}` : ''}</p>
                <small class="dme-muted">Especialista: ${esc(a.specialist || 'Sin preferencia')}${a.notes ? ` · Notas: ${esc(a.notes)}` : ''}${a.cancelReason ? ` · Motivo cancelación: ${esc(a.cancelReason)}` : ''}</small>
              </div>
            </div>
            <div class="appt-actions">
              ${NEXT[a.status]?.includes('confirmed') ? `<button class="dme-btn dme-btn-xs dme-btn-primary js-confirm" data-id="${esc(a.id)}">Confirmar</button>` : ''}
              ${NEXT[a.status]?.includes('completed') && a.date <= todayKey ? `<button class="dme-btn dme-btn-xs js-complete" data-id="${esc(a.id)}">Realizada</button>` : ''}
              ${['pending', 'confirmed'].includes(a.status) ? `<button class="dme-btn dme-btn-xs js-resched" data-id="${esc(a.id)}">Reprogramar</button><button class="dme-btn dme-btn-xs dme-btn-danger js-cancel" data-id="${esc(a.id)}">Cancelar</button>` : ''}
            </div>
          </article>`).join('');
    }
    function openModal(html) { const m = container.querySelector('#apptModal'); m.innerHTML = html; m.classList.add('open'); m.setAttribute('aria-hidden', 'false'); }
    function closeModal() { const m = container.querySelector('#apptModal'); m.classList.remove('open'); m.setAttribute('aria-hidden', 'true'); }
    function savedResult(result) {
      if (!result || result.ok === false) {
        const e = new Error(result?.conflict ? 'conflict' : 'not_saved');
        if (result?.conflict) e.status = 409;
        throw e;
      }
      return result.appointment || null;
    }
    function commit(updated) {
      const index = list.findIndex((item) => item.id === updated.id);
      if (index >= 0) list[index] = { ...list[index], ...updated };
      else list.unshift(updated);
      renderList();
    }

    function openNew() {
      const today = todayInTimeZone(cfg?.settings?.timeZone || 'UTC');
      const services = (cfg && cfg.services) || [];
      const team = (cfg && cfg.team) || [];
      const locations = (cfg && cfg.locations) || [];
      openModal(`
        <div class="dme-modal-card">
          <div class="dme-modal-head"><h3>Nueva cita</h3><button class="dme-close" id="apptClose">×</button></div>
          <form id="apptNewForm" class="dme-form">
            <div class="dme-row">
              <label>Servicio<select name="service" class="dme-select">${services.map((s) => `<option value="${esc(s.id)}">${esc(s.title?.es || s.title)}</option>`).join('') || '<option value="general">General</option>'}</select></label>
              <label>Especialista<select name="specialist" class="dme-select"><option value="">Sin preferencia</option>${team.map((t) => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('')}</select></label>
            </div>
            <div class="dme-row">
              <label>Sede<select name="location" class="dme-select"><option value="">Principal</option>${locations.map((l) => `<option value="${esc(l.id)}">${esc(l.name)}</option>`).join('')}</select></label>
              <label>Fecha<input type="date" name="date" class="dme-input" required min="${today}" value="${today}"></label>
            </div>
            <div class="dme-row">
              <label>Franja<select name="slot" class="dme-select"><option>Mañana (09:00–14:00)</option><option>Tarde (14:00–18:00)</option><option>Última hora (18:00–20:00)</option></select></label>
              <label>Nombre paciente *<input name="name" class="dme-input" required></label>
            </div>
            <div class="dme-row">
              <label>Teléfono *<input name="phone" class="dme-input" required></label>
              <label>Correo electrónico<input type="email" name="email" class="dme-input"></label>
            </div>
            <label>Notas<textarea name="notes" rows="2" class="dme-input"></textarea></label>
            <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar cita</button></div>
          </form>
        </div>`);
      container.querySelector('#apptClose').onclick = closeModal;
      container.querySelector('#apptNewForm').onsubmit = async (e) => {
        e.preventDefault();
        const button = e.target.querySelector('[type="submit"]');
        button.disabled = true;
        try {
          const result = await S.saveAppointment(Object.fromEntries(new FormData(e.target)));
          const appointment = savedResult(result);
          if (!appointment) throw new Error('missing_saved_appointment');
          commit(appointment);
          closeModal();
          notify('Cita guardada.');
        } catch (error) {
          notify(errorText(error, 'guardar la cita'), true);
          button.disabled = false;
        }
      };
    }

    container.querySelector('#apptList').onclick = async (e) => {
      const button = e.target.closest('button[data-id]');
      const id = button?.dataset.id;
      if (!id) return;
      const a = list.find((x) => String(x.id) === String(id));
      if (!a) return;
      const classList = button.classList;
      if (classList.contains('js-confirm') || classList.contains('js-complete')) {
        const next = classList.contains('js-confirm') ? 'confirmed' : 'completed';
        if (!NEXT[a.status]?.includes(next)) return;
        button.disabled = true;
        try {
          const result = await S.saveAppointment({ ...a, status: next });
          const saved = savedResult(result);
          commit({ ...a, ...(saved || {}), status: next });
          if (next === 'confirmed') S.runAutomationsFor('appointment.confirmed', { ...a, status: next });
          if (next === 'completed') S.runAutomationsFor('appointment.completed', { ...a, status: next });
          notify(`Cita ${STATUS[next].toLowerCase()}.`);
        } catch (error) {
          button.disabled = false;
          notify(errorText(error, 'actualizar el estado'), true);
        }
      } else if (classList.contains('js-cancel')) {
        if (!NEXT[a.status]?.includes('cancelled')) return;
        const reason = prompt('Motivo de cancelación (opcional):');
        if (reason === null) return;
        button.disabled = true;
        try {
          const response = await S.cancelAppointment(id, reason);
          const result = response === undefined && typeof S.isLocalDemo === 'function' && S.isLocalDemo()
            ? null
            : savedResult(response);
          commit({ ...a, ...(result || {}), status: 'cancelled', cancelReason: reason });
          notify('Cita cancelada.');
        } catch (error) {
          button.disabled = false;
          notify(errorText(error, 'cancelar la cita'), true);
        }
      } else if (classList.contains('js-resched')) {
        if (!['pending', 'confirmed'].includes(a.status)) return;
        const d = prompt('Nueva fecha (YYYY-MM-DD):', a.date); if (!d) return;
        const slot = prompt('Nueva franja:\n1) Mañana (09:00–14:00)\n2) Tarde (14:00–18:00)\n3) Última hora (18:00–20:00)\n(Escribe 1, 2 o 3 o el texto)', '1');
        if (slot === null) return;
        const slots = { 1: 'Mañana (09:00–14:00)', 2: 'Tarde (14:00–18:00)', 3: 'Última hora (18:00–20:00)' };
        const finalSlot = slots[slot] || slot;
        button.disabled = true;
        try {
          const result = await S.rescheduleAppointment(id, d, finalSlot);
          const saved = savedResult(result);
          commit({ ...a, ...(saved || {}), date: d, slot: finalSlot, status: 'pending' });
          notify('Cita reprogramada y pendiente de confirmación.');
        } catch (error) {
          button.disabled = false;
          notify(errorText(error, 'reprogramar la cita'), true);
        }
      }
    };
    container.querySelector('#apptDateFilter').onchange = renderList;
    container.querySelector('#apptStatusFilter').onchange = renderList;
    container.querySelector('#apptNewBtn').onclick = openNew;
    renderList();
  }

  global.DMEAppointments = { render };
})(typeof window !== 'undefined' ? window : globalThis);

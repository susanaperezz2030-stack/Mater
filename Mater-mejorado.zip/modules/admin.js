/**
 * Dental Master Enterprise — Professional Administration Dashboard
 * Tabs: overview, crm, appointments, automations, content, settings, analytics, users
 * RBAC: administrator, manager, receptionist, marketing
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ROLE_TABS = {
    administrator: ['overview', 'crm', 'appointments', 'automations', 'content', 'settings', 'analytics', 'users'],
    manager: ['overview', 'crm', 'appointments', 'automations', 'content', 'analytics'],
    receptionist: ['appointments'],
    marketing: ['content', 'analytics'],
  };

  function isLocalDemo() { return Boolean(S && typeof S.isLocalDemo === 'function' && S.isLocalDemo()); }
  function errorMessage(error, fallback) {
    const status = Number(error && (error.status || error.statusCode));
    if (status === 401 || status === 403) return 'Tu sesión no está autorizada o ha caducado. Inicia sesión de nuevo.';
    if (status === 503 || error?.code === 'AUTH_NOT_CONFIGURED') return 'El acceso de producción no está configurado. Un administrador debe revisar USERS y SESSION_SECRET en Cloudflare.';
    if (error?.code === 'STORAGE_UNAVAILABLE' || error?.name === 'StorageError') return 'No se pudo conectar con el servicio. Comprueba la conexión e inténtalo de nuevo.';
    return fallback;
  }
  function showMessage(target, message, isError = true) {
    if (!target) return;
    target.innerHTML = `<div class="dme-notice" role="${isError ? 'alert' : 'status'}"><p>${esc(message)}</p></div>`;
  }

  async function mount(container, cfg) {
    if (!container) return;

    function renderLogin() {
      container.innerHTML = `
        <div class="adm-login">
          <div class="adm-login-card">
            <div class="adm-logo">✦ Dental Master Enterprise</div>
            <h2>Acceso al panel de administración</h2>
            <p class="dme-muted"><small>Acceso para personal autorizado.</small></p>
            <form id="admLoginForm" class="dme-form">
              <label>Correo electrónico<input type="email" name="email" class="dme-input" autocomplete="username" required></label>
              <label>Contraseña<input type="password" name="pass" class="dme-input" autocomplete="current-password" required></label>
              <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Entrar</button></div>
            </form>
            ${isLocalDemo() ? '<div class="adm-demo-creds"><small><strong>Demo local:</strong> admin@clinic.com / admin123. Estas credenciales y los datos del navegador son ficticios.</small></div>' : ''}
            <p class="dme-notice"><small><strong>Seguridad:</strong> el panel gestiona datos de contacto, no historias clínicas. Configura las cuentas de producción en el secreto Cloudflare USERS.</small></p>
            <p id="admLoginError" class="dme-error" role="alert" hidden></p>
          </div>
        </div>`;
      container.querySelector('#admLoginForm').onsubmit = async (e) => {
        e.preventDefault();
        const { email, pass } = Object.fromEntries(new FormData(e.target));
        const error = container.querySelector('#admLoginError');
        error.hidden = true;
        try {
          const sess = await S.login(email, pass);
          if (!sess) { error.textContent = 'No se pudo iniciar sesión. Verifica el correo y la contraseña.'; error.hidden = false; return; }
          renderDashboard(sess);
        } catch (err) {
          const status = Number(err && (err.status || err.statusCode));
          error.textContent = status === 401
            ? 'Correo electrónico o contraseña incorrectos.'
            : status === 403
              ? 'El servidor rechazó el inicio de sesión para esta solicitud.'
              : errorMessage(err, 'No se pudo completar el inicio de sesión. Inténtalo de nuevo.');
          error.hidden = false;
        }
      };
    }

    async function renderDashboard(sess) {
      const role = sess.role;
      if (!ROLE_TABS[role]) { renderLogin(); return; }
      container.innerHTML = `
        <div class="adm-shell">
          <header class="adm-bar">
            <div class="adm-bar-left">
              <a href="index.html" class="adm-back">← Ver sitio</a>
              <span class="adm-title">✦ <strong>Dental Master Enterprise</strong> · Panel</span>
            </div>
            <div class="adm-user"><span>${esc(sess.name)}</span> <span class="dme-badge">${esc(role)}</span> <button id="admLogout" class="dme-btn dme-btn-xs dme-btn-ghost">Salir</button></div>
          </header>
          <div class="adm-body">
            <aside class="adm-nav">
              ${ROLE_TABS[role].map((tab) => `<button class="adm-link${tab === ROLE_TABS[role][0] ? ' active' : ''}" data-tab="${tab}">${({ overview: 'Panel', crm: 'CRM · Leads', appointments: 'Citas', automations: 'Automatizaciones', content: 'Contenido', settings: 'Ajustes', analytics: 'Analítica', users: 'Usuarios' })[tab]}</button>`).join('')}
            </aside>
            <main class="adm-content" id="admTabContent"></main>
          </div>
        </div>`;
      container.querySelector('#admLogout').onclick = async () => {
        try { await S.logout(); renderLogin(); }
        catch (error) { showMessage(container.querySelector('#admTabContent'), errorMessage(error, 'No se pudo cerrar la sesión con el servidor. Inténtalo de nuevo.')); }
      };
      container.querySelectorAll('.adm-link').forEach((b) => {
        b.onclick = () => openTab(b.dataset.tab, sess);
      });
      openTab(ROLE_TABS[role][0], sess);
    }

    async function openTab(tab, sess) {
      const c = container.querySelector('#admTabContent');
      if (!c) return;
      if (!ROLE_TABS[sess?.role]?.includes(tab)) { showMessage(c, 'Tu rol no tiene permiso para acceder a esta sección.'); return; }
      try {
        const current = await S.session();
        if (!current || !ROLE_TABS[current.role]?.includes(tab)) { renderLogin(); return; }
        container.querySelectorAll('.adm-link').forEach((x) => x.classList.toggle('active', x.dataset.tab === tab));
        if (tab === 'overview') await renderOverview(c);
        else if (tab === 'crm') global.DMECRM ? await global.DMECRM.render(c, current) : showMessage(c, 'Módulo CRM no cargado.');
        else if (tab === 'appointments') global.DMEAppointments ? await global.DMEAppointments.render(c, cfg, current) : showMessage(c, 'Módulo de citas no cargado.');
        else if (tab === 'automations' && !isLocalDemo()) showMessage(c, 'La gestión y los logs de automatizaciones disponibles aquí son solo de demostración local; no se envían emails, SMS o mensajes de WhatsApp desde este panel.');
        else if (tab === 'automations') global.DMEAutomations ? await global.DMEAutomations.render(c) : showMessage(c, 'Módulo de automatizaciones no cargado.');
        else if (tab === 'content') renderContent(c);
        else if (tab === 'settings') renderSettings(c);
        else if (tab === 'analytics') renderAnalytics(c);
        else if (tab === 'users') renderUsers(c);
      } catch (err) {
        if (err?.status === 401 || err?.status === 403) { renderLogin(); return; }
        showMessage(c, errorMessage(err, 'No se pudieron cargar los datos de esta sección. Inténtalo de nuevo.'));
      }
    }

    async function renderOverview(c) {
      const [leads, appts] = await Promise.all([S.getLeads(), S.getAppointments()]);
      const conv = leads.filter((l) => l.status === 'converted').length;
      const rate = leads.length ? Math.round((conv / leads.length) * 100) : 0;
      const pendingAppts = appts.filter((a) => a.status === 'pending');
      const upcoming = appts.filter((a) => a.status !== 'cancelled').slice(0, 5);
      const recent = leads.slice(0, 6);
      const stages = (S.PIPELINE_STAGES || []).map((stage) => ({ ...stage, count: leads.filter((lead) => lead.status === stage.id).length }));
      const stageMax = Math.max(1, ...stages.map((stage) => stage.count));
      c.innerHTML = `
        <div class="adm-section-head"><h2>Resumen del negocio</h2><p class="dme-muted"><small>Métricas calculadas en tiempo real a partir del CRM y de la agenda de citas.</small></p></div>
        <div class="adm-kpis">
          <div class="adm-kpi-card"><span class="kpi-num">${leads.length}</span><span class="kpi-label">Leads registrados</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${leads.filter((l) => l.status === 'new').length}</span><span class="kpi-label">Leads nuevos</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${pendingAppts.length}</span><span class="kpi-label">Citas pendientes de confirmar</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${rate}%</span><span class="kpi-label">Tasa de conversión</span></div>
        </div>
        <div class="adm-card adm-pipeline-card"><div class="adm-chart-head"><h3>Estado del pipeline</h3><span class="dme-badge">${leads.length} leads</span></div><div class="adm-chart" role="list" aria-label="Leads por estado">${stages.map((stage) => `<div class="adm-chart-row" role="listitem"><span class="adm-chart-label">${esc(stage.label)}</span><span class="adm-chart-track"><span class="adm-chart-bar" style="width:${Math.max(stage.count ? 5 : 0, Math.round(stage.count / stageMax * 100))}%"></span></span><strong class="adm-chart-value">${stage.count}</strong></div>`).join('')}</div></div>
        <div class="adm-two">
          <div class="adm-card"><h3>Próximas citas</h3>${upcoming.length ? `<table class="dme-table"><tbody>${upcoming.map((a) => `<tr><td>${esc(a.date)} ${esc((a.slot || '').split(' ')[0])}</td><td><strong>${esc(a.name)}</strong></td><td>${esc(a.service)}</td><td><span class="dme-badge">${esc(a.status)}</span></td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">No hay citas.</p>'}</div>
          <div class="adm-card"><h3>Últimos leads</h3>${recent.length ? `<table class="dme-table"><tbody>${recent.map((l) => `<tr><td><strong>${esc(l.name)}</strong></td><td><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></td><td>${esc(l.treatment || '—')}</td><td><span class="dme-badge">${esc(l.status)}</span></td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">No hay leads.</p>'}</div>
        </div>
        <div class="adm-card"><h3>Accesos rápidos</h3><div class="adm-quick"><a class="dme-btn dme-btn-primary" href="index.html" target="_blank">Abrir sitio web</a><button class="dme-btn" onclick="document.querySelector('[data-tab=crm]').click()">Ver pipeline completo</button><button class="dme-btn" onclick="document.querySelector('[data-tab=appointments]').click()">Gestionar citas</button>${isLocalDemo() ? '<button class="dme-btn dme-btn-ghost" onclick="DMEStorage.resetDemo();location.reload()">Restaurar datos demo</button>' : ''}</div></div>`;
    }

    function renderContent(c) {
      c.innerHTML = `
        <div class="adm-section-head"><h2>Gestión de contenidos</h2><p class="dme-muted"><small>En demo local, los cambios se guardan en este navegador para previsualización. En producción edita la configuración fuente y vuelve a publicar; este formulario no guarda contenido remoto.</small></p></div>
        <div class="adm-two">
          <div class="adm-card"><h3>Tratamientos</h3><p class="dme-muted"><small>Los tratamientos se configuran en <code>siteData.js > services</code> (nombre, precio, duración, icono, categoría).</small></p><div id="svcList"></div></div>
          <div class="adm-card"><h3>Identidad y textos</h3><form id="contentForm" class="dme-form"><label>Nombre de la clínica<input name="name" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.name)}"></label><label>Lema principal (ES)<input name="tagline" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.tagline && cfg.clinic.tagline.es)}"></label><label>Ciudad<input name="city" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.city)}"></label><label>Email de contacto<input name="email" class="dme-input" value="${esc(cfg.contact && cfg.contact.email)}"></label><div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar</button></div></form></div>
        </div>
        <div class="adm-card"><h3>Reglas de veracidad</h3><p><small>Este producto obliga a sustituir las cifras de ejemplo (pacientes, reseñas, años) por datos verificados antes de publicar. No publiques valoraciones ni testimonios no comprobables.</small></p></div>
        <p id="contentSaveStatus" class="dme-notice" role="status" hidden></p>`;
      const svcEl = c.querySelector('#svcList');
      svcEl.innerHTML = ((cfg && cfg.services) || []).map((s) => `<div class="adm-item"><div><strong>${esc(s.title?.es || s.title)}</strong> <small class="dme-muted">${esc(s.price || '')}</small></div><span class="dme-badge">${esc(s.category)}</span></div>`).join('');
      c.querySelector('#contentForm').onsubmit = (e) => {
        e.preventDefault();
        const status = c.querySelector('#contentSaveStatus');
        if (!isLocalDemo()) { status.textContent = 'No se ha guardado: este formulario solo permite previsualización en demo local. Actualiza la configuración fuente y publica el sitio mediante el proceso autorizado.'; status.hidden = false; return; }
        const d = Object.fromEntries(new FormData(e.target));
        cfg.clinic = cfg.clinic || {}; cfg.contact = cfg.contact || {};
        cfg.clinic.name = d.name; cfg.clinic.city = d.city;
        cfg.clinic.tagline = cfg.clinic.tagline || {}; cfg.clinic.tagline.es = d.tagline;
        cfg.contact.email = d.email;
        try {
          S.saveSettings({ ...S.getSettings(), clinicOverride: d });
          status.textContent = 'Guardado en la demo local. Actualiza la página del sitio para ver la previsualización.';
          status.hidden = false;
        } catch (error) {
          status.textContent = errorMessage(error, 'No se pudo guardar la previsualización local.');
          status.hidden = false;
        }
      };
    }

    async function renderSettings(c) {
      if (!isLocalDemo()) {
        c.innerHTML = '<div class="adm-section-head"><h2>Ajustes del sitio</h2></div><div class="adm-card"><p>Estos ajustes modifican solo la previsualización local del navegador; no hay guardado remoto de temas o módulos en esta pantalla.</p><p>Para cambiar producción, actualiza la configuración del sitio mediante el proceso autorizado y vuelve a publicar.</p></div>';
        return;
      }
      const themes = await (fetch('assets/themes/themes.json').then((r) => r.json()).catch(() => []));
      const currentTheme = (cfg.settings && cfg.settings.theme) || 'luxury-studio';
      c.innerHTML = `
        <div class="adm-section-head"><h2>Ajustes del sitio</h2><p class="dme-muted"><small>Identidad visual, módulos activos y preferencias generales.</small></p></div>
        <div class="adm-card">
          <h3>Tema visual</h3>
          <p class="dme-muted"><small>Elige una de las 6 identidades visuales incluidas. Cada una define colores, contrastes y formas pensados para un tipo de clínica.</small></p>
          <div class="theme-grid">${themes.map((t) => `
            <div class="theme-card ${t.id === currentTheme ? 'selected' : ''}" data-theme="${esc(t.id)}">
              <div class="theme-swatch"><span style="background:${t.preview.bg}"></span><span style="background:${t.preview.ink}"></span><span style="background:${t.preview.accent}"></span><span style="background:${t.preview.accent2}"></span></div>
              <strong>${esc(t.name)}</strong>
              <small>${esc(t.desc)}</small>
            </div>`).join('')}</div>
        </div>
        <div class="adm-card">
          <h3>Módulos activos</h3>
          <form id="featsForm" class="adm-feats">${Object.entries((cfg.features) || {}).map(([k, v]) => `<label class="dme-check"><input type="checkbox" name="${k}" ${v ? 'checked' : ''}><span>${esc(k)}</span></label>`).join('')}</form>
          <div class="dme-actions"><button id="featsSave" class="dme-btn dme-btn-primary">Guardar módulos</button></div>
        </div>
        <div class="adm-card">
          <h3>Asistente FAQ local</h3>
          <p class="dme-muted"><small>Responde en español e inglés sobre precios, horarios, ubicación, citas, seguros y urgencias. Funciona directamente en el navegador: no necesita conexión a servicios de IA ni claves.</small></p>
        </div>`;
      c.querySelector('#featsSave').onclick = () => {
        const d = Object.fromEntries(new FormData(c.querySelector('#featsForm')));
        cfg.features = cfg.features || {};
        for (const k of Object.keys(cfg.features)) cfg.features[k] = k in d;
        S.saveSettings({ ...S.getSettings(), features: cfg.features });
        alert('Módulos actualizados.');
      };
      c.querySelector('.theme-grid').onclick = (e) => {
        const card = e.target.closest('.theme-card'); if (!card) return;
        c.querySelectorAll('.theme-card').forEach((x) => x.classList.remove('selected')); card.classList.add('selected');
        const t = card.dataset.theme; cfg.settings = cfg.settings || {}; cfg.settings.theme = t;
        localStorage.setItem('dme-preview-theme', t);
        document.documentElement.setAttribute('data-theme', t);
      };
    }

    function renderAnalytics(c) {
      if (!isLocalDemo()) {
        c.innerHTML = '<div class="adm-section-head"><h2>Analítica y conversión</h2></div><div class="adm-card"><p>Los eventos y las estadísticas disponibles en esta pantalla se guardan solo en la demo local del navegador. No hay un endpoint de analítica persistente conectado en este panel de producción.</p></div>';
        return;
      }
      const a = global.DMEAnalytics ? global.DMEAnalytics.stats() : { counts: {}, sources: {}, total: 0 };
      const labels = { 'click.phone': 'Clics en llamar', 'click.whatsapp': 'Clics en WhatsApp', 'booking.open': 'Aperturas del wizard de cita', 'booking.submit': 'Reservas completadas', 'click.exit_claim': 'Reclamaciones exit-intent' };
      c.innerHTML = `
        <div class="adm-section-head"><h2>Analítica y conversión</h2><p class="dme-muted"><small>Seguimiento de clics clave y orígenes UTM capturados en la navegación.</small></p></div>
        <div class="adm-kpis">${Object.entries(a.counts).map(([k, v]) => `<div class="adm-kpi-card"><span class="kpi-num">${v}</span><span class="kpi-label">${esc(labels[k] || k)}</span></div>`).join('') || '<p class="dme-empty">Sin eventos registrados aún.</p>'}</div>
        <div class="adm-card"><h3>Orígenes UTM</h3>${Object.keys(a.sources).length ? `<table class="dme-table"><thead><tr><th>utm_source</th><th>Eventos</th></tr></thead><tbody>${Object.entries(a.sources).map(([k, v]) => `<tr><td><code>${esc(k)}</code></td><td>${v}</td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">Sin parámetros UTM detectados. Prueba URLs con <code>?utm_source=...</code></p>'}</div>
        <p class="dme-notice"><small>Para medición formal añade el ID de GA4 en <code>integraciones.googleAnalyticsId</code> y asegúrate de configurar el aviso de cookies conforme a la normativa aplicable.</small></p>`;
    }

    function renderUsers(c) {
      if (!isLocalDemo()) {
        c.innerHTML = `<div class="adm-section-head"><h2>Usuarios y permisos</h2></div><div class="adm-card"><p><strong>La gestión de cuentas de producción no se realiza desde este panel.</strong></p><p>Cloudflare Pages autentica con las cuentas definidas en el secreto <code>USERS</code> (JSON con usuarios, roles y hashes PBKDF2). Actualiza ese secreto mediante el proceso autorizado de Cloudflare; esta pantalla no crea ni elimina cuentas remotas.</p><p>La configuración requiere además <code>SESSION_SECRET</code>. No introduzcas contraseñas ni secretos en esta página.</p></div>`;
        return;
      }
      const users = S.getUsers();
      c.innerHTML = `
        <div class="adm-section-head"><h2>Usuarios y permisos <span class="dme-badge">DEMO LOCAL</span></h2><p class="dme-muted"><small>Estas cuentas solo se guardan en este navegador y no crean usuarios de producción. Roles de demostración: administrator, manager, receptionist, marketing.</small></p></div>
        <div class="adm-card"><table class="dme-table"><thead><tr><th>Nombre</th><th>Email</th><th>Rol</th><th></th></tr></thead><tbody>${users.map((u) => `<tr><td><strong>${esc(u.name)}</strong></td><td>${esc(u.email)}</td><td><span class="dme-badge">${esc(u.role)}</span></td><td>${users.length > 1 ? `<button class="dme-btn dme-btn-xs dme-btn-danger js-deluser" data-id="${u.id}">Eliminar</button>` : ''}</td></tr>`).join('')}</tbody></table></div>
        <div class="adm-card"><h3>Nuevo usuario de prueba</h3><form id="newUserForm" class="dme-form"><div class="dme-row"><label>Nombre<input name="name" class="dme-input" required></label><label>Correo electrónico<input type="email" name="email" class="dme-input" autocomplete="off" required></label></div><div class="dme-row"><label>Contraseña de demo<input type="password" name="pass" class="dme-input" autocomplete="new-password" required></label><label>Rol<select name="role" class="dme-select">${S.ROLES.map((r) => `<option value="${r}">${r}</option>`).join('')}</select></label></div><div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Crear cuenta demo</button></div></form></div>`;
      c.querySelector('#newUserForm').onsubmit = (e) => { e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); S.saveUser(d); renderUsers(c); };
      c.querySelector('table').onclick = (e) => { const b = e.target.closest('.js-deluser'); if (b && confirm('¿Eliminar usuario?')) { S.deleteUser(b.dataset.id); renderUsers(c); } };
    }

    try {
      const sess = await S.session();
      if (sess) await renderDashboard(sess); else renderLogin();
    } catch (error) {
      container.innerHTML = '<div class="adm-login"><div class="adm-login-card"><h2>No se pudo validar la sesión</h2><p id="admMountError" role="alert"></p><button id="admRetry" class="dme-btn dme-btn-primary">Reintentar</button></div></div>';
      container.querySelector('#admMountError').textContent = errorMessage(error, 'El servicio de autenticación no está disponible. Inténtalo de nuevo más tarde.');
      container.querySelector('#admRetry').onclick = () => mount(container, cfg);
    }
  }

  global.DMEAdmin = { mount };
})(typeof window !== 'undefined' ? window : globalThis);

/* Dental Master Enterprise — API-first data adapter with explicit local demo mode. */
(function (global) {
  'use strict';

  const LS_KEYS = {
    leads: 'dme_leads', appointments: 'dme_appointments', automations: 'dme_automations',
    automationLogs: 'dme_automation_logs', users: 'dme_users', settings: 'dme_settings',
    events: 'dme_events', session: 'dme_session',
  };
  const SEED_USERS = [
    { id: 'u1', name: 'Admin', email: 'admin@clinic.com', pass: 'admin123', role: 'administrator' },
    { id: 'u2', name: 'Ana Gestora', email: 'manager@clinic.com', pass: 'demo123', role: 'manager' },
    { id: 'u3', name: 'Laura Recepción', email: 'recepcion@clinic.com', pass: 'demo123', role: 'receptionist' },
    { id: 'u4', name: 'Carlos Marketing', email: 'marketing@clinic.com', pass: 'demo123', role: 'marketing' },
  ];
  const SEED_LEADS = [
    { id: 'l1', name: 'Paciente Demo 01', phone: '+1 555 0101', email: 'demo01@example.test', treatment: 'veneers', source: 'web', status: 'new', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u3', followUp: '2099-11-12', createdAt: '2099-11-08T10:30:00Z' },
    { id: 'l2', name: 'Paciente Demo 02', phone: '+1 555 0102', email: 'demo02@example.test', treatment: 'invisalign', source: 'whatsapp', status: 'contacted', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u3', followUp: '2099-11-10', createdAt: '2099-11-07T16:00:00Z' },
    { id: 'l3', name: 'Paciente Demo 03', phone: '+1 555 0103', email: 'demo03@example.test', treatment: 'implants', source: 'google_ads', status: 'appointment_requested', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u2', followUp: '2099-11-09', createdAt: '2099-11-06T09:15:00Z' },
    { id: 'l4', name: 'Paciente Demo 04', phone: '+1 555 0104', email: 'demo04@example.test', treatment: 'whitening', source: 'instagram', status: 'appointment_confirmed', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u3', followUp: '2099-11-15', createdAt: '2099-11-05T12:00:00Z' },
    { id: 'l5', name: 'Paciente Demo 05', phone: '+1 555 0105', email: 'demo05@example.test', treatment: 'general', source: 'referral', status: 'consultation_done', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u2', followUp: '2099-11-13', createdAt: '2099-11-02T11:00:00Z' },
    { id: 'l6', name: 'Paciente Demo 06', phone: '+1 555 0106', email: 'demo06@example.test', treatment: 'emergency', source: 'phone', status: 'converted', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u3', followUp: '', createdAt: '2099-10-30T17:00:00Z' },
    { id: 'l7', name: 'Paciente Demo 07', phone: '+1 555 0107', email: 'demo07@example.test', treatment: 'implants', source: 'facebook_ads', status: 'treatment_pending', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u2', followUp: '2099-11-18', createdAt: '2099-10-25T14:00:00Z' },
    { id: 'l8', name: 'Paciente Demo 08', phone: '+1 555 0108', email: 'demo08@example.test', treatment: 'rootcanal', source: 'exit_intent', status: 'lost', notes: 'Registro sintético de demostración; no usar para atención clínica.', assignee: 'u4', followUp: '', createdAt: '2099-10-20T10:00:00Z' },
  ];
  const SEED_APPOINTMENTS = [
    { id: 'a1', service: 'veneers', specialist: 'Equipo Demo', location: '', date: '2099-11-15', slot: 'Mañana (09:00–14:00)', name: 'Paciente Demo 01', phone: '+1 555 0101', email: 'demo01@example.test', notes: 'Registro sintético de demostración; no usar para atención clínica.', status: 'confirmed', createdAt: '2099-11-05T12:00:00Z' },
    { id: 'a2', service: 'invisalign', specialist: 'Equipo Demo', location: '', date: '2099-11-16', slot: 'Tarde (14:00–18:00)', name: 'Paciente Demo 02', phone: '+1 555 0102', email: 'demo02@example.test', notes: 'Registro sintético de demostración; no usar para atención clínica.', status: 'pending', createdAt: '2099-11-06T09:15:00Z' },
    { id: 'a3', service: 'general', specialist: 'Equipo Demo', location: '', date: '2099-11-10', slot: 'Mañana (09:00–14:00)', name: 'Paciente Demo 03', phone: '+1 555 0103', email: 'demo03@example.test', notes: 'Registro sintético de demostración; no usar para atención clínica.', status: 'completed', createdAt: '2099-11-02T11:00:00Z' },
  ];
  const SEED_AUTOMATIONS = [
    { id: 'auto-new-inquiry', name: 'Nueva solicitud de información', trigger: 'lead.created', condition: 'true', action: 'internal_notification', actionDetail: 'Notificar al equipo por email interno', enabled: true, lastRun: '2026-11-08T10:30:10Z' },
    { id: 'auto-appt-confirm', name: 'Confirmación de cita', trigger: 'appointment.confirmed', condition: 'true', action: 'email_patient', actionDetail: 'Enviar email con fecha, hora y ubicación', enabled: true, lastRun: '2026-11-05T12:02:00Z' },
    { id: 'auto-reminder', name: 'Recordatorio 24 h antes', trigger: 'appointment.reminder_due', condition: 'true', action: 'sms_patient', actionDetail: 'SMS con botón de confirmación', enabled: true, lastRun: null },
    { id: 'auto-missed', name: 'Seguimiento de cita no presentada', trigger: 'appointment.no_show', condition: 'true', action: 'whatsapp_followup', actionDetail: 'Mensaje amable para reprogramar', enabled: false, lastRun: null },
    { id: 'auto-review', name: 'Solicitud de reseña en Google', trigger: 'appointment.completed', condition: 'appointment.service != "emergency"', action: 'email_review_link', actionDetail: 'Email con enlace directo a la ficha de Google', enabled: true, lastRun: '2026-11-02T11:05:00Z' },
    { id: 'auto-reactivate', name: 'Reactivación de pacientes inactivos', trigger: 'schedule.monthly', condition: 'months_since_last_visit >= 12', action: 'email_recall', actionDetail: 'Recordatorio de revisión anual', enabled: false, lastRun: null },
    { id: 'auto-stalled', name: 'Seguimiento de consultas sin respuesta', trigger: 'schedule.daily', condition: 'lead.status == "new" && lead.age_hours >= 48', action: 'task_assign', actionDetail: 'Crear tarea para recepción', enabled: true, lastRun: null },
  ];

  function isLocalDemo() {
    const location = global.location || (typeof globalThis !== 'undefined' ? globalThis.location : null);
    const host = String(location?.hostname || '').toLowerCase();
    return location?.protocol === 'file:' || host === 'localhost' || host === '127.0.0.1';
  }
  function read(key, fallback) {
    try { const raw = global.localStorage?.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
  }
  function write(key, value) {
    if (!isLocalDemo()) return;
    try { global.localStorage?.setItem(key, JSON.stringify(value)); } catch (error) { throw new Error(`No se pudo guardar el modo demo local: ${error.message}`); }
  }
  function localList(key, seed) { return read(key, seed).map((record) => ({ ...record })); }
  function initSeeds() {
    if (!isLocalDemo()) return;
    for (const [key, value] of [[LS_KEYS.users, SEED_USERS], [LS_KEYS.leads, SEED_LEADS], [LS_KEYS.appointments, SEED_APPOINTMENTS], [LS_KEYS.automations, SEED_AUTOMATIONS], [LS_KEYS.automationLogs, []], [LS_KEYS.events, []], [LS_KEYS.settings, { demoMode: true }]]) {
      if (!global.localStorage?.getItem(key)) write(key, value);
    }
  }

  class StorageError extends Error {
    constructor(message, details = {}) { super(message); this.name = 'StorageError'; Object.assign(this, details); }
  }
  async function api(path, options = {}) {
    let response;
    try {
      response = await global.fetch(path, {
        credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options,
      });
    } catch (cause) {
      throw new StorageError(`No se pudo conectar con ${path}: ${cause?.message || 'error de red'}`, { code: 'network_error', endpoint: path, cause });
    }
    let payload = null;
    const text = await response.text().catch(() => '');
    if (text) {
      try { payload = JSON.parse(text); } catch { throw new StorageError(`La respuesta de ${path} no es JSON válido.`, { code: 'invalid_response', status: response.status, endpoint: path }); }
    }
    if (!response.ok) {
      const code = payload?.error || payload?.code || `http_${response.status}`;
      const message = payload?.message || payload?.error || `Error HTTP ${response.status}`;
      throw new StorageError(`${message} (${response.status}, ${path})`, { code, status: response.status, endpoint: path, payload });
    }
    return payload;
  }
  function mayFallback(error) {
    return isLocalDemo() && (error?.code === 'network_error' || [404, 501].includes(error?.status));
  }
  async function apiOrDemo(path, options, demo) {
    try { return await api(path, options); }
    catch (error) { if (mayFallback(error)) return demo(); throw error; }
  }
  function normalizeRow(row) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return row;
    const out = {};
    for (const [key, value] of Object.entries(row)) {
      const camel = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
      out[camel] = value;
    }
    return out;
  }
  function recordFrom(payload, key, endpoint) {
    const record = payload?.[key] || payload?.data || payload;
    if (!record || typeof record !== 'object' || Array.isArray(record) || !record.id) {
      throw new StorageError(`La respuesta de ${endpoint} no contiene el registro guardado.`, { code: 'invalid_response', endpoint, payload });
    }
    return normalizeRow(record);
  }
  function arrayFrom(payload, endpoint) {
    const rows = Array.isArray(payload) ? payload : payload?.items || payload?.data;
    if (!Array.isArray(rows)) throw new StorageError(`La respuesta de ${endpoint} no contiene una lista válida.`, { code: 'invalid_response', endpoint, payload });
    return rows.map(normalizeRow);
  }
  function event(type, detail) { logEvent({ type, ...detail }); }
  function demoSave(key, seed, record, idField = 'id') {
    const list = localList(key, seed);
    const index = list.findIndex((entry) => entry[idField] === record[idField]);
    if (index >= 0) list[index] = record; else list.unshift(record);
    write(key, list);
    return record;
  }
  const timestamp = () => new Date().toISOString();

  async function login(email, pass) {
    const body = { email, pass };
    try {
      const result = await api('/api/auth', { method: 'POST', body: JSON.stringify(body) });
      if (!result?.ok || !result.session) throw new StorageError('El servidor no devolvió una sesión válida.', { code: 'invalid_response', endpoint: '/api/auth' });
      return result.session;
    } catch (error) {
      if (!mayFallback(error)) throw error;
      const users = localList(LS_KEYS.users, SEED_USERS);
      const user = users.find((candidate) => String(candidate.email).toLowerCase() === String(email || '').toLowerCase() && candidate.pass === pass);
      if (!user) return null;
      const localSession = { id: user.id, name: user.name, email: user.email, role: user.role, token: `local-${Date.now()}` };
      write(LS_KEYS.session, localSession);
      return localSession;
    }
  }
  async function session() {
    try {
      const result = await api('/api/session');
      if (result?.session) return result.session;
      if (result?.id && result?.role) return result;
      throw new StorageError('El servidor no devolvió una sesión válida.', { code: 'invalid_response', endpoint: '/api/session' });
    } catch (error) {
      if (error?.status === 401) {
        try { global.localStorage?.removeItem(LS_KEYS.session); } catch {}
        return null;
      }
      if (!mayFallback(error)) throw error;
      return read(LS_KEYS.session, null);
    }
  }
  async function logout() {
    let failure = null;
    try { await api('/api/auth', { method: 'DELETE' }); }
    catch (error) { if (!mayFallback(error)) failure = error; }
    finally { try { global.localStorage?.removeItem(LS_KEYS.session); } catch {} }
    if (failure) throw failure;
  }

  async function getLeads() {
    return apiOrDemo('/api/leads', {}, () => localList(LS_KEYS.leads, SEED_LEADS)).then((data) => Array.isArray(data) ? data.map(normalizeRow) : arrayFrom(data, '/api/leads'));
  }
  async function saveLead(lead) {
    const input = { ...lead };
    const saved = await apiOrDemo('/api/leads', { method: 'POST', body: JSON.stringify(input) }, () => {
      const record = { ...input, id: input.id || `l${Date.now()}`, createdAt: input.createdAt || timestamp() };
      return demoSave(LS_KEYS.leads, SEED_LEADS, record);
    });
    const record = saved?.id ? normalizeRow(saved) : recordFrom(saved, 'lead', '/api/leads');
    event('lead.created', { leadId: record.id, source: record.source || 'web' });
    runAutomationsFor('lead.created', record);
    return record;
  }
  async function savePublicLead(lead) {
    const input = { ...lead };
    const saved = await apiOrDemo('/api/intake/leads', { method: 'POST', body: JSON.stringify(input) }, () => {
      const record = { ...input, source: input.source || 'web', status: 'new', id: `l${Date.now()}`, createdAt: timestamp() };
      return demoSave(LS_KEYS.leads, SEED_LEADS, record);
    });
    return saved?.id ? normalizeRow(saved) : recordFrom(saved, 'lead', '/api/intake/leads');
  }
  async function updateLead(id, patch) {
    const input = { ...patch, id };
    const saved = await apiOrDemo('/api/leads', { method: 'PUT', body: JSON.stringify(input) }, () => {
      const list = localList(LS_KEYS.leads, SEED_LEADS);
      const index = list.findIndex((entry) => entry.id === id);
      if (index < 0) throw new StorageError('No se encontró el lead que se quiere actualizar.', { code: 'not_found', status: 404 });
      list[index] = { ...list[index], ...patch, id, updatedAt: timestamp() };
      write(LS_KEYS.leads, list);
      return list[index];
    });
    return saved?.id ? normalizeRow(saved) : recordFrom(saved, 'lead', '/api/leads');
  }
  async function deleteLead(id) {
    const result = await apiOrDemo('/api/leads', { method: 'DELETE', body: JSON.stringify({ id }) }, () => {
      const list = localList(LS_KEYS.leads, SEED_LEADS);
      const index = list.findIndex((entry) => entry.id === id);
      if (index < 0) throw new StorageError('No se encontró el lead que se quiere eliminar.', { code: 'not_found', status: 404 });
      const deleted = list.splice(index, 1)[0]; write(LS_KEYS.leads, list); return { ok: true, lead: deleted };
    });
    if (result?.lead?.id) return normalizeRow(result.lead);
    if (result?.id) return normalizeRow(result);
    throw new StorageError('El servidor no confirmó el lead eliminado.', { code: 'invalid_response', endpoint: '/api/leads', payload: result });
  }

  async function getAppointments() {
    return apiOrDemo('/api/appointments', {}, () => localList(LS_KEYS.appointments, SEED_APPOINTMENTS)).then((data) => Array.isArray(data) ? data.map(normalizeRow) : arrayFrom(data, '/api/appointments'));
  }
  function ensureAppointmentSuccess(payload, endpoint) {
    if (payload?.ok === false) throw new StorageError(payload.error || 'No se pudo guardar la cita.', { code: payload.error || 'save_failed', status: payload.status, endpoint, payload });
    const record = recordFrom(payload, 'appointment', endpoint);
    return { ok: true, appointment: record };
  }
  async function saveAppointment(appointment) {
    const input = { ...appointment };
    const updating = Boolean(input.id);
    const endpoint = '/api/appointments';
    const saved = await apiOrDemo(endpoint, { method: updating ? 'PUT' : 'POST', body: JSON.stringify(input) }, () => {
      const list = localList(LS_KEYS.appointments, SEED_APPOINTMENTS);
      const current = updating ? list.find((entry) => String(entry.id) === String(input.id)) : null;
      if (updating && !current) throw new StorageError('No se encontró la cita que se quiere actualizar.', { code: 'not_found', status: 404 });
      const status = input.status || current?.status || 'pending';
      if (current) {
        const allowed = { pending: ['pending', 'confirmed', 'cancelled'], confirmed: ['confirmed', 'completed', 'cancelled'], completed: ['completed'], cancelled: ['cancelled'] };
        if (!allowed[current.status]?.includes(status)) throw new StorageError('Transición de estado de cita no permitida.', { code: 'invalid_status_transition', status: 400 });
        const moved = (input.date || current.date) !== current.date || (input.slot || current.slot) !== current.slot || (input.location || current.location || '') !== (current.location || '');
        if (current.status === 'confirmed' && status === 'pending' && !moved) throw new StorageError('Reprogramar una cita confirmada requiere cambiar fecha, hora o sede.', { code: 'invalid_status_transition', status: 400 });
      }
      const record = { ...(current || {}), ...input, id: input.id || `a${Date.now()}`, createdAt: current?.createdAt || input.createdAt || timestamp(), status: updating ? status : 'pending' };
      if (updating) record.updatedAt = timestamp();
      const conflict = list.find((entry) => entry.id !== record.id && entry.status !== 'cancelled' && entry.date === record.date && entry.slot === record.slot && (entry.location || '') === (record.location || ''));
      if (conflict) throw new StorageError('La franja ya está ocupada.', { code: 'slot_taken', status: 409, conflict: true });
      demoSave(LS_KEYS.appointments, SEED_APPOINTMENTS, record);
      return record;
    });
    const result = ensureAppointmentSuccess(saved, endpoint);
    if (!updating) { event('appointment.created', { apptId: result.appointment.id }); runAutomationsFor('appointment.created', result.appointment); }
    return result;
  }
  async function savePublicAppointment(appointment) {
    const input = { ...appointment };
    const endpoint = '/api/intake/appointments';
    const saved = await apiOrDemo(endpoint, { method: 'POST', body: JSON.stringify(input) }, () => {
      if (input.consent !== true) throw new StorageError('Se requiere aceptar la política de privacidad para enviar la solicitud.', { code: 'consent_required', status: 400 });
      const list = localList(LS_KEYS.appointments, SEED_APPOINTMENTS);
      const now = timestamp();
      const { consent, ...appointmentData } = input;
      const record = { ...appointmentData, id: `a${Date.now()}`, consentGiven: true, consentAt: now, status: 'pending', createdAt: now };
      const conflict = list.find((entry) => entry.status !== 'cancelled' && entry.date === record.date && entry.slot === record.slot && (entry.location || '') === (record.location || ''));
      if (conflict) throw new StorageError('La franja ya está ocupada.', { code: 'slot_taken', status: 409, conflict: true });
      demoSave(LS_KEYS.appointments, SEED_APPOINTMENTS, record);
      return record;
    });
    return ensureAppointmentSuccess(saved, endpoint).appointment;
  }
  async function cancelAppointment(id, reason) {
    const result = await saveAppointment({ id, status: 'cancelled', cancelReason: reason || '' });
    return result.appointment;
  }
  async function rescheduleAppointment(id, date, slot) {
    const current = (await getAppointments()).find((entry) => entry.id === id);
    if (!current) throw new StorageError('No se encontró la cita que se quiere reprogramar.', { code: 'not_found', status: 404 });
    const result = await saveAppointment({ ...current, date, slot, status: 'pending' });
    return result;
  }

  // Demo-only features without server endpoints. They never initialize or persist PII outside local demo.
  function requireLocalDemo(name) { if (!isLocalDemo()) throw new StorageError(`${name} solo está disponible en el modo demo local.`, { code: 'demo_only' }); }
  function getAutomations() { requireLocalDemo('Automatizaciones'); return read(LS_KEYS.automations, SEED_AUTOMATIONS); }
  function saveAutomation(automation) { requireLocalDemo('Automatizaciones'); const list = getAutomations().filter((item) => item.id !== automation.id); list.push(automation); write(LS_KEYS.automations, list); return automation; }
  function getAutomationLogs() { requireLocalDemo('Automatizaciones'); return read(LS_KEYS.automationLogs, []); }
  function runAutomationsFor(trigger, payload) {
    if (!isLocalDemo()) return;
    const automations = getAutomations().filter((item) => item.enabled && item.trigger === trigger);
    const logs = getAutomationLogs();
    const reference = payload && typeof payload === 'object' ? { leadId: payload.leadId || '', appointmentId: payload.apptId || payload.appointmentId || '' } : {};
    automations.forEach((automation) => { automation.lastRun = timestamp(); logs.unshift({ id: `log${Date.now()}`, automationId: automation.id, automationName: automation.name, trigger, action: automation.action, reference, outcome: 'simulated', simulated: true, at: automation.lastRun, ok: true }); });
    write(LS_KEYS.automationLogs, logs.slice(0, 200)); write(LS_KEYS.automations, getAutomations());
  }
  function logEvent(value) { if (!isLocalDemo()) return; const record = { ...value, at: value.at || timestamp() }; const events = read(LS_KEYS.events, []); events.unshift(record); write(LS_KEYS.events, events.slice(0, 1000)); }
  function getEvents() { requireLocalDemo('Analítica'); return read(LS_KEYS.events, []); }
  function getSettings() { requireLocalDemo('Configuración'); return read(LS_KEYS.settings, { demoMode: true }); }
  function saveSettings(settings) { requireLocalDemo('Configuración'); write(LS_KEYS.settings, settings); }
  function getUsers() { requireLocalDemo('Usuarios'); return read(LS_KEYS.users, SEED_USERS); }
  function saveUser(user) { requireLocalDemo('Usuarios'); const value = { ...user, id: user.id || `u${Date.now()}` }; const list = getUsers().filter((item) => item.id !== value.id); list.push(value); write(LS_KEYS.users, list); return value; }
  function deleteUser(id) { requireLocalDemo('Usuarios'); write(LS_KEYS.users, getUsers().filter((item) => item.id !== id)); }
  function resetDemo() { requireLocalDemo('Restablecer demo'); write(LS_KEYS.leads, SEED_LEADS); write(LS_KEYS.appointments, SEED_APPOINTMENTS); write(LS_KEYS.automations, SEED_AUTOMATIONS); write(LS_KEYS.automationLogs, []); write(LS_KEYS.events, []); }

  initSeeds();
  global.DMEStorage = {
    isLocalDemo, login, session, logout,
    getLeads, saveLead, savePublicLead, updateLead, deleteLead,
    getAppointments, saveAppointment, savePublicAppointment, cancelAppointment, rescheduleAppointment,
    getAutomations, saveAutomation, getAutomationLogs, runAutomationsFor,
    logEvent, getEvents, getSettings, saveSettings, getUsers, saveUser, deleteUser, resetDemo,
    PIPELINE_STAGES: [
      { id: 'new', label: 'Nuevo' }, { id: 'contacted', label: 'Contactado' },
      { id: 'appointment_requested', label: 'Cita solicitada' }, { id: 'appointment_confirmed', label: 'Cita confirmada' },
      { id: 'consultation_done', label: 'Consulta realizada' }, { id: 'treatment_pending', label: 'Tratamiento pendiente' },
      { id: 'converted', label: 'Convertido' }, { id: 'lost', label: 'Perdido' },
    ],
    ROLES: ['administrator', 'manager', 'receptionist', 'marketing'],
  };
})(typeof window !== 'undefined' ? window : globalThis);

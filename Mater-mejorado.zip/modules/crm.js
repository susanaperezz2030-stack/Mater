/**
 * Dental Master Enterprise — Patient Lead Management CRM
 * Pipeline: new -> contacted -> appointment_requested -> appointment_confirmed ->
 * consultation_done -> treatment_pending -> converted -> lost
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const SOURCES = [
    { label: 'Web y canales digitales', items: [['web', 'Sitio web'], ['whatsapp', 'WhatsApp'], ['exit_intent', 'Exit-intent']] },
    { label: 'Publicidad', items: [['google_ads', 'Google Ads'], ['facebook_ads', 'Facebook Ads'], ['instagram', 'Instagram']] },
    { label: 'Contacto directo', items: [['phone', 'Teléfono']] },
    { label: 'Recomendación', items: [['referral', 'Recomendación']] },
  ];

  function sourceOptions(selected) {
    const found = SOURCES.some((group) => group.items.some(([value]) => value === selected));
    const custom = selected && !found ? `<option value="${esc(selected)}" selected>${esc(selected)} (otro)</option>` : '';
    return `${custom}${SOURCES.map((group) => `<optgroup label="${esc(group.label)}">${group.items.map(([value, label]) => `<option value="${value}" ${value === selected ? 'selected' : ''}>${label}</option>`).join('')}</optgroup>`).join('')}`;
  }
  function errorText(error, action) {
    const status = Number(error && (error.status || error.statusCode));
    if (status === 401 || status === 403) return 'Tu sesión no está autorizada o ha caducado. Vuelve a iniciar sesión.';
    if (status === 409 || error?.conflict) return 'El registro cambió en el servidor (409). Recarga los datos antes de volver a guardar.';
    if (status === 400) return 'El servidor rechazó los datos. Revisa los campos e inténtalo de nuevo.';
    return `No se pudo ${action}. El registro no se ha actualizado en esta vista; inténtalo de nuevo.`;
  }

  async function render(container, session) {
    if (!container) return;
    if (!session || !['administrator', 'manager'].includes(session.role)) {
      container.innerHTML = '<p class="dme-notice" role="alert">Inicia sesión con un rol autorizado para consultar y gestionar el CRM.</p>';
      return;
    }
    let leads;
    try {
      leads = await S.getLeads();
      if (!Array.isArray(leads)) throw new Error('invalid_leads_response');
    } catch (error) {
      container.innerHTML = '<div class="dme-notice" role="alert"></div>';
      container.querySelector('.dme-notice').textContent = errorText(error, 'cargar los leads');
      return;
    }
    const stages = S.PIPELINE_STAGES || [];
    const localDemo = typeof S.isLocalDemo === 'function' && S.isLocalDemo();

    container.innerHTML = `
      <div class="crm-toolbar">
        <input type="search" id="crmSearch" class="dme-input" placeholder="Buscar por nombre, teléfono o email..." aria-label="Buscar leads">
        <select id="crmStageFilter" class="dme-select" aria-label="Filtrar por estado"><option value="">Todos los estados</option>${stages.map((s) => `<option value="${esc(s.id)}">${esc(s.label)}</option>`).join('')}</select>
        <select id="crmSourceFilter" class="dme-select" aria-label="Filtrar por origen"><option value="">Todos los orígenes</option>${SOURCES.map((group) => `<optgroup label="${esc(group.label)}">${group.items.map(([value, label]) => `<option value="${value}">${label}</option>`).join('')}</optgroup>`).join('')}</select>
        <button id="crmNewBtn" class="dme-btn dme-btn-primary">+ Nuevo lead</button>
        <button id="crmExportBtn" class="dme-btn dme-btn-ghost">Exportar CSV</button>
        ${localDemo ? '<button id="crmResetBtn" class="dme-btn dme-btn-ghost" title="Restaura los datos de demostración">Datos demo</button>' : ''}
      </div>
      <div id="crmFeedback" class="dme-notice" role="status" hidden></div>
      <div class="crm-kpis" id="crmKpis"></div>
      <div class="crm-tabs"><button class="crm-tab active" data-view="pipeline">Canalización</button><button class="crm-tab" data-view="table">Listado</button></div>
      <div id="crmPipelineView" class="crm-pipeline"></div>
      <div id="crmTableView" class="crm-table-wrap" style="display:none"></div>
      <p class="crm-notice"><small><strong>Aviso de privacidad:</strong> este CRM contiene datos de contacto y marketing. No almacenes información clínica sensible; los datos de salud deben gestionarse en un sistema independiente adecuado a la normativa aplicable.</small></p>
      <div id="crmModal" class="dme-modal" aria-hidden="true"></div>`;

    function notify(message, isError = false) {
      const node = container.querySelector('#crmFeedback');
      if (!node) return;
      node.hidden = !message;
      node.textContent = message || '';
      node.setAttribute('role', isError ? 'alert' : 'status');
    }
    function filterLeads(list) {
      const q = (container.querySelector('#crmSearch')?.value || '').trim().toLowerCase();
      const stage = container.querySelector('#crmStageFilter')?.value || '';
      const source = container.querySelector('#crmSourceFilter')?.value || '';
      return list.filter((l) => {
        if (q && ![l.name, l.phone, l.email, l.notes].join(' ').toLowerCase().includes(q)) return false;
        if (stage && l.status !== stage) return false;
        if (source && l.source !== source) return false;
        return true;
      });
    }
    function renderKpis(filtered) {
      const conv = filtered.filter((l) => l.status === 'converted').length;
      const rate = filtered.length ? Math.round((conv / filtered.length) * 100) : 0;
      container.querySelector('#crmKpis').innerHTML = `<div class="crm-kpi"><strong>${filtered.length}</strong><span>Leads totales</span></div><div class="crm-kpi"><strong>${filtered.filter((l) => l.status === 'new').length}</strong><span>Nuevos</span></div><div class="crm-kpi"><strong>${conv}</strong><span>Convertidos</span></div><div class="crm-kpi"><strong>${rate}%</strong><span>Tasa de conversión</span></div>`;
    }
    function renderPipeline(filtered) {
      container.querySelector('#crmPipelineView').innerHTML = stages.map((s) => {
        const inStage = filtered.filter((l) => l.status === s.id);
        return `<div class="crm-col" data-stage="${esc(s.id)}"><div class="crm-col-head"><strong>${esc(s.label)}</strong><span class="crm-count">${inStage.length}</span></div><div class="crm-col-body">${inStage.map((l) => `<article class="crm-card" data-lead-id="${esc(l.id)}"><div class="crm-card-title">${esc(l.name)}</div><div class="crm-card-meta"><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></div><div class="crm-card-tags"><span class="crm-tag">${esc(l.treatment || '—')}</span><span class="crm-tag crm-tag-src">${esc(l.source || '—')}</span></div>${l.followUp ? `<div class="crm-followup"><small>Seguimiento:</small> ${esc(l.followUp)}</div>` : ''}<div class="crm-card-foot"><small>Responsable: ${esc(l.assignee || '—')}</small><button class="crm-card-btn js-crm-edit" data-id="${esc(l.id)}">Ver</button></div></article>`).join('')}</div></div>`;
      }).join('');
    }
    function renderTable(filtered) {
      container.querySelector('#crmTableView').innerHTML = `<table class="dme-table"><thead><tr><th>Nombre</th><th>Teléfono</th><th>Email</th><th>Tratamiento</th><th>Origen</th><th>Estado</th><th>Responsable</th><th>Seguimiento</th><th></th></tr></thead><tbody>${filtered.map((l) => `<tr><td><strong>${esc(l.name)}</strong></td><td><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></td><td>${esc(l.email || '—')}</td><td>${esc(l.treatment || '—')}</td><td>${esc(l.source || '—')}</td><td><span class="dme-badge">${esc(stages.find((s) => s.id === l.status)?.label || l.status)}</span></td><td>${esc(l.assignee || '—')}</td><td>${esc(l.followUp || '—')}</td><td><button class="dme-btn dme-btn-xs js-crm-edit" data-id="${esc(l.id)}">Ver</button></td></tr>`).join('')}</tbody></table>`;
    }
    function refresh() {
      const filtered = filterLeads(leads);
      renderKpis(filtered);
      renderPipeline(filtered);
      renderTable(filtered);
    }
    function exportCsv() {
      const filtered = filterLeads(leads);
      const headers = ['id', 'name', 'phone', 'email', 'treatment', 'source', 'status', 'assignee', 'followUp', 'notes', 'createdAt'];
      const rows = filtered.map((l) => headers.map((h) => `"${String(l[h] ?? '').replace(/"/g, '""')}"`).join(','));
      const blob = new Blob([headers.join(',') + '\n' + rows.join('\n')], { type: 'text/csv;charset=utf-8' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `leads-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    }
    function openModal(html) { const modal = container.querySelector('#crmModal'); modal.innerHTML = html; modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false'); }
    function closeModal() { const modal = container.querySelector('#crmModal'); modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); }
    function assertWrite(result) {
      if (result === null || result === false || result?.ok === false) throw new Error('write_rejected');
      return result;
    }
    function showModalError(form, error, action) {
      let message = form.querySelector('.crm-form-error');
      if (!message) { message = document.createElement('p'); message.className = 'crm-form-error dme-notice'; message.setAttribute('role', 'alert'); form.prepend(message); }
      message.textContent = errorText(error, action);
    }
    function openLead(id) {
      const lead = leads.find((x) => String(x.id) === String(id));
      if (!lead) return;
      openModal(`<div class="dme-modal-card"><div class="dme-modal-head"><h3>Lead · ${esc(lead.name)}</h3><button class="dme-close" id="crmClose">×</button></div><form id="crmForm" class="dme-form">
        <div class="dme-row"><label>Nombre<input name="name" value="${esc(lead.name)}" class="dme-input" required></label><label>Teléfono<input name="phone" value="${esc(lead.phone)}" class="dme-input" required></label></div>
        <div class="dme-row"><label>Correo electrónico<input type="email" name="email" value="${esc(lead.email)}" class="dme-input"></label><label>Origen por categoría<select name="source" class="dme-select">${sourceOptions(lead.source)}</select></label></div>
        <div class="dme-row"><label>Tratamiento<input name="treatment" value="${esc(lead.treatment)}" class="dme-input"></label><label>Estado<select name="status" class="dme-select">${stages.map((s) => `<option value="${esc(s.id)}" ${lead.status === s.id ? 'selected' : ''}>${esc(s.label)}</option>`).join('')}</select></label></div>
        <label>Seguimiento<input type="date" name="followUp" value="${esc(lead.followUp)}" class="dme-input"></label>
        <label>Notas internas<textarea name="notes" rows="3" class="dme-input">${esc(lead.notes)}</textarea></label>
        <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar</button><button type="button" id="crmDeleteBtn" class="dme-btn dme-btn-danger">Eliminar</button></div>
      </form></div>`);
      container.querySelector('#crmClose').onclick = closeModal;
      const form = container.querySelector('#crmForm');
      form.onsubmit = async (e) => {
        e.preventDefault();
        const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
        const data = Object.fromEntries(new FormData(form));
        try {
          assertWrite(await S.updateLead(lead.id, data));
          Object.assign(lead, data);
          closeModal(); refresh(); notify('Cambios guardados.');
        } catch (error) {
          showModalError(form, error, 'guardar los cambios');
          submit.disabled = false;
        }
      };
      container.querySelector('#crmDeleteBtn').onclick = async () => {
        if (!confirm('¿Eliminar este lead?')) return;
        const button = container.querySelector('#crmDeleteBtn'); button.disabled = true;
        try {
          assertWrite(await S.deleteLead(lead.id));
          const index = leads.findIndex((x) => String(x.id) === String(lead.id)); if (index >= 0) leads.splice(index, 1);
          closeModal(); refresh(); notify('Lead eliminado.');
        } catch (error) {
          showModalError(form, error, 'eliminar el lead');
          button.disabled = false;
        }
      };
    }
    function openNew() {
      openModal(`<div class="dme-modal-card"><div class="dme-modal-head"><h3>Nuevo lead</h3><button class="dme-close" id="crmClose">×</button></div><form id="crmNewForm" class="dme-form">
        <div class="dme-row"><label>Nombre *<input name="name" class="dme-input" required></label><label>Teléfono *<input name="phone" class="dme-input" required></label></div>
        <div class="dme-row"><label>Correo electrónico<input type="email" name="email" class="dme-input"></label><label>Origen por categoría<select name="source" class="dme-select">${sourceOptions('phone')}</select></label></div>
        <label>Tratamiento<input name="treatment" class="dme-input"></label><label>Notas internas<textarea name="notes" rows="3" class="dme-input"></textarea></label>
        <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Crear</button></div></form></div>`);
      container.querySelector('#crmClose').onclick = closeModal;
      const form = container.querySelector('#crmNewForm');
      form.onsubmit = async (e) => {
        e.preventDefault();
        const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
        try {
          const created = assertWrite(await S.saveLead(Object.fromEntries(new FormData(form))));
          if (!created || typeof created !== 'object' || !created.id) throw new Error('missing_saved_lead');
          leads.unshift(created); closeModal(); refresh(); notify('Lead creado.');
        } catch (error) {
          showModalError(form, error, 'crear el lead');
          submit.disabled = false;
        }
      };
    }

    container.querySelector('#crmPipelineView').onclick = (e) => { const button = e.target.closest('.js-crm-edit'); if (button) openLead(button.dataset.id); };
    container.querySelector('#crmTableView').onclick = (e) => { const button = e.target.closest('.js-crm-edit'); if (button) openLead(button.dataset.id); };
    container.querySelector('#crmSearch').oninput = refresh;
    container.querySelector('#crmStageFilter').onchange = refresh;
    container.querySelector('#crmSourceFilter').onchange = refresh;
    container.querySelector('#crmExportBtn').onclick = exportCsv;
    container.querySelector('#crmNewBtn').onclick = openNew;
    if (localDemo) container.querySelector('#crmResetBtn').onclick = () => { S.resetDemo(); location.reload(); };
    container.querySelectorAll('.crm-tab').forEach((tab) => {
      tab.onclick = () => {
        container.querySelectorAll('.crm-tab').forEach((x) => x.classList.remove('active'));
        tab.classList.add('active');
        const view = tab.dataset.view;
        container.querySelector('#crmPipelineView').style.display = view === 'pipeline' ? 'grid' : 'none';
        container.querySelector('#crmTableView').style.display = view === 'table' ? 'block' : 'none';
      };
    });
    refresh();
  }

  global.DMECRM = { render };
})(typeof window !== 'undefined' ? window : globalThis);

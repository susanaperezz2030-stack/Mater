import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(projectRoot, 'dist');
const excludedDirectories = new Set([
  'dist', 'node_modules', '.git', '.wrangler', 'functions', 'db', 'tests', 'docs', 'config', 'scripts',
]);
const publishableExtensions = new Set([
  '.html', '.css', '.js', '.json', '.txt', '.svg', '.xml', '.webmanifest',
]);
const publishableRootFiles = new Set(['_headers', '_redirects']);

const pages = [
  {
    file: 'servicios.html', slug: 'servicios', section: 'servicios', labelEs: 'Servicios', labelEn: 'Treatments',
    titleEs: 'RHD Dental Studio — Tratamientos dentales en Austin', titleEn: 'RHD Dental Studio — Dental treatments in Austin',
    descriptionEs: 'Conoce los tratamientos y especialidades dentales de RHD Dental Studio en Austin.',
    descriptionEn: 'Explore dental treatments and specialties at RHD Dental Studio in Austin.',
  },
  {
    file: 'casos.html', slug: 'casos', section: 'galeria', labelEs: 'Casos reales', labelEn: 'Patient cases',
    titleEs: 'RHD Dental Studio — Casos y resultados dentales', titleEn: 'RHD Dental Studio — Dental cases and results',
    descriptionEs: 'Explora casos dentales y resultados de pacientes de RHD Dental Studio.',
    descriptionEn: 'Explore patient cases and dental results from RHD Dental Studio.',
  },
  {
    file: 'equipo.html', slug: 'equipo', section: 'doctora', labelEs: 'Equipo médico', labelEn: 'Our team',
    titleEs: 'RHD Dental Studio — Equipo médico en Austin', titleEn: 'RHD Dental Studio — Dental team in Austin',
    descriptionEs: 'Conoce al equipo médico y la experiencia clínica de RHD Dental Studio.',
    descriptionEn: 'Meet the clinicians and learn about the experience at RHD Dental Studio.',
  },
  {
    file: 'financiacion.html', slug: 'financiacion', section: 'financiamiento', labelEs: 'Financiación', labelEn: 'Financing',
    titleEs: 'RHD Dental Studio — Financiación de tratamientos', titleEn: 'RHD Dental Studio — Treatment financing',
    descriptionEs: 'Consulta las opciones de financiación y calcula una cuota orientativa para tu tratamiento.',
    descriptionEn: 'Review financing options and estimate a monthly payment for your treatment.',
  },
  {
    file: 'opiniones.html', slug: 'opiniones', section: 'opiniones', labelEs: 'Opiniones', labelEn: 'Reviews',
    titleEs: 'RHD Dental Studio — Opiniones de pacientes', titleEn: 'RHD Dental Studio — Patient reviews',
    descriptionEs: 'Lee testimonios y opiniones de pacientes de RHD Dental Studio.',
    descriptionEn: 'Read testimonials and patient reviews for RHD Dental Studio.',
  },
  {
    file: 'preguntas.html', slug: 'preguntas', section: 'faq', labelEs: 'Preguntas frecuentes', labelEn: 'Frequently asked questions',
    titleEs: 'RHD Dental Studio — Preguntas frecuentes', titleEn: 'RHD Dental Studio — Frequently asked questions',
    descriptionEs: 'Resuelve tus dudas sobre tratamientos, citas, seguros y atención en RHD Dental Studio.',
    descriptionEn: 'Find answers about treatments, appointments, insurance and care at RHD Dental Studio.',
  },
  {
    file: 'contacto.html', slug: 'contacto', section: 'contacto', labelEs: 'Contacto y ubicación', labelEn: 'Contact & location',
    titleEs: 'RHD Dental Studio — Contacto, ubicación y horarios', titleEn: 'RHD Dental Studio — Contact, location and hours',
    descriptionEs: 'Consulta la dirección, los horarios y las formas de contactar a RHD Dental Studio.',
    descriptionEn: 'Find the address, opening hours and contact details for RHD Dental Studio.',
  },
];

const escapeHtml = (value) => String(value)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#39;');
const escapeAttr = escapeHtml;
const sourceIndex = fs.readFileSync(path.join(projectRoot, 'index.html'), 'utf8');
if (!/<body\b[^>]*data-page="home"/.test(sourceIndex)) {
  throw new Error('index.html must declare data-page="home" before generating section pages.');
}

for (const page of pages) {
  const attrs = {
    'data-page': page.slug,
    'data-page-path': `/${page.slug}`,
    'data-page-title-es': page.titleEs,
    'data-page-title-en': page.titleEn,
    'data-page-description-es': page.descriptionEs,
    'data-page-description-en': page.descriptionEn,
  };
  let html = sourceIndex.replace(/<body\b([^>]*)>/i, (_match, existing) => {
    const clean = existing.replace(/\sdata-(?:page|page-path|page-title-es|page-title-en|page-description-es|page-description-en)="[^"]*"/g, '');
    const additions = Object.entries(attrs).map(([key, value]) => ` ${key}="${escapeAttr(value)}"`).join('');
    return `<body${clean}${additions}>`;
  });
  html = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeHtml(page.titleEs)}</title>`);
  html = html.replace(/<meta name="description" content="[^"]*">/i, `<meta name="description" content="${escapeAttr(page.descriptionEs)}">`);

  const heroMatch = html.match(/<section class="hero" id="inicio">[\s\S]*?<\/section>/i);
  if (!heroMatch) throw new Error(`Home hero section not found while generating ${page.file}.`);
  html = html.replace(heroMatch[0], '');

  const intro = `
    <header class="page-intro" aria-labelledby="pageIntroTitle">
      <nav class="page-breadcrumb" aria-label="Breadcrumb">
        <ol>
          <li><a href="index.html" data-page-link="home"><span class="i18n-es">Inicio</span><span class="i18n-en">Home</span></a></li>
          <li><span aria-current="page"><span class="i18n-es">${escapeHtml(page.labelEs)}</span><span class="i18n-en">${escapeHtml(page.labelEn)}</span></span></li>
        </ol>
      </nav>
      <h1 id="pageIntroTitle"><span class="i18n-es">${escapeHtml(page.labelEs)}</span><span class="i18n-en">${escapeHtml(page.labelEn)}</span></h1>
      <p class="page-intro-description"><span class="i18n-es">${escapeHtml(page.descriptionEs)}</span><span class="i18n-en">${escapeHtml(page.descriptionEn)}</span></p>
    </header>
`;
  html = html.replace(/<main>\s*/, `<main>${intro}`);
  fs.writeFileSync(path.join(projectRoot, page.file), html);
}

fs.rmSync(outputDir, { recursive: true, force: true });
fs.mkdirSync(outputDir, { recursive: true });

for (const entry of fs.readdirSync(projectRoot, { withFileTypes: true })) {
  if (entry.name.startsWith('.') || excludedDirectories.has(entry.name)) continue;

  const source = path.join(projectRoot, entry.name);
  const destination = path.join(outputDir, entry.name);

  if (entry.isDirectory()) {
    if (entry.name === 'assets' || entry.name === 'modules') {
      fs.cpSync(source, destination, { recursive: true });
    }
    continue;
  }

  const extension = path.extname(entry.name).toLowerCase();
  if (publishableExtensions.has(extension) || publishableRootFiles.has(entry.name)) {
    fs.copyFileSync(source, destination);
  }
}

const required = [
  'index.html', 'admin.html', '_headers', '_redirects', 'multipage.css', 'manus-routes.json',
  ...pages.map((page) => page.file),
];
for (const file of required) {
  if (!fs.existsSync(path.join(outputDir, file))) throw new Error(`Cloudflare Pages asset missing from dist: ${file}`);
}

console.log(`Prepared ${outputDir} with ${pages.length + 1} public pages; Pages Functions remain in ${path.join(projectRoot, 'functions')}.`);

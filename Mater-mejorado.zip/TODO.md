# TODO — Mejora integral de Dental Master/Mater

## A. Diseño, navegación, móvil y accesibilidad

- [x] Las páginas interiores `servicios.html`, `casos.html`, `equipo.html`, `financiacion.html`, `opiniones.html`, `preguntas.html` y `contacto.html` muestran un título y una introducción específicos; solo la portada conserva el hero de marca completo, y el contenido principal aparece sin repetir el hero genérico.
- [x] La navegación y los estilos responsive tienen reglas coherentes; los controles táctiles alcanzan al menos 44 × 44 px en vistas móviles relevantes, y el contenido no queda oculto por barras fijas.
- [x] Los filtros se exponen como grupo de botones con nombre accesible y `aria-pressed` sincronizado, o como pestañas completas con roles, estado y teclado; no se deja un `tablist` incompleto.
- [x] El diálogo de cita mueve el foco a un control al abrirse, contiene Tab/Shift+Tab, se cierra con Escape, devuelve el foco al disparador y comunica de forma accesible el paso actual. El E2E confirmó también la visibilidad inmediata necesaria para que el foco funcione.
- [x] Los enlaces de consulta por WhatsApp identifican el tratamiento; el comparador y demás controles interactivos tienen instrucciones/etiquetas útiles; se revisan orden de encabezados, contraste, foco visible y movimiento reducido.
- [x] Si JavaScript no monta tratamientos, casos, reseñas o FAQ, la página conserva contenido HTML mínimo o muestra un estado de error útil en vez de dejar zonas vacías.

## B. Fiabilidad de citas, CRM y almacenamiento

- [x] El modo demo local se distingue explícitamente del modo con API; las respuestas HTTP fallidas `400`, `401`, `403`, `409` y `5xx` no se convierten silenciosamente en lecturas o escrituras locales presentadas como éxito.
- [x] Un `409` de horario ocupado no se muestra como reserva confirmada; el mensaje permite corregir/reintentar sin perder innecesariamente los datos del formulario. Validado en Chromium con los campos retenidos.
- [x] Una escritura API aceptada conserva los campos del registro y su identidad; una respuesta `{ok:true}` no reemplaza toda la cita, y el estado de guardado de la UI coincide con la respuesta real del servidor.
- [x] Los leads/citas existentes solo en D1 se pueden actualizar; campos SQL como `follow_up` y `created_at` se normalizan a `followUp` y `createdAt` al leer y escribir.
- [x] El alta pública de leads queda limitada a los valores aprobados por servidor; las actualizaciones CRM autenticadas validan lista de campos, longitudes y estados, y las pruebas distinguen ambos permisos.
- [x] Las transiciones de cita impiden confirmar citas completadas o revivir canceladas accidentalmente; fechas y zona horaria tienen una regla consistente y documentada.
- [x] La UI de automatizaciones no afirma que emails/SMS se enviaron cuando solo se registró una simulación; logs, identificadores y marcas temporales son correctos y las integraciones faltantes se indican explícitamente.
- [x] Con API activa, los datos personales no se duplican/usarán silenciosamente desde `localStorage`; el modo offline/demo sigue disponible solo cuando procede y la autorización de servidor sigue siendo obligatoria para recursos privados.
- [x] El formulario público ya no invita a ingresar síntomas o alergias; exige consentimiento sin preseleccionarlo y guarda `consent_given`/`consent_at`. Los registros antiguos permanecen sin consentimiento atribuido.

## C. Administración y seguridad

- [x] El login indica claramente que se usa correo electrónico y muestra mensajes comprensibles para credenciales incorrectas, API no disponible o autenticación sin configurar, sin filtrar secretos.
- [x] Pestañas y acciones visibles concuerdan con roles; los permisos reales siguen aplicándose y validándose en el servidor, incluso con una sesión cliente local manipulada.
- [x] El alta/baja local de usuarios no se presenta como gestión de cuentas de producción; queda limitada al modo demo, sin contraseña prellenada, y la guía indica cómo se configuran cuentas reales con hashes PBKDF2 en secretos protegidos.
- [x] Se endurecen validaciones de servidor y encabezados; la documentación CSP refleja las directivas realmente aplicadas y se documentan como pendientes los controles que requieren configuración externa (MFA, limitación de fuerza bruta y anti-spam/Turnstile).
- [x] Los datos semilla de CRM/agenda son sintéticos y neutros; no se incluyen datos reales de pacientes ni notas clínicas en el bundle público.

## D. Pruebas, documentación y entrega

- [x] Se añaden pruebas para errores API sin éxito falso, conflicto `409`, preservación de registros, normalización, permisos y transiciones de cita, dentro de la cobertura que el proyecto puede ejecutar localmente.
- [x] Se ejecutan las pruebas existentes y afectadas; los resultados locales simulados se distinguen de cualquier verificación de staging con D1/Cloudflare. Última suite completa: 69 pruebas de Functions, rutas/storage, asistente local y 39/39 E2E.
- [x] README y documentación de seguridad/despliegue describen sin contradicciones el modo demo, el origen real de las cuentas, límites de automatización, almacenamiento de datos y requisitos de publicación.
- [x] `dist/` se regenera desde las fuentes con el script del proyecto y mantiene consistencia de rutas y recursos.
- [x] El proyecto se empaqueta para entrega; no se despliega, no se cambian secretos/Cloudflare/D1 ni se publica en GitHub sin autorización posterior.

## Pendiente de operación real (no ejecutado)

- La migración `db/migrations/0003_appointment_consent.sql` se entrega, pero **no** se aplicó a ninguna D1. Para una base existente debe revisarse y aplicarse primero en staging con autorización y copia de seguridad.
- `pnpm run check:cloudflare` se bloquea correctamente porque la configuración local no contiene el binding D1 real `DB`. El proyecto indica sincronizar la configuración existente de Pages; no se hizo porque requeriría login/identificación de entorno y podría reemplazar configuración real. No se desplegó ni se modificó el repositorio remoto.
- Antes de producción configura la zona IANA real de la clínica tanto en `siteData.js > settings.timeZone` como en `CLINIC_TIME_ZONE`; UTC sigue siendo el fallback técnico.

import { verifySession } from './session.js';

const jsonError = (error, status) => new Response(JSON.stringify({ ok: false, error }), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
});
const roles = {
  '/api/leads': ['administrator', 'manager'],
  '/api/appointments': ['administrator', 'manager', 'receptionist'],
  '/api/automations': ['administrator', 'manager'],
  '/api/settings': ['administrator'],
};

export async function onRequestOptions({ request }) {
  const url = new URL(request.url);
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return jsonError('cross_origin_denied', 403);
  return new Response(null, { status: 204, headers: { Allow: 'GET, POST, PUT, DELETE, OPTIONS', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
}

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/$/, '');
  const method = request.method.toUpperCase();
  const response = async () => {
    const result = await context.next();
    const headers = new Headers(result.headers);
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('Cache-Control', 'no-store');
    headers.delete('Access-Control-Allow-Origin');
    headers.delete('Access-Control-Allow-Credentials');
    return new Response(result.body, { status: result.status, statusText: result.statusText, headers });
  };

  if (path === '/api/auth') {
    const origin = request.headers.get('Origin');
    if (['POST', 'DELETE'].includes(method) && origin && origin !== url.origin) return jsonError('cross_origin_denied', 403);
    if (request.headers.get('Sec-Fetch-Site') === 'cross-site') return jsonError('cross_origin_denied', 403);
    return response();
  }

  // Public forms may submit new contact requests/bookings; listing and changes stay private.
  const isPublicIntake = method === 'POST' && ['/api/leads', '/api/appointments'].includes(path);
  const origin = request.headers.get('Origin');
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
    if (origin && origin !== url.origin) return jsonError('cross_origin_denied', 403);
    if (request.headers.get('Sec-Fetch-Site') === 'cross-site') return jsonError('cross_origin_denied', 403);
  }
  if (isPublicIntake) return response();

  const requiredRoles = roles[path];
  if (!requiredRoles) return response();
  const cookieHeader = request.headers.get('Cookie') || '';
  const token = cookieHeader.split(';').map((part) => part.trim()).find((part) => part.startsWith('dme_session='))?.slice('dme_session='.length);
  const session = await verifySession(token, env.SESSION_SECRET);
  if (!session) return jsonError('authentication_required', 401);
  if (!requiredRoles.includes(session.role)) return jsonError('forbidden', 403);
  return response();
}

/** Public POST intake; administrative reads/updates are enforced by api/_middleware.js. */
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});
const SLOTS = new Set(['Mañana (09:00–14:00)', 'Tarde (14:00–18:00)', 'Última hora (18:00–20:00)']);
const text = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const isIsoDate = (value) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
};
const isPhone = (value) => /^[+\d() .-]{7,30}$/.test(value);
const isEmail = (value) => !value || (value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value));
const uniqueConflict = (error) => /unique constraint|idx_appt_unique_active_slot|constraint failed/i.test(String(error?.message || error));

export async function onRequestGet({ env }) {
  if (!env.DB) return json([]);
  const { results } = await env.DB.prepare('SELECT * FROM appointments ORDER BY datetime(created_at) DESC').all();
  return json(results);
}

export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const appointment = {
    service: text(body.service, 80), specialist: text(body.specialist, 120), location: text(body.location, 80),
    date: text(body.date, 10), slot: text(body.slot, 60), name: text(body.name, 120), phone: text(body.phone, 30),
    email: text(body.email, 254), notes: text(body.notes, 500),
  };
  if (!appointment.service || !appointment.name || !isPhone(appointment.phone) || !isIsoDate(appointment.date) || !SLOTS.has(appointment.slot) || !isEmail(appointment.email)) {
    return json({ ok: false, error: 'invalid_appointment' }, 400);
  }
  if (appointment.date < new Date().toISOString().slice(0, 10)) return json({ ok: false, error: 'date_in_past' }, 400);
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  if (env.DB) {
    const conflict = await env.DB.prepare(
      'SELECT id FROM appointments WHERE status <> ? AND date = ? AND slot = ? AND IFNULL(location, \'\') = ?'
    ).bind('cancelled', appointment.date, appointment.slot, appointment.location).first();
    if (conflict) return json({ ok: false, conflict: true }, 409);
    try {
      await env.DB.prepare(
        'INSERT INTO appointments (id, service, specialist, location, date, slot, name, phone, email, notes, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      ).bind(id, appointment.service, appointment.specialist, appointment.location, appointment.date, appointment.slot, appointment.name, appointment.phone, appointment.email, appointment.notes, 'pending', now).run();
    } catch (error) {
      if (uniqueConflict(error)) return json({ ok: false, conflict: true }, 409);
      throw error;
    }
  }
  return json({ id, ...appointment, status: 'pending', createdAt: now }, 201);
}

export async function onRequestPut({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const id = text(body.id, 100);
  const status = text(body.status, 20);
  const cancelReason = text(body.cancelReason, 300);
  const date = text(body.date, 10);
  const slot = text(body.slot, 60);
  if (!id || !['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) return json({ ok: false, error: 'invalid_update' }, 400);
  if (date && !isIsoDate(date)) return json({ ok: false, error: 'invalid_date' }, 400);
  if (slot && !SLOTS.has(slot)) return json({ ok: false, error: 'invalid_slot' }, 400);
  if (env.DB) {
    try {
      await env.DB.prepare(
        'UPDATE appointments SET status=?, cancel_reason=?, date=COALESCE(NULLIF(?, \'\'), date), slot=COALESCE(NULLIF(?, \'\'), slot), updated_at=datetime(\'now\') WHERE id=?'
      ).bind(status, cancelReason, date, slot, id).run();
    } catch (error) {
      if (uniqueConflict(error)) return json({ ok: false, conflict: true }, 409);
      throw error;
    }
  }
  return json({ ok: true });
}

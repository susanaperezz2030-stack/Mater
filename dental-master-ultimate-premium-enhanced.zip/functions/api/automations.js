/**
 * /functions/api/automations — GET rules/logs, POST run manual trigger
 */
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });
}

export async function onRequestGet({ env }) {
  if (env.DB) {
    const rules = await env.DB.prepare('SELECT * FROM automations ORDER BY name').all();
    const logs = await env.DB.prepare('SELECT * FROM automation_logs ORDER BY datetime(at) DESC LIMIT 100').all();
    return json({ rules: rules.results, logs: logs.results });
  }
  return json({ rules: [], logs: [] });
}

export async function onRequestPost({ request, env }) {
  const { trigger, payload } = await request.json().catch(() => ({}));
  const at = new Date().toISOString();
  if (env.DB && trigger) {
    const rules = await env.DB.prepare('SELECT * FROM automations WHERE enabled=1 AND trigger=?').bind(trigger).all();
    for (const r of rules.results || []) {
      await env.DB.prepare(
        'INSERT INTO automation_logs (id, automation_id, automation_name, trigger, action, payload, at, ok) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
      ).bind('log' + Date.now() + Math.random().toString(36).slice(2, 6), r.id, r.name, trigger, r.action, JSON.stringify(payload || {}), at).run();
    }
  }
  return json({ ok: true, at });
}

/**
 * /api/leads — GET list, POST create, PUT update, DELETE
 * Backed by Cloudflare D1 when binding DB is present; otherwise returns demo arrays.
 */
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
}

export async function onRequestGet({ env }) {
  if (env.DB) {
    const { results } = await env.DB.prepare('SELECT * FROM leads ORDER BY datetime(created_at) DESC').all();
    return json(results);
  }
  return json([]);
}

export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const clean = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
  const lead = {
    name: clean(body.name, 120), phone: clean(body.phone, 30), email: clean(body.email, 254),
    treatment: clean(body.treatment, 80), source: clean(body.source || 'web', 40), notes: clean(body.notes, 500),
  };
  if (!lead.name || !/^[+\d() .-]{7,30}$/.test(lead.phone) || (lead.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email))) {
    return json({ ok: false, error: 'invalid_lead' }, 400);
  }
  const id = crypto.randomUUID();
  const now = new Date().toISOString();
  if (env.DB) {
    await env.DB.prepare(
      'INSERT INTO leads (id, name, phone, email, treatment, source, status, notes, assignee, follow_up, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(id, lead.name, lead.phone, lead.email, lead.treatment, lead.source, 'new', lead.notes, '', '', now).run();
  }
  return json({ id, ...lead, status: 'new', createdAt: now }, 201);
}

export async function onRequestPut({ request, env }) {
  const b = await request.json().catch(() => ({}));
  if (env.DB && b.id) {
    await env.DB.prepare(
      'UPDATE leads SET name=?, phone=?, email=?, treatment=?, source=?, status=?, notes=?, assignee=?, follow_up=?, updated_at=datetime(\'now\') WHERE id=?'
    ).bind(b.name || '', b.phone || '', b.email || '', b.treatment || '', b.source || '', b.status || '', b.notes || '', b.assignee || '', b.followUp || '', b.id).run();
  }
  return json({ ok: true });
}

export async function onRequestDelete({ request, env }) {
  const b = await request.json().catch(() => ({}));
  if (env.DB && b.id) await env.DB.prepare('DELETE FROM leads WHERE id=?').bind(b.id).run();
  return json({ ok: true });
}

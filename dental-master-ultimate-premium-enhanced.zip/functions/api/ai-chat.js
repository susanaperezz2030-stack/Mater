/*
 * Legacy route retained only for backwards-compatible deployments.
 * The premium assistant now runs entirely in modules/ai-assistant.js.
 * No provider calls, API keys, or remote chat processing are performed here.
 */
function json(data, status = 410) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

export async function onRequestPost() {
  return json({ error: 'local_faq_assistant_enabled', message: 'Use the local FAQ assistant in the website.' });
}

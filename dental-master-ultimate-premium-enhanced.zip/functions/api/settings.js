/**
 * /functions/api/settings — GET/PUT clinic configuration overrides (KV or D1)
 */
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });
}

export async function onRequestGet({ env }) {
  if (env.KV) {
    const raw = await env.KV.get('settings', 'json');
    return json(raw || {});
  }
  if (env.DB) {
    const row = await env.DB.prepare('SELECT value FROM settings WHERE key=?').bind('clinic').first();
    return json(row ? JSON.parse(row.value) : {});
  }
  return json({});
}

export async function onRequestPut({ request, env }) {
  const b = await request.json().catch(() => ({}));
  if (env.KV) await env.KV.put('settings', JSON.stringify(b));
  if (env.DB) await env.DB.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').bind('clinic', JSON.stringify(b)).run();
  return json({ ok: true });
}

import { signSession } from './session.js';

const DEMO_USERS = [
  { id: 'u1', name: 'Admin', email: 'admin@clinic.com', pass: 'admin123', role: 'administrator' },
  { id: 'u2', name: 'Ana Gestora', email: 'manager@clinic.com', pass: 'demo123', role: 'manager' },
  { id: 'u3', name: 'Laura Recepción', email: 'recepcion@clinic.com', pass: 'demo123', role: 'receptionist' },
  { id: 'u4', name: 'Carlos Marketing', email: 'marketing@clinic.com', pass: 'demo123', role: 'marketing' },
];
const SESSION_SECONDS = 8 * 60 * 60;
const COOKIE_NAME = 'dme_session';
const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...headers },
});

function getUsers(env) {
  if (env.USERS) {
    try {
      const entries = JSON.parse(env.USERS);
      if (!Array.isArray(entries) || !entries.length) return null;
      if (entries.some((u) => !u || typeof u.id !== 'string' || typeof u.name !== 'string' || typeof u.email !== 'string' || !['administrator', 'manager', 'receptionist', 'marketing'].includes(u.role))) return null;
      if (entries.some((u) => typeof u.passwordHash !== 'string' || !u.passwordHash.startsWith('pbkdf2$'))) return null;
      return entries;
    } catch { return null; }
  }
  return env.DEMO_MODE === 'true' ? DEMO_USERS : null;
}

function decodeBase64url(text) {
  const normalized = text.replaceAll('-', '+').replaceAll('_', '/');
  const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
}
async function verifyPassword(password, encoded) {
  try {
    const [algorithm, iterationText, saltText, expectedText] = encoded.split('$');
    const iterations = Number(iterationText);
    if (algorithm !== 'pbkdf2' || !Number.isInteger(iterations) || iterations < 100000 || iterations > 1000000) return false;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
    const result = new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: decodeBase64url(saltText), iterations }, key, 256));
    const expected = decodeBase64url(expectedText);
    if (result.length !== expected.length) return false;
    let difference = 0;
    for (let i = 0; i < result.length; i += 1) difference |= result[i] ^ expected[i];
    return difference === 0;
  } catch { return false; }
}

function sessionCookie(token, maxAge) {
  return `${COOKIE_NAME}=${token}; Path=/api; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Strict`;
}
export async function onRequestPost({ request, env }) {
  const body = await request.json().catch(() => ({}));
  const email = body && typeof body.email === 'string' ? body.email : '';
  const pass = body && typeof body.pass === 'string' ? body.pass : '';
  const configuredUsers = getUsers(env);
  if (!configuredUsers || typeof env.SESSION_SECRET !== 'string' || env.SESSION_SECRET.length < 32) {
    return json({ ok: false, error: 'auth_not_configured' }, 503);
  }
  const user = configuredUsers.find((u) => u.email.toLowerCase() === (email || '').trim().toLowerCase());
  const passwordOK = user && (user.passwordHash
    ? await verifyPassword(String(pass || ''), user.passwordHash)
    : env.DEMO_MODE === 'true' && typeof user.pass === 'string' && user.pass === pass);
  if (!user || !passwordOK) return json({ ok: false, error: 'invalid_credentials' }, 401);
  const issuedAt = Math.floor(Date.now() / 1000);
  const safeUser = { id: user.id, name: user.name, email: user.email, role: user.role, iat: issuedAt, exp: issuedAt + SESSION_SECONDS };
  const token = await signSession(safeUser, env.SESSION_SECRET);
  return json({ ok: true, session: { id: safeUser.id, name: safeUser.name, email: safeUser.email, role: safeUser.role, expiresAt: safeUser.exp } }, 200, {
    'Set-Cookie': sessionCookie(token, SESSION_SECONDS),
  });
}

export async function onRequestDelete({ env }) {
  return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0) });
}

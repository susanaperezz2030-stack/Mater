/**
 * =====================================================================
 *  PLANTILLA MAESTRA PREMIUM — DENTAL CLINIC MASTER TEMPLATE
 *  Archivo de Configuración Centralizada / Centralized Configuration
 * =====================================================================
 *
 *  CÓMO USAR / HOW TO USE:
 *  Edita los valores entre corchetes datos de ejemplo con los datos reales de tu
 *  cliente y guarda. Todo el sitio se actualizará automáticamente.
 *  Para más detalles, consulta EDITABLE-FIELDS.md
 *
 *  Edit the values inside brackets demo data with your client's real data
 *  and save. The entire site will update automatically.
 *  For full details, see EDITABLE-FIELDS.md
 * =====================================================================
 */

const SITE_CONFIG = window.SITE_CONFIG = {

  schemaVersion: '1.0',

  // -------------------------------------------------------------------
  // 1. DATOS DE LA CLÍNICA / CLINIC DATA
  // -------------------------------------------------------------------
  clinic: {
    // Nombre de la clínica que aparecerá en el logo, título y textos
    name: 'RHD Dental Studio',
    nameShort: 'RHD DENTAL STUDIO', // nombre de demostración para la plantilla
    namePrefix: 'Clínica Dental',  // para el texto pequeño sobre el logo

    tagline: {
      es: 'La odontología de alta gama que tu sonrisa merece.',
      en: 'High-end dentistry your smile deserves.',
    },
    subtagline: {
      es: 'Diseño de sonrisas, implantes y estética dental con tecnología de última generación en Austin.',
      en: 'Smile design, implants and cosmetic dentistry with next-generation technology in Austin.',
    },
    description: {
      es: 'Una clínica dental boutique donde la precisión médica se une a la experiencia de lujo. Resultados naturales, mínimamente invasivos y personalizados.',
      en: 'A boutique dental clinic where medical precision meets a luxury experience. Natural, minimally invasive, personalized results.',
    },
    yearFounded: '2016',
    license: 'Lic. Sanitaria #TX-DENT-20418',
    city: 'Austin',
    country: 'Estados Unidos',
  },

  // -------------------------------------------------------------------
  // 2. CONTACTO Y LOCALIZACIÓN / CONTACT & LOCATION
  // -------------------------------------------------------------------
  contact: {
    phone: '+15551234567',             // sin espacios ni símbolos: +15551234567
    phoneFormatted: '+1 (555) 123-4567', // ej. "(305) 555-1234"
    phone2: '',                           // opcional: teléfono secundario
    email: 'hello@rhddentalstudio.com',             // ej. contacto@tuclinica.com
    address: '123 Congress Avenue, Suite 800, Austin, TX 78701',      // ej. Av. Las Américas 450, Piso 3, Miami, FL
    addressLine2: 'Austin, TX 78701',
    // Enlace de Google Maps para el botón "Cómo llegar"
    mapsUrl: 'https://maps.google.com/?q=RHD+Dental+Studio+Austin+TX', // ej. https://maps.app.goo.gl/tu-clinica
    // URL embed para el iframe del mapa (Google Maps > Compartir > Insertar)
    mapsEmbedUrl: 'https://www.google.com/maps?q=123+Congress+Avenue,+Austin,+TX+78701&output=embed',
  },

  // Multi-ubicación opcional (si tu clínica tiene varias sedes, define cada una)
  locations: [
    // { id: 'sede-1', name: 'RHD Dental Studio — Austin', phone: '+1 (555) 123-4567', address: '123 Congress Avenue, Suite 800, Austin, TX 78701', city: 'Austin', mapsUrl: 'https://maps.google.com/?q=RHD+Dental+Studio+Austin+TX' },
  ],

  // -------------------------------------------------------------------
  // 3. WHATSAPP INTELIGENTE / SMART WHATSAPP
  // -------------------------------------------------------------------
  whatsapp: {
    number: '15551234567', // solo dígitos con código país: ej. 13055551234
    // Mensajes pre-escritos según la sección donde esté el usuario
    messages: {
      general: {
        es: 'Hola RHD Dental Studio, me gustaría agendar una primera cita de valoración.',
        en: 'Hello RHD Dental Studio, I would like to book a first consultation.',
      },
      whitening: {
        es: 'Hola RHD Dental Studio, quiero información y precios del blanqueamiento dental.',
        en: 'Hello RHD Dental Studio, I would like info and pricing for teeth whitening.',
      },
      invisalign: {
        es: 'Hola RHD Dental Studio, me interesa la ortodoncia invisible (Invisalign). ¿Tienen valoración gratuita?',
        en: 'Hello RHD Dental Studio, I am interested in clear aligners. Do you offer a free assessment?',
      },
      implants: {
        es: 'Hola RHD Dental Studio, quisiera información sobre implantes dentales y opciones de financiamiento.',
        en: 'Hello RHD Dental Studio, I would like info about dental implants and financing options.',
      },
      veneers: {
        es: 'Hola RHD Dental Studio, me gustaría saber más sobre el diseño de sonrisa con carillas.',
        en: 'Hello RHD Dental Studio, I would like to learn more about smile design with veneers.',
      },
      rootcanal: {
        es: 'Hola RHD Dental Studio, necesito una cita urgente para tratamiento de endodoncia / dolor dental.',
        en: 'Hello RHD Dental Studio, I need an urgent appointment for root canal / tooth pain.',
      },
      emergency: {
        es: '🚨 ¡Hola RHD Dental Studio! Tengo una urgencia dental y necesito atención hoy.',
        en: '🚨 Hello RHD Dental Studio! I have a dental emergency and need care today.',
      },
      virtual: {
        es: 'Hola RHD Dental Studio, me gustaría agendar una consulta virtual con el doctor.',
        en: 'Hello RHD Dental Studio, I would like to book a virtual consultation with the doctor.',
      },
    },
  },

  // -------------------------------------------------------------------
  // 4. DOCTOR / DIRECTORA MÉDICA
  // -------------------------------------------------------------------
  doctor: {
    name: 'Dra. Sofía Morales',           // ej. "Dra. Sofía Morales"
    role: {
      es: 'Directora Médica & Especialista en Estética Dental',
      en: 'Medical Director & Cosmetic Dentistry Specialist',
    },
    credentials: 'DDS · AACD Accredited', // ej. "DDS, PhD · Fellow AACD · 14+ años de experiencia"
    university: 'University of Texas Health Science Center at San Antonio',// ej. "Universidad de Barcelona · Máster en Rehabilitación Oral"
    bio: {
      es: 'Con más de 15 años transformando sonrisas, la Dra. Sofía Morales combina precisión microscópica y sensibilidad estética para crear resultados naturales que devuelven la confianza. Pionera en odontología mínimamente invasiva y diseño digital de sonrisas.',
      en: 'With over 15 years transforming smiles, Dr. Sofia Morales combines microscopic precision and aesthetic sensitivity to create natural results that restore confidence. A pioneer in minimally invasive dentistry and digital smile design.',
    },
    photo: 'assets/images/doctor-portrait.jpg', // Reemplaza con la foto del doctor
    photoAlt: 'Retrato profesional de Dra. Sofía Morales',
    // Botón de consulta virtual (Zoom, WhatsApp o enlace externo)
    virtualConsultation: {
      enabled: true,
      url: 'https://calendly.com/rhddentalstudio/consultation', // ej. https://calendly.com/tu-clinica/virtual o '#'
    },
    highlights: [
      { number: '14+', label: { es: 'Años de experiencia', en: 'Years of experience' } },
      { number: '8.200+', label: { es: 'Sonrisas transformadas', en: 'Smiles transformed' } },
      { number: '4.9★', label: { es: 'Valoración media', en: 'Average rating' } },
    ],
  },

  // Equipo médico multi-doctor (para clínicas con varios especialistas)
  team: [
    // { id: 'doc-1', name: 'Dra. Sofía Morales', role: { es: 'Odontología estética y rehabilitación oral', en: 'Cosmetic dentistry and oral rehabilitation' }, credentials: 'DDS · AACD Accredited', photo: 'assets/images/doctor-portrait.jpg' },
  ],

  // -------------------------------------------------------------------
  // 5. ESTADÍSTICAS DEL HERO (CONTADORES)
  // -------------------------------------------------------------------
  stats: [
    { number: 98, suffix: '%', label: { es: 'Pacientes satisfechos', en: 'Satisfied patients' } },
    { number: 15, suffix: '+', label: { es: 'Años de excelencia', en: 'Years of excellence' } },
    { number: 12000, suffix: '+', label: { es: 'Procedimientos exitosos', en: 'Successful procedures' } },
    { number: 500, suffix: '+', label: { es: 'Reseñas 5 estrellas', en: '5-star reviews' } },
  ],

  // -------------------------------------------------------------------
  // 6. SERVICIOS DENTALES / SERVICES
  // -------------------------------------------------------------------
  services: [
    {
      id: 'whitening',
      icon: 'assets/icons/icon-whitening.svg',
      tag: { es: 'Más popular', en: 'Most popular' },
      title: { es: 'Blanqueamiento Dental Profesional', en: 'Professional Teeth Whitening' },
      desc: {
        es: 'Aclara hasta 8 tonos en una sola sesión con tecnología LED no invasiva que protege tu esmalte.',
        en: 'Lighten up to 8 shades in a single session with non-invasive LED technology that protects enamel.',
      },
      price: 'Desde $299', // ej. "Desde $199"
      duration: '45–60 min',
      popular: true,
      category: 'cosmetic',
    },
    {
      id: 'veneers',
      icon: 'assets/icons/icon-veneers.svg',
      tag: { es: 'Diseño de sonrisa', en: 'Smile design' },
      title: { es: 'Carillas Dentales de Porcelana', en: 'Porcelain Veneers' },
      desc: {
        es: 'Láminas ultrafinas hechas a mano para corregir forma, color y posición con resultados hipernaturales.',
        en: 'Handcrafted ultra-thin shells to correct shape, color and alignment with hyper-natural results.',
      },
      price: 'Desde $890 por carilla', // ej. "Desde $490/diente"
      duration: '2–3 sesiones',
      popular: true,
      category: 'cosmetic',
    },
    {
      id: 'invisalign',
      icon: 'assets/icons/icon-invisalign.svg',
      tag: { es: 'Ortodoncia invisible', en: 'Clear aligners' },
      title: { es: 'Alineadores Invisibles (Invisalign)', en: 'Clear Aligners (Invisalign)' },
      desc: {
        es: 'Corrige tu sonrisa de forma cómoda y discreta, con planificación digital 3D y seguimiento continuo.',
        en: 'Straighten your smile comfortably and discreetly with 3D digital planning and ongoing monitoring.',
      },
      price: 'Desde $1,890', // ej. "Desde $1.890"
      duration: '6–18 meses',
      popular: true,
      category: 'ortho',
    },
    {
      id: 'implants',
      icon: 'assets/icons/icon-implants.svg',
      tag: { es: 'Rehabilitación', en: 'Rehabilitation' },
      title: { es: 'Implantes Dentales & All-on-4', en: 'Dental Implants & All-on-4' },
      desc: {
        es: 'Recupera piezas perdidas con titanio biocompatible de máxima calidad y corona personalizada.',
        en: 'Restore missing teeth with premium biocompatible titanium and a fully customized crown.',
      },
      price: 'Desde $1,490', // ej. "Desde $890"
      duration: '1–2 horas',
      popular: false,
      category: 'implant',
    },
    {
      id: 'general',
      icon: 'assets/icons/icon-general.svg',
      tag: { es: 'Prevención', en: 'Prevention' },
      title: { es: 'Limpieza & Chequeo Preventivo', en: 'Cleaning & Preventive Checkup' },
      desc: {
        es: 'Profilaxis ultrasónica, diagnóstico con radiografía digital y plan de cuidado personalizado.',
        en: 'Ultrasonic prophylaxis, digital X-ray diagnostics and a personalized oral care plan.',
      },
      price: 'Desde $149', // ej. "Desde $79"
      duration: '40 min',
      popular: false,
      category: 'general',
    },
    {
      id: 'rootcanal',
      icon: 'assets/icons/icon-rootcanal.svg',
      tag: { es: 'Sin dolor', en: 'Pain-free' },
      title: { es: 'Endodoncia Microscópica', en: 'Microscopic Root Canal' },
      desc: {
        es: 'Salva tu diente natural con tecnología microscópica y anestesia computerizada prácticamente indolora.',
        en: 'Save your natural tooth with microscopic tech and virtually painless computer-guided anesthesia.',
      },
      price: 'Desde $750', // ej. "Desde $350"
      duration: '60–90 min',
      popular: false,
      category: 'general',
    },
    {
      id: 'pediatric',
      icon: 'assets/icons/icon-pediatric.svg',
      tag: { es: 'Odontopediatría', en: 'Pediatric' },
      title: { es: 'Odontología Infantil & Familiar', en: 'Pediatric & Family Dentistry' },
      desc: {
        es: 'Un entorno lúdico y sin miedo para los más pequeños, con selladores, flúor y ortodoncia preventiva.',
        en: 'A playful, fear-free environment for children with sealants, fluoride and preventive orthodontics.',
      },
      price: 'Desde $99',
      duration: '30–45 min',
      popular: false,
      category: 'family',
    },
    {
      id: 'emergency',
      icon: 'assets/icons/icon-emergency.svg',
      tag: { es: 'Atención 24/7', en: '24/7 care' },
      title: { es: 'Urgencias Dentales Mismo Día', en: 'Same-Day Dental Emergencies' },
      desc: {
        es: 'Dolor agudo, fracturas o pérdida de piezas: te atendemos en el día con prioridad absoluta.',
        en: 'Severe pain, fractures or lost teeth: we see you the same day with absolute priority.',
      },
      price: 'Desde $125',
      duration: 'Inmediata',
      popular: false,
      category: 'emergency',
    },
  ],

  // -------------------------------------------------------------------
  // 7. GALERÍA DE SONRISAS / SMILE GALLERY (ANTES Y DESPUÉS)
  // -------------------------------------------------------------------
  gallery: {
    // Caso principal del comparador interactivo (slider arrastrable)
    featuredCase: {
      before: 'assets/images/smile-before-1.jpg',
      after: 'assets/images/smile-after-1.jpg',
      title: {
        es: 'Diseño integral de sonrisa con 10 carillas de porcelana',
        en: 'Full smile design with 10 porcelain veneers',
      },
      treatment: { es: 'Carillas de porcelana + blanqueamiento', en: 'Porcelain veneers + whitening' },
      sessions: { es: '2 sesiones · 3 semanas', en: '2 sessions · 3 weeks' },
    },
    // Casos adicionales para la cuadrícula
    cases: [
      {
        before: 'assets/images/smile-before-2.jpg',
        after: 'assets/images/smile-after-2.jpg',
        title: { es: 'Ortodoncia invisible + recontorneado estético', en: 'Clear aligners + aesthetic recontouring' },
        treatment: { es: 'Invisalign · 11 meses', en: 'Invisalign · 11 months' },
        patient: 'Laura M., 29 años',
      },
      {
        before: 'assets/images/smile-before-1.jpg',
        after: 'assets/images/smile-after-1.jpg',
        title: { es: 'Rehabilitación estética completa superior', en: 'Complete upper aesthetic rehabilitation' },
        treatment: { es: 'Implantes + coronas de circonio', en: 'Implants + zirconia crowns' },
        patient: 'Carlos R., 41 años',
      },
      {
        after: 'assets/images/cosmetic-smile.jpg',
        title: { es: 'Resultado final tras 6 carillas mínimamente invasivas', en: 'Final result after 6 minimally invasive veneers' },
        treatment: { es: 'Carillas ultrafinas sin tallado', en: 'Ultra-thin no-prep veneers' },
        patient: 'Sofía P., 24 años',
      },
      {
        after: 'assets/images/veneers-result.jpg',
        title: { es: 'Detalle de adaptación marginal y textura natural', en: 'Marginal fit detail and natural texture' },
        treatment: { es: 'Macrofotografía clínica', en: 'Clinical macrophotography' },
        patient: 'Caso #D-2407',
      },
    ],
  },

  // -------------------------------------------------------------------
  // 8. FINANCIAMIENTO / FINANCING
  // -------------------------------------------------------------------
  financing: {
    badge: '0% INTERÉS',
    badgeEN: '0% INTEREST',
    headline: {
      es: 'Financia tu tratamiento al 0% de interés',
      en: 'Finance your treatment at 0% interest',
    },
    subheadline: {
      es: 'La sonrisa que quieres no tiene por qué esperar. Planes de pago flexibles en hasta 24 cuotas sin intereses ni comisiones ocultas.',
      en: 'The smile you want doesn’t have to wait. Flexible payment plans in up to 24 interest-free installments with no hidden fees.',
    },
    bullets: {
      es: [
        'Aprobación inmediata en la propia clínica',
        'Hasta 24 cuotas al 0% TAE',
        'Compatible con Aetna, Cigna y Delta Dental',
        'Sin letra pequeña ni costes de apertura',
      ],
      en: [
        'Immediate approval right at the clinic',
        'Up to 24 interest-free monthly installments',
        'Compatible with Aetna, Cigna, and Delta Dental',
        'No fine print, no setup fees',
      ],
    },
    partners: ['CareCredit', 'LendingPoint', 'SmilePay'], // asegúrate de poner tus financieras reales
    // Parámetros para la calculadora rápida
    calculator: {
      defaultAmount: 2400,
      minAmount: 300,
      maxAmount: 12000,
      months: [6, 12, 18, 24],
      defaultMonths: 12,
    },
  },

  // -------------------------------------------------------------------
  // 9. GOOGLE REVIEWS Y TESTIMONIOS / TESTIMONIALS
  // -------------------------------------------------------------------
  google: {
    rating: '4.9',
    totalReviews: '520',
    stars: 5,
    businessUrl: 'https://www.google.com/search?q=RHD+Dental+Studio+reviews', // enlace para dejar o leer reseñas en Google
    badgeText: {
      es: 'Basado en 520+ reseñas verificadas de Google',
      en: 'Based on 520+ verified Google reviews',
    },
  },

  testimonials: [
    {
      author: 'Carolina V.',
      city: 'Austin',
      rating: 5,
      date: { es: 'Hace 2 semanas', en: '2 weeks ago' },
      treatment: { es: 'Diseño de sonrisa', en: 'Smile design' },
      text: {
        es: 'La mejor decisión que he tomado. El resultado es tan natural que nadie nota que llevo carillas, pero todos me dicen que estoy radiante. La atención es de hotel cinco estrellas.',
        en: 'Best decision I have ever made. The result is so natural that nobody can tell I have veneers, yet everyone says I am glowing. The service feels like a five-star hotel.',
      },
      avatar: 'CV',
    },
    {
      author: 'Martín S.',
      city: 'Austin',
      rating: 5,
      date: { es: 'Hace 1 mes', en: '1 month ago' },
      treatment: { es: 'Invisalign', en: 'Invisalign' },
      text: {
        es: 'Tenía pánico al dentista y aquí me trataron con una delicadeza increíble. La planificación 3D te muestra el resultado final antes de empezar. En 10 meses mi sonrisa quedó perfecta.',
        en: 'I was terrified of dentists and they treated me with incredible gentleness. The 3D planning shows the final result before you even start. My smile was perfect in 10 months.',
      },
      avatar: 'MS',
    },
    {
      author: 'Elena R.',
      city: 'Austin',
      rating: 5,
      date: { es: 'Hace 3 semanas', en: '3 weeks ago' },
      treatment: { es: 'Blanqueamiento LED', en: 'LED whitening' },
      text: {
        es: 'El blanqueamiento fue súper rápido y sin sensibilidad. Las instalaciones son preciosas, parecen de spa. Puntualidad inglesa y equipo muy profesional.',
        en: 'The whitening was super fast with zero sensitivity. The facilities are gorgeous, spa-like. British punctuality and a very professional team.',
      },
      avatar: 'ER',
    },
    {
      author: 'Diego G.',
      city: 'Austin',
      rating: 5,
      date: { es: 'Hace 2 meses', en: '2 months ago' },
      treatment: { es: 'Implante dental', en: 'Dental implant' },
      text: {
        es: 'Perdí una muela y con el implante no siento ninguna diferencia con un diente propio. El proceso fue sin dolor alguno. Además me financiaron todo al 0%. Recomendadísimos.',
        en: 'I lost a molar and with the implant I feel no difference from a real tooth. The process was completely painless. Plus they financed everything at 0%. Highly recommended.',
      },
      avatar: 'DG',
    },
    {
      author: 'Valentina M.',
      city: 'Austin',
      rating: 5,
      date: { es: 'Hace 3 días', en: '3 days ago' },
      treatment: { es: 'Urgencia dental', en: 'Dental emergency' },
      text: {
        es: 'Se me fracturó un diente un sábado por la tarde y me atendieron en menos de dos horas. Me reconstruyeron la pieza de forma impecable. Un servicio de urgencia impecable.',
        en: 'I fractured a tooth on a Saturday afternoon and was seen in under two hours. They rebuilt it flawlessly. Truly impeccable emergency service.',
      },
      avatar: 'VM',
    },
  ],

  // -------------------------------------------------------------------
  // 10. PREGUNTAS FRECUENTES / FAQ
  // -------------------------------------------------------------------
  faqs: [
    {
      q: {
        es: '¿La primera cita de valoración es gratuita?',
        en: 'Is the first consultation free?',
      },
      a: {
        es: 'Sí. Nuestra primera visita incluye exploración clínica completa, radiografía digital y propuesta de tratamiento sin ningún compromiso.',
        en: 'Yes. Our first visit includes a full clinical examination, digital X-rays and a treatment proposal with no obligation.',
      },
    },
    {
      q: {
        es: '¿Los tratamientos duelen? Tengo miedo al dentista.',
        en: 'Do the treatments hurt? I am afraid of the dentist.',
      },
      a: {
        es: 'Trabajamos con anestesia computerizada prácticamente indolora, técnicas mínimamente invasivas y un protocolo de atención relajada. Para pacientes con alta ansiedad ofrecemos también sedación consciente.',
        en: 'We use virtually painless computer-assisted anesthesia, minimally invasive techniques and a relaxed-care protocol. For patients with high anxiety we also offer conscious sedation.',
      },
    },
    {
      q: {
        es: '¿Cuánto dura un tratamiento de diseño de sonrisa con carillas?',
        en: 'How long does a smile design with veneers take?',
      },
      a: {
        es: 'Por lo general se completa en solo 2–3 sesiones a lo largo de 3–4 semanas. Gracias al escáner digital 3D podrás previsualizar el resultado final antes de empezar.',
        en: 'It is typically completed in 2–3 sessions over 3–4 weeks. Thanks to 3D digital scanning you can preview the final result before we even begin.',
      },
    },
    {
      q: {
        es: '¿Trabajan con seguros dentales?',
        en: 'Do you accept dental insurance?',
      },
      a: {
        es: 'Colaboramos con las principales aseguradoras: Aetna, Cigna, Delta Dental y más. También tramitamos reembolsos para aseguradoras con libre elección de facultativo.',
        en: 'We work with major insurers: Aetna, Cigna, Delta Dental and more. We also process reimbursements for out-of-network plans.',
      },
    },
    {
      q: {
        es: '¿Cómo funciona la financiación al 0% de interés?',
        en: 'How does 0% interest financing work?',
      },
      a: {
        es: 'Te aprobamos la financiación en la propia clínica en minutos, con planes de 6 a 24 cuotas sin intereses ni comisiones de apertura. Solo necesitas un documento de identidad y tu cuenta bancaria.',
        en: 'We approve financing at the clinic within minutes, with plans from 6 to 24 interest-free installments and no setup fees. You only need a valid ID and a bank account.',
      },
    },
    {
      q: {
        es: '¿Ofrecen citas el mismo día para urgencias?',
        en: 'Do you offer same-day emergency appointments?',
      },
      a: {
        es: 'Sí, reservamos franjas diarias exclusivas para urgencias. Llámanos o escríbenos por WhatsApp y te daremos cita prioritaria en el mismo día.',
        en: 'Yes, we reserve daily slots exclusively for emergencies. Call or WhatsApp us and we will give you priority same-day scheduling.',
      },
    },
  ],

  // -------------------------------------------------------------------
  // 11. HORARIOS / OPENING HOURS
  // -------------------------------------------------------------------
  hours: [
    { days: { es: 'Lunes a Viernes', en: 'Monday to Friday' }, time: '08:00–17:00' }, // ej. "09:00 – 20:00"
    { days: { es: 'Sábados', en: 'Saturdays' }, time: '09:00–13:00' },                  // ej. "10:00 – 14:00"
    { days: { es: 'Domingos', en: 'Sundays' }, time: { es: 'Solo urgencias con cita previa', en: 'Emergencies by appointment only' } },
  ],

  // -------------------------------------------------------------------
  // 12. FORMULARIO DE CITA / APPOINTMENT FORM (FORMSPREE)
  // -------------------------------------------------------------------
  form: {
    // ID de tu formulario de Formspree (crea uno gratis en formspree.io)
    formspreeId: 'YOUR_FORM_ID',
    // Deja en true durante el desarrollo para probar sin enviar emails reales
    demoMode: true,
    emailRecipient: 'hello@rhddentalstudio.com', // para tu registro (no visible)
  },

  // -------------------------------------------------------------------
  // 13. REDES SOCIALES / SOCIAL LINKS
  // -------------------------------------------------------------------
  social: {
    instagram: 'https://www.instagram.com/rhddentalstudio/', // ej. https://instagram.com/tuclinica
    facebook: 'https://www.facebook.com/rhddentalstudio/',
    whatsapp: 'https://wa.me/15551234567',
    x: 'https://x.com/rhddentalstudio',
    googleBusiness: 'https://maps.google.com/?q=RHD+Dental+Studio+Austin+TX',
  },

  // -------------------------------------------------------------------
  // 14. POP-UP DE SALIDA (EXIT-INTENT)
  // -------------------------------------------------------------------
  exitPopup: {
    enabled: true,
    delaySeconds: 0, // se activa cuando el ratón sale de la ventana
    mobileDelaySeconds: 45, // en móvil se activa por tiempo
    title: {
      es: 'No te vayas sin reservar tu consulta',
      en: 'Don’t leave without booking your consultation',
    },
    subtitle: {
      es: 'Déjanos tus datos y continúa con la reserva de tu consulta. El equipo de la clínica confirmará los detalles directamente.',
      en: 'Leave your details and continue booking your consultation. The clinic team will confirm the details directly.',
    },
    cta: {
      es: 'Reservar mi consulta',
      en: 'Book my consultation',
    },
  },

  // -------------------------------------------------------------------
  // 15. TARJETA PREMIUM DE RESERVA / PREMIUM BOOKING PASS
  // -------------------------------------------------------------------
  bookingPass: {
    logoMark: '✦',
    accent: '#D1B886',
    accentDeep: '#0A5A5C',
    headerColor: '#0B5558',
    brandLabel: { es: 'PREMIUM DENTAL CARE', en: 'PREMIUM DENTAL CARE' },
    status: { es: 'CONFIRMADA', en: 'CONFIRMED' },
    eyebrow: { es: 'TU TARJETA DE RESERVA', en: 'YOUR BOOKING CARD' },
    title: { es: 'Premium Dental Booking Pass', en: 'Premium Dental Booking Pass' },
    subtitle: { es: 'Tu próxima visita comienza aquí', en: 'Your next visit starts here' },
    protectedTitle: { es: 'Tu reserva está protegida', en: 'Your reservation is protected' },
    protectedCopy: { es: 'Presenta esta tarjeta al llegar a la clínica.', en: 'Present this card when you arrive at the clinic.' },
  },

  // -------------------------------------------------------------------
  // 16. CONFIGURACIÓN TÉCNICA / TECHNICAL SETTINGS
  // -------------------------------------------------------------------
  settings: {
    defaultLang: 'es',          // 'es' o 'en'
    defaultTheme: 'light',       // 'light' o 'dark'
    theme: 'luxury-studio',      // luxury-studio | modern-family | cosmetic | premium-implants | orthodontic | boutique
    heroUseVideo: false,        // true = video de fondo (assets/images/hero-bg.mp4)
    currency: '$',              // símbolo de moneda para la calculadora
  },

  // -------------------------------------------------------------------
  // 16. SEO AVANZADO (valores reales por clínica)
  // -------------------------------------------------------------------
  seo: {
    title: {
      es: 'RHD Dental Studio — Odontología de Alta Gama y Diseño de Sonrisa en Austin',
      en: 'RHD Dental Studio — High-End Dentistry & Smile Design in Austin',
    },
    description: {
      es: 'RHD Dental Studio: clínica dental boutique en Austin. Diseño de sonrisa, carillas de porcelana, implantes, Invisalign y blanqueamiento con tecnología de última generación.',
      en: 'RHD Dental Studio: boutique dental clinic in Austin. Smile design, porcelain veneers, implants, Invisalign and whitening with next-generation technology.',
    },
    siteUrl: 'https://www.rhddentalstudio.com',         // ej. https://www.tuclinica.com
    canonicalUrl: 'https://www.rhddentalstudio.com/',
    ogImage: 'assets/images/hero-smile.jpg',
    keywords: ['clínica dental Austin', 'diseño de sonrisa', 'carillas', 'invisalign', 'implantes dentales'],
  },

  // -------------------------------------------------------------------
  // 17. ASISTENTE FAQ LOCAL (opcional)
  // -------------------------------------------------------------------
  aiAssistant: {
    enabled: true,
    name: 'Sofía',
    transferNumber: '15551234567', // teléfono para derivar consultas complejas
    guardrailsNotes: 'El asistente nunca diagnostica, prescribe ni promete resultados médicos.',
  },

  // -------------------------------------------------------------------
  // 18. MÓDULOS ACTIVABLES
  // -------------------------------------------------------------------
  features: {
    crm: true,
    automations: true,
    aiAssistant: true,
    multiLocation: false,
    financingCalculator: true,
    beforeAfterGallery: true,
    googleReviews: true,
    faq: true,
    darkThemeToggle: true,
    languageSwitch: true,
  },

  // -------------------------------------------------------------------
  // 19. INTEGRACIONES EXTERNAS (rellena solo las que uses)
  // -------------------------------------------------------------------
  integrations: {
    googleAnalyticsId: 'G-1A2B3C4D5E',   // ej. G-XXXXXXXXXX
    googleTagManagerId: '',                      // ej. GTM-XXXXXXX
    googleSearchConsoleMeta: '',
    googleMapsApiKey: '',
    resendApiKey: '',                            // para emails desde Cloudflare Functions
    twilio: { sid: '', auth: '', from: '' },     // para SMS
    googleCalendar: { enabled: false },
    outlookCalendar: { enabled: false },
  },
};

/**
 * Dental Master Enterprise — Automation Engine
 * Triggers -> conditions -> actions (notifications, emails, SMS, reviews, reactivation)
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function render(container) {
    if (!container) return;
    const autos = S.getAutomations();
    const logs = S.getAutomationLogs();

    container.innerHTML = `
      <div class="auto-panel">
        <div class="auto-col">
          <h3>Flujos activos</h3>
          <p class="dme-muted"><small>Se ejecutan automáticamente con cada evento (lead nuevo, cita confirmada, cita realizada...). Puedes desactivar o probar cualquiera.</small></p>
          <div class="auto-list" id="autoList"></div>
        </div>
        <div class="auto-col">
          <div class="dme-row dme-row-between"><h3>Historial de ejecuciones</h3><button id="autoRunStalled" class="dme-btn dme-btn-xs" title="Lanza la regla de seguimientos estancados">Ejecutar chequeo diario</button></div>
          <div class="auto-logs" id="autoLogs"></div>
        </div>
      </div>
      <p class="dme-notice"><small><strong>Consentimiento y canales:</strong> cada flujo simula el canal configurado (email/SMS/WhatsApp/notificación interna). En producción con Cloudflare Functions se conectan proveedores reales (Resend, Twilio) respetando preferencias de comunicación y bajas.</small></p>`;

    function renderList() {
      container.querySelector('#autoList').innerHTML = autos.map((a) => `
        <article class="auto-card">
          <div class="auto-head">
            <div><strong>${esc(a.name)}</strong><div class="dme-muted"><small>Disparador: <code>${esc(a.trigger)}</code> · Acción: <code>${esc(a.action)}</code></small></div></div>
            <label class="dme-switch"><input type="checkbox" data-id="${esc(a.id)}" ${a.enabled ? 'checked' : ''}><span class="dme-switch-track"></span></label>
          </div>
          <p class="auto-desc"><small>${esc(a.actionDetail)}</small></p>
          <div class="auto-foot"><small class="dme-muted">Última ejecución: ${a.lastRun ? esc(a.lastRun) : '—'}</small><button class="dme-btn dme-btn-xs js-auto-test" data-id="${esc(a.id)}">Probar ahora</button></div>
        </article>`).join('');
    }

    function renderLogs() {
      container.querySelector('#autoLogs').innerHTML = logs.length === 0
        ? '<p class="dme-empty">Sin ejecuciones todavía. Genera un lead o una cita para ver los flujos en acción.</p>'
        : logs.map((l) => `<div class="auto-log ${l.ok ? 'ok' : 'err'}"><span>${esc(l.at)}</span><strong>${esc(l.automationName || l.automationId)}</strong><small>${esc(l.action)}</small></div>`).join('');
    }

    container.querySelector('#autoList').onclick = (e) => {
      const sw = e.target.closest('input[type=checkbox]');
      if (sw) { const a = autos.find((x) => x.id === sw.dataset.id); if (a) { a.enabled = sw.checked; S.saveAutomation(a); renderList(); } }
      const btn = e.target.closest('.js-auto-test');
      if (btn) { const a = autos.find((x) => x.id === btn.dataset.id); if (a) { S.runAutomationsFor(a.trigger, { simulated: true }); renderList(); renderLogs(); } }
    };
    container.querySelector('#autoRunStalled').onclick = () => { S.runAutomationsFor('schedule.daily', { simulated: true }); renderList(); renderLogs(); };
    renderList(); renderLogs();
  }

  global.DMEAutomations = { render };
})(typeof window !== 'undefined' ? window : globalThis);

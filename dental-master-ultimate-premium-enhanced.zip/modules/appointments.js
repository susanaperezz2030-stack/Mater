/**
 * Dental Master Enterprise — Smart Appointment Management
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const STATUS = { pending: 'Pendiente', confirmed: 'Confirmada', completed: 'Realizada', cancelled: 'Cancelada' };

  async function render(container, cfg) {
    if (!container) return;
    const list = await S.getAppointments();
    const today = new Date();
    const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    list.sort((a, b) => `${a.date || ''} ${a.slot || ''}`.localeCompare(`${b.date || ''} ${b.slot || ''}`));

    container.innerHTML = `
      <div class="appt-toolbar">
        <input type="date" id="apptDateFilter" class="dme-input">
        <select id="apptStatusFilter" class="dme-select"><option value="">Todos los estados</option><option value="pending">Pendientes</option><option value="confirmed">Confirmadas</option><option value="completed">Realizadas</option><option value="cancelled">Canceladas</option></select>
        <button id="apptNewBtn" class="dme-btn dme-btn-primary">+ Nueva cita</button>
      </div>
      <div class="appt-list" id="apptList"></div>
      <div id="apptModal" class="dme-modal" aria-hidden="true"></div>`;

    function filter(items) {
      const d = container.querySelector('#apptDateFilter')?.value || '';
      const st = container.querySelector('#apptStatusFilter')?.value || '';
      return items.filter((a) => (d ? a.date === d : true) && (st ? a.status === st : true));
    }

    function renderList() {
      const f = filter(list);
      container.querySelector('#apptList').innerHTML = f.length === 0
        ? '<p class="dme-empty">No hay citas con estos filtros.</p>'
        : f.map((a) => `
          <article class="appt-card appt-${a.status}">
            <div class="appt-main">
              <div class="appt-date"><strong>${esc(a.date)}</strong><span>${esc(a.slot)}</span></div>
              <div class="appt-info">
                <h4>${esc(a.name)} <span class="dme-badge appt-badge-${a.status}">${esc(STATUS[a.status] || a.status)}</span></h4>
                <p><a href="tel:${esc(a.phone)}">${esc(a.phone)}</a> · ${esc(a.email || '')} · Tratamiento: <b>${esc(a.service)}</b>${a.location ? ` · Sede: ${esc(a.location)}` : ''}</p>
                <small class="dme-muted">Especialista: ${esc(a.specialist || 'Sin preferencia')}${a.notes ? ` · Notas: ${esc(a.notes)}` : ''}${a.cancelReason ? ` · Motivo cancelación: ${esc(a.cancelReason)}` : ''}</small>
              </div>
            </div>
            <div class="appt-actions">
              ${a.status !== 'confirmed' && a.status !== 'cancelled' ? `<button class="dme-btn dme-btn-xs dme-btn-primary js-confirm" data-id="${esc(a.id)}">Confirmar</button>` : ''}
              ${a.status === 'confirmed' && a.date <= todayKey ? `<button class="dme-btn dme-btn-xs js-complete" data-id="${esc(a.id)}">Realizada</button>` : ''}
              <button class="dme-btn dme-btn-xs js-resched" data-id="${esc(a.id)}">Reprogramar</button>
              ${a.status !== 'cancelled' ? `<button class="dme-btn dme-btn-xs dme-btn-danger js-cancel" data-id="${esc(a.id)}">Cancelar</button>` : ''}
            </div>
          </article>`).join('');
    }

    function openModal(html) { const m = container.querySelector('#apptModal'); m.innerHTML = html; m.classList.add('open'); m.setAttribute('aria-hidden', 'false'); }
    function closeModal() { const m = container.querySelector('#apptModal'); m.classList.remove('open'); m.setAttribute('aria-hidden', 'true'); }

    function openNew() {
      const today = new Date().toISOString().split('T')[0];
      const services = (cfg && cfg.services) || [];
      const team = (cfg && cfg.team) || [];
      const locations = (cfg && cfg.locations) || [];
      openModal(`
        <div class="dme-modal-card">
          <div class="dme-modal-head"><h3>Nueva cita</h3><button class="dme-close" id="apptClose">×</button></div>
          <form id="apptNewForm" class="dme-form">
            <div class="dme-row">
              <label>Servicio<select name="service" class="dme-select">${services.map((s) => `<option value="${s.id}">${esc(s.title?.es || s.title)}</option>`).join('') || '<option value="general">General</option>'}</select></label>
              <label>Especialista<select name="specialist" class="dme-select"><option value="">Sin preferencia</option>${team.map((t) => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('')}</select></label>
            </div>
            <div class="dme-row">
              <label>Sede<select name="location" class="dme-select"><option value="">Principal</option>${locations.map((l) => `<option value="${esc(l.id)}">${esc(l.name)}</option>`).join('')}</select></label>
              <label>Fecha<input type="date" name="date" class="dme-input" required min="${today}" value="${today}"></label>
            </div>
            <div class="dme-row">
              <label>Franja<select name="slot" class="dme-select"><option>Mañana (09:00–14:00)</option><option>Tarde (14:00–18:00)</option><option>Última hora (18:00–20:00)</option></select></label>
              <label>Nombre paciente *<input name="name" class="dme-input" required></label>
            </div>
            <div class="dme-row">
              <label>Teléfono *<input name="phone" class="dme-input" required></label>
              <label>Email<input type="email" name="email" class="dme-input"></label>
            </div>
            <label>Notas<textarea name="notes" rows="2" class="dme-input"></textarea></label>
            <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar cita</button></div>
          </form>
        </div>`);
      container.querySelector('#apptClose').onclick = closeModal;
      container.querySelector('#apptNewForm').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        const res = await S.saveAppointment(data);
        if (!res.ok && res.conflict) { alert('Franja ocupada en esa fecha y sede. Elige otra fecha/hora.'); return; }
        list.unshift(res.appointment); closeModal(); renderList();
      };
    }

    container.querySelector('#apptList').onclick = async (e) => {
      const id = e.target.dataset.id;
      if (!id) return;
      const a = list.find((x) => x.id === id);
      if (!a) return;
      if (e.target.classList.contains('js-confirm')) { a.status = 'confirmed'; await S.saveAppointment({ ...a }); S.runAutomationsFor('appointment.confirmed', a); renderList(); }
      else if (e.target.classList.contains('js-complete')) { a.status = 'completed'; await S.saveAppointment({ ...a }); S.runAutomationsFor('appointment.completed', a); renderList(); }
      else if (e.target.classList.contains('js-cancel')) {
        const reason = prompt('Motivo de cancelación (opcional):') ?? null;
        if (reason === null) return;
        await S.cancelAppointment(id, reason); a.status = 'cancelled'; a.cancelReason = reason; renderList();
      } else if (e.target.classList.contains('js-resched')) {
        const d = prompt('Nueva fecha (YYYY-MM-DD):', a.date); if (!d) return;
        const slot = prompt('Nueva franja:\n1) Mañana (09:00–14:00)\n2) Tarde (14:00–18:00)\n3) Última hora (18:00–20:00)\n(Escribe 1, 2 o 3 o el texto)', '1');
        const slots = { 1: 'Mañana (09:00–14:00)', 2: 'Tarde (14:00–18:00)', 3: 'Última hora (18:00–20:00)' };
        const finalSlot = slots[slot] || slot;
        const res = await S.rescheduleAppointment(id, d, finalSlot);
        if (!res.ok) { alert(res.conflict ? 'Franja ocupada. Elige otra.' : 'No se pudo reprogramar.'); return; }
        a.date = d; a.slot = finalSlot; a.status = 'pending'; renderList();
      }
    };
    container.querySelector('#apptDateFilter').onchange = renderList;
    container.querySelector('#apptStatusFilter').onchange = renderList;
    container.querySelector('#apptNewBtn').onclick = openNew;
    renderList();
  }

  global.DMEAppointments = { render };
})(typeof window !== 'undefined' ? window : globalThis);

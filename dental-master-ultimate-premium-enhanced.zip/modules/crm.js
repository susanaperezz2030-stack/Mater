/**
 * Dental Master Enterprise — Patient Lead Management CRM
 * Pipeline: new -> contacted -> appointment_requested -> appointment_confirmed ->
 * consultation_done -> treatment_pending -> converted -> lost
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  async function render(container) {
    if (!container) return;
    const leads = await S.getLeads();
    const users = S.getUsers();
    const stages = S.PIPELINE_STAGES;

    container.innerHTML = `
      <div class="crm-toolbar">
        <input type="search" id="crmSearch" class="dme-input" placeholder="Buscar por nombre, teléfono o email...">
        <select id="crmStageFilter" class="dme-select"><option value="">Todos los estados</option>${stages.map((s) => `<option value="${s.id}">${s.label}</option>`).join('')}</select>
        <select id="crmSourceFilter" class="dme-select"><option value="">Todos los orígenes</option><option value="web">Web</option><option value="whatsapp">WhatsApp</option><option value="google_ads">Google Ads</option><option value="instagram">Instagram</option><option value="facebook_ads">Facebook Ads</option><option value="phone">Teléfono</option><option value="referral">Recomendación</option><option value="exit_intent">Exit-intent</option></select>
        <button id="crmNewBtn" class="dme-btn dme-btn-primary">+ Nuevo lead</button>
        <button id="crmExportBtn" class="dme-btn dme-btn-ghost">Exportar CSV</button>
        <button id="crmResetBtn" class="dme-btn dme-btn-ghost" title="Restaura los datos de demostración">Datos demo</button>
      </div>

      <div class="crm-kpis" id="crmKpis"></div>

      <div class="crm-tabs">
        <button class="crm-tab active" data-view="pipeline">Canalización</button>
        <button class="crm-tab" data-view="table">Listado</button>
      </div>

      <div id="crmPipelineView" class="crm-pipeline"></div>
      <div id="crmTableView" class="crm-table-wrap" style="display:none"></div>

      <p class="crm-notice"><small><strong>Aviso de privacidad:</strong> este CRM contiene únicamente datos de contacto de marketing. No almacenes información clínica sensible; los datos protegidos de salud deben gestionarse en un sistema médico independiente y conforme a la normativa aplicable.</small></p>

      <div id="crmModal" class="dme-modal" aria-hidden="true"></div>`;

    function filterLeads(list) {
      const q = (container.querySelector('#crmSearch')?.value || '').trim().toLowerCase();
      const stage = container.querySelector('#crmStageFilter')?.value || '';
      const source = container.querySelector('#crmSourceFilter')?.value || '';
      return list.filter((l) => {
        if (q && ![l.name, l.phone, l.email, l.notes].join(' ').toLowerCase().includes(q)) return false;
        if (stage && l.status !== stage) return false;
        if (source && l.source !== source) return false;
        return true;
      });
    }

    function userName(id) { const u = users.find((x) => x.id === id); return u ? u.name : '—'; }

    function renderKpis(filtered) {
      const conv = filtered.filter((l) => l.status === 'converted').length;
      const rate = filtered.length ? Math.round((conv / filtered.length) * 100) : 0;
      container.querySelector('#crmKpis').innerHTML = `
        <div class="crm-kpi"><strong>${filtered.length}</strong><span>Leads totales</span></div>
        <div class="crm-kpi"><strong>${filtered.filter((l) => l.status === 'new').length}</strong><span>Nuevos</span></div>
        <div class="crm-kpi"><strong>${conv}</strong><span>Convertidos</span></div>
        <div class="crm-kpi"><strong>${rate}%</strong><span>Tasa de conversión</span></div>`;
    }

    function renderPipeline(filtered) {
      const el = container.querySelector('#crmPipelineView');
      el.innerHTML = stages
        .map((s) => {
          const inStage = filtered.filter((l) => l.status === s.id);
          return `
            <div class="crm-col" data-stage="${s.id}">
              <div class="crm-col-head"><strong>${s.label}</strong><span class="crm-count">${inStage.length}</span></div>
              <div class="crm-col-body">
                ${inStage.map((l) => `
                  <article class="crm-card" data-lead-id="${esc(l.id)}">
                    <div class="crm-card-title">${esc(l.name)}</div>
                    <div class="crm-card-meta"><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></div>
                    <div class="crm-card-tags"><span class="crm-tag">${esc(l.treatment || '—')}</span><span class="crm-tag crm-tag-src">${esc(l.source || '—')}</span></div>
                    ${l.followUp ? `<div class="crm-followup"><small>Seguimiento:</small> ${esc(l.followUp)}</div>` : ''}
                    <div class="crm-card-foot"><small>${esc(userName(l.assignee))}</small><button class="crm-card-btn js-crm-edit" data-id="${esc(l.id)}">Ver</button></div>
                  </article>`).join('')}
              </div>
            </div>`;
        })
        .join('');
    }

    function renderTable(filtered) {
      const el = container.querySelector('#crmTableView');
      el.innerHTML = `
        <table class="dme-table">
          <thead><tr><th>Nombre</th><th>Teléfono</th><th>Email</th><th>Tratamiento</th><th>Origen</th><th>Estado</th><th>Responsable</th><th>Seguimiento</th><th></th></tr></thead>
          <tbody>${filtered.map((l) => `
            <tr><td><strong>${esc(l.name)}</strong></td><td><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></td><td>${esc(l.email || '—')}</td><td>${esc(l.treatment || '—')}</td><td>${esc(l.source || '—')}</td><td><span class="dme-badge">${esc(stages.find((s) => s.id === l.status)?.label || l.status)}</span></td><td>${esc(userName(l.assignee))}</td><td>${esc(l.followUp || '—')}</td><td><button class="dme-btn dme-btn-xs js-crm-edit" data-id="${esc(l.id)}">Ver</button></td></tr>`).join('')}</tbody>
        </table>`;
    }

    function refresh() {
      const f = filterLeads(leads);
      renderKpis(f);
      renderPipeline(f);
      renderTable(f);
    }

    // Export CSV
    function exportCsv() {
      const f = filterLeads(leads);
      const headers = ['id', 'name', 'phone', 'email', 'treatment', 'source', 'status', 'assignee', 'followUp', 'notes', 'createdAt'];
      const rows = f.map((l) => headers.map((h) => `"${String(l[h] ?? '').replace(/"/g, '""')}"`).join(','));
      const blob = new Blob([headers.join(',') + '\n' + rows.join('\n')], { type: 'text/csv;charset=utf-8' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `leads-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    }

    // Modal
    function openModal(html) { const m = container.querySelector('#crmModal'); m.innerHTML = html; m.classList.add('open'); m.setAttribute('aria-hidden', 'false'); }
    function closeModal() { const m = container.querySelector('#crmModal'); m.classList.remove('open'); m.setAttribute('aria-hidden', 'true'); }

    function openLead(id) {
      const l = leads.find((x) => x.id === id);
      if (!l) return;
      openModal(`
        <div class="dme-modal-card">
          <div class="dme-modal-head"><h3>Lead · ${esc(l.name)}</h3><button class="dme-close" id="crmClose">×</button></div>
          <form id="crmForm" class="dme-form">
            <div class="dme-row">
              <label>Nombre<input name="name" value="${esc(l.name)}" class="dme-input" required></label>
              <label>Teléfono<input name="phone" value="${esc(l.phone)}" class="dme-input" required></label>
            </div>
            <div class="dme-row">
              <label>Email<input type="email" name="email" value="${esc(l.email)}" class="dme-input"></label>
              <label>Origen<input name="source" value="${esc(l.source)}" class="dme-input"></label>
            </div>
            <div class="dme-row">
              <label>Tratamiento<input name="treatment" value="${esc(l.treatment)}" class="dme-input"></label>
              <label>Estado<select name="status" class="dme-select">${stages.map((s) => `<option value="${s.id}" ${l.status === s.id ? 'selected' : ''}>${s.label}</option>`).join('')}</select></label>
            </div>
            <div class="dme-row">
              <label>Responsable<select name="assignee" class="dme-select"><option value="">—</option>${users.map((u) => `<option value="${u.id}" ${l.assignee === u.id ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}</select></label>
              <label>Seguimiento<input type="date" name="followUp" value="${esc(l.followUp)}" class="dme-input"></label>
            </div>
            <label>Notas internas<textarea name="notes" rows="3" class="dme-input">${esc(l.notes)}</textarea></label>
            <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar</button><button type="button" id="crmDeleteBtn" class="dme-btn dme-btn-danger">Eliminar</button></div>
          </form>
        </div>`);
      container.querySelector('#crmClose').onclick = closeModal;
      container.querySelector('#crmForm').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        await S.updateLead(id, data);
        Object.assign(l, data);
        closeModal(); refresh();
      };
      container.querySelector('#crmDeleteBtn').onclick = async () => {
        if (!confirm('¿Eliminar este lead?')) return;
        await S.deleteLead(id);
        const idx = leads.findIndex((x) => x.id === id); if (idx >= 0) leads.splice(idx, 1);
        closeModal(); refresh();
      };
    }

    function openNew() {
      openModal(`
        <div class="dme-modal-card">
          <div class="dme-modal-head"><h3>Nuevo lead</h3><button class="dme-close" id="crmClose">×</button></div>
          <form id="crmNewForm" class="dme-form">
            <div class="dme-row">
              <label>Nombre *<input name="name" class="dme-input" required></label>
              <label>Teléfono *<input name="phone" class="dme-input" required></label>
            </div>
            <div class="dme-row">
              <label>Email<input type="email" name="email" class="dme-input"></label>
              <label>Origen<input name="source" value="phone" class="dme-input"></label>
            </div>
            <div class="dme-row">
              <label>Tratamiento<input name="treatment" class="dme-input"></label>
              <label>Estado<select name="status" class="dme-select">${stages.map((s) => `<option value="${s.id}">${s.label}</option>`).join('')}</select></label>
            </div>
            <label>Notas internas<textarea name="notes" rows="3" class="dme-input"></textarea></label>
            <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Crear</button></div>
          </form>
        </div>`);
      container.querySelector('#crmClose').onclick = closeModal;
      container.querySelector('#crmNewForm').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        const created = await S.saveLead(data);
        leads.unshift(created); closeModal(); refresh();
      };
    }

    container.querySelector('#crmPipelineView').onclick = (e) => { const b = e.target.closest('.js-crm-edit'); if (b) openLead(b.dataset.id); };
    container.querySelector('#crmTableView').onclick = (e) => { const b = e.target.closest('.js-crm-edit'); if (b) openLead(b.dataset.id); };
    container.querySelector('#crmSearch').oninput = refresh;
    container.querySelector('#crmStageFilter').onchange = refresh;
    container.querySelector('#crmSourceFilter').onchange = refresh;
    container.querySelector('#crmExportBtn').onclick = exportCsv;
    container.querySelector('#crmNewBtn').onclick = openNew;
    container.querySelector('#crmResetBtn').onclick = () => { S.resetDemo(); location.reload(); };
    container.querySelectorAll('.crm-tab').forEach((t) => {
      t.onclick = () => {
        container.querySelectorAll('.crm-tab').forEach((x) => x.classList.remove('active'));
        t.classList.add('active');
        const v = t.dataset.view;
        container.querySelector('#crmPipelineView').style.display = v === 'pipeline' ? 'grid' : 'none';
        container.querySelector('#crmTableView').style.display = v === 'table' ? 'block' : 'none';
      };
    });

    refresh();
  }

  global.DMECRM = { render };
})(typeof window !== 'undefined' ? window : globalThis);

/**
 * Dental Master Enterprise — Analytics & Conversion Tracking
 * Captures UTM params, stores attribution in sessionStorage (attached to leads),
 * and tracks key events: phone clicks, whatsapp clicks, booking start/submit, exit claims.
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const UTM_KEY = 'dme_utm';

  function captureUtm() {
    try {
      const p = new URLSearchParams(location.search);
      const utm = {};
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach((k) => {
        const v = p.get(k); if (v) utm[k] = v;
      });
      if (Object.keys(utm).length) sessionStorage.setItem(UTM_KEY, JSON.stringify({ ...utm, ref: document.referrer, at: new Date().toISOString() }));
    } catch {}
  }
  function attribution() { try { return JSON.parse(sessionStorage.getItem(UTM_KEY) || '{}'); } catch { return {}; } }

  function event(type, extra = {}) {
    S && S.logEvent && S.logEvent({ type, page: location.pathname, ...attribution(), ...extra });
  }

  function bindTrackers() {
    captureUtm();
    document.addEventListener('click', (e) => {
      if (e.target.closest('[data-phone-link]')) event('click.phone');
      if (e.target.closest('[data-wa-link]')) event('click.whatsapp');
      if (e.target.closest('.js-open-booking')) event('booking.open');
    });
  }

  function stats() {
    const events = (S && S.getEvents ? S.getEvents() : []);
    const counts = {};
    events.forEach((ev) => { counts[ev.type] = (counts[ev.type] || 0) + 1; });
    const sources = {};
    events.filter((e) => e.utm_source).forEach((e) => { sources[e.utm_source] = (sources[e.utm_source] || 0) + 1; });
    return { counts, sources, total: events.length };
  }

  global.DMEAnalytics = { bindTrackers, event, attribution, stats };
})(typeof window !== 'undefined' ? window : globalThis);

/*
 * Dental Master Enterprise — Local Premium FAQ Assistant
 * Spanish/English keyword-based answers. No network requests, AI provider, or API keys.
 * Medical guardrail: informational only; emergencies are directed to the clinic.
 */
(function (global) {
  'use strict';

  const normalize = (value) => String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9+\s]/g, ' ').replace(/\s+/g, ' ').trim();
  const escapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

  const TOPICS = [
    { id: 'emergency', terms: ['emergencia', 'urgencia', 'urgente', 'emergency', 'urgent', 'toothache', 'dolor', 'me duele', 'sangrado', 'bleeding', 'swelling', 'hinchazon', 'fractura', 'broken tooth'] },
    { id: 'pricing', terms: ['precio', 'precios', 'cuanto cuesta', 'cuanto vale', 'coste', 'costo', 'price', 'pricing', 'cost', 'fee', 'how much', 'financiacion', 'financing', 'cuotas', 'installments'] },
    { id: 'hours', terms: ['horario', 'horarios', 'abren', 'abierto', 'cierra', 'abren hoy', 'opening hours', 'business hours', 'open', 'close', 'saturday', 'sunday', 'lunes', 'sabado', 'domingo'] },
    { id: 'location', terms: ['direccion', 'ubicacion', 'donde estan', 'como llegar', 'mapa', 'location', 'address', 'directions', 'where are you', 'map'] },
    { id: 'booking', terms: ['cita', 'reservar', 'reserva', 'agendar', 'pedir cita', 'appointment', 'book', 'booking', 'schedule', 'consultation', 'valoracion'] },
    { id: 'insurance', terms: ['seguro', 'seguros', 'aseguradora', 'aseguradoras', 'cobertura', 'insurance', 'insurer', 'coverage', 'dental plan'] },
  ];

  const textFor = (value, lang) => {
    if (value == null) return '';
    if (typeof value === 'object') return value[lang] || value.es || value.en || '';
    return String(value);
  };
  const isPlaceholder = (value) => !value || /\[[^\]]+\]|YOUR_FORM_ID/i.test(String(value));
  const listJoin = (list, lang) => list.length < 2 ? (list[0] || '') : `${list.slice(0, -1).join(', ')}${lang === 'en' ? ' and ' : ' y '}${list[list.length - 1]}`;

  function answer(query, cfg, language) {
    const lang = language === 'en' ? 'en' : 'es';
    const q = normalize(query);
    const c = cfg || {};
    const tr = (es, en) => lang === 'en' ? en : es;

    const ranked = TOPICS.map((topic) => ({
      id: topic.id,
      score: topic.terms.reduce((sum, term) => sum + (q.includes(normalize(term)) ? (normalize(term).includes(' ') ? 3 : 1) : 0), 0),
    })).sort((a, b) => b.score - a.score);
    const topic = ranked[0] && ranked[0].score > 0 ? ranked[0].id : '';

    if (topic === 'emergency') {
      const phone = c.contact && (c.contact.phoneFormatted || c.contact.phone);
      const call = !isPlaceholder(phone) ? `${tr('Llama ahora al ', 'Call us now at ')}${phone}. ` : '';
      return tr(
        `Si se trata de una urgencia dental, contacta directamente con la clínica para que el equipo valore la atención prioritaria. ${call}También puedes solicitar una cita desde el formulario del sitio. Este asistente no puede diagnosticar ni indicar tratamientos.`,
        `For a dental emergency, contact the clinic directly so the team can advise on priority care. ${call}You can also request an appointment using the booking form. This assistant cannot diagnose or recommend treatment.`
      );
    }

    if (topic === 'pricing') {
      const services = Array.isArray(c.services) ? c.services : [];
      const items = services.slice(0, 4).map((service) => {
        const title = textFor(service.title, lang);
        const price = textFor(service.price, lang);
        if (!title || isPlaceholder(title) || isPlaceholder(price)) return '';
        return `${title}: ${price}`;
      }).filter(Boolean);
      const finance = c.financing && textFor(c.financing.subheadline, lang);
      const financeLine = finance && !isPlaceholder(finance) ? ` ${finance}` : '';
      const priceLine = items.length ? `${tr('Algunos precios publicados: ', 'Some listed prices: ')}${listJoin(items, lang)}. ` : '';
      return tr(
        `${priceLine}El coste final depende de una valoración individual. ${financeLine}Para un presupuesto exacto, solicita una cita de valoración.`,
        `${priceLine}The final cost depends on an individual assessment. ${financeLine}Please book a consultation for an exact quote.`
      );
    }

    if (topic === 'hours') {
      const hours = Array.isArray(c.hours) ? c.hours : [];
      const rows = hours.map((row) => {
        const day = textFor(row.days, lang);
        const time = textFor(row.time, lang);
        if (!day || !time || isPlaceholder(time)) return '';
        return `${day}: ${time}`;
      }).filter(Boolean);
      if (rows.length && rows.length === hours.length) return `${tr('Nuestro horario es: ', 'Our opening hours are: ')}${rows.join('; ')}.`;
      return tr('Consulta el horario actualizado en la sección de contacto o llama a la clínica antes de venir.', 'Check the latest hours in the Contact section or call the clinic before visiting.');
    }

    if (topic === 'location') {
      const address = c.contact && [c.contact.address, c.contact.addressLine2].filter((part) => part && !isPlaceholder(part)).join(', ');
      const maps = c.contact && c.contact.mapsUrl;
      const city = c.clinic && c.clinic.city;
      const place = address || (!isPlaceholder(city) ? city : '');
      const mapText = !isPlaceholder(maps) ? ` ${tr('Indicaciones: ', 'Directions: ')}${maps}` : '';
      if (place) return tr(`Estamos en ${place}.${mapText}`, `You can find us at ${place}.${mapText}`);
      return tr('Consulta la dirección y el mapa en la sección de contacto del sitio.', 'Find the address and map in the Contact section of the website.');
    }

    if (topic === 'booking') {
      return tr(
        'Para solicitar una cita, pulsa «Pedir cita» o «Book Visit», elige el tratamiento y la franja disponible, y deja tus datos de contacto. El equipo de la clínica confirmará la cita directamente.',
        'To request an appointment, select “Book Visit”, choose a treatment and an available time slot, then enter your contact details. The clinic team will confirm your appointment directly.'
      );
    }

    if (topic === 'insurance') {
      const faq = (Array.isArray(c.faqs) ? c.faqs : []).find((item) => {
        const question = normalize(textFor(item.q, lang));
        return /seguro|aseguradora|insurance|insurer|coverage/.test(question);
      });
      const configured = faq && textFor(faq.a, lang);
      if (configured && !/\[[^\]]+\]/.test(configured)) return configured;
      const providers = c.insurance && (c.insurance.providers || c.insurance.accepted || c.insurance.partners);
      if (Array.isArray(providers) && providers.length) return tr(`La clínica informa de estas aseguradoras: ${providers.join(', ')}. Confirma directamente con el equipo que tu plan y tratamiento tengan cobertura.`, `The clinic lists these insurers: ${providers.join(', ')}. Please confirm directly with the team that your plan and treatment are covered.`);
      return tr('La cobertura depende de tu póliza y del tratamiento. Contacta con la clínica para confirmar si trabajan con tu aseguradora y qué servicios incluye tu plan.', 'Coverage depends on your policy and treatment. Contact the clinic to confirm whether they work with your insurer and which services your plan covers.');
    }

    return tr(
      'Puedo ayudarte con precios, horarios, ubicación, citas, seguros y urgencias. Para cualquier otra consulta, llama a la clínica o utiliza el formulario de cita y el equipo te orientará.',
      'I can help with pricing, opening hours, directions, appointments, insurance and emergencies. For anything else, call the clinic or use the booking form and the team will be happy to help.'
    );
  }

  function mount(cfg) {
    const ai = cfg && cfg.aiAssistant;
    if (ai && ai.enabled === false) return;
    const name = (ai && ai.name) || 'Sofía';
    const t = (es, en) => (document.documentElement.lang || 'es').toLowerCase().startsWith('en') ? en : es;
    const div = document.createElement('div');
    div.className = 'ai-widget';
    div.innerHTML = `
      <button class="ai-launcher" aria-label="${t('Abrir asistente ', 'Open assistant ')}${escapeHtml(name)}" data-label-es="Abrir asistente ${escapeHtml(name)}" data-label-en="Open assistant ${escapeHtml(name)}" id="aiLaunch" aria-controls="aiPanel" aria-expanded="false"><span class="ai-launcher-icon" aria-hidden="true">✦</span></button>
      <section class="ai-panel" id="aiPanel" aria-hidden="true" aria-label="${t('Asistente de la clínica', 'Clinic assistant')}" data-label-es="Asistente de la clínica" data-label-en="Clinic assistant">
        <header class="ai-head"><div class="ai-title"><span class="ai-avatar" aria-hidden="true">✦</span><div><strong>${escapeHtml(name)}</strong><small><span class="ai-status-dot"></span><span class="ai-status-text" data-es="Guía de la clínica · en línea" data-en="Clinic guide · online">${t('Guía de la clínica · en línea', 'Clinic guide · online')}</span></small></div></div><button type="button" class="ai-close" id="aiClose" aria-label="${t('Cerrar asistente', 'Close assistant')}" data-label-es="Cerrar asistente" data-label-en="Close assistant">×</button></header>
        <div class="ai-body" id="aiBody" role="log" aria-live="polite" aria-relevant="additions"></div>
        <div class="ai-suggestions" id="aiSuggestions" aria-label="${t('Preguntas frecuentes', 'Frequently asked questions')}">
          <button type="button" data-question-es="¿Cuáles son los precios?" data-question-en="What are your prices?" data-es="Precios" data-en="Pricing">${t('Precios', 'Pricing')}</button>
          <button type="button" data-question-es="¿Cuál es el horario?" data-question-en="What are your opening hours?" data-es="Horario" data-en="Hours">${t('Horario', 'Hours')}</button>
          <button type="button" data-question-es="¿Dónde están ubicados?" data-question-en="Where are you located?" data-es="Ubicación" data-en="Directions">${t('Ubicación', 'Directions')}</button>
          <button type="button" data-question-es="¿Cómo puedo reservar una cita?" data-question-en="How do I book an appointment?" data-es="Cita" data-en="Booking">${t('Cita', 'Booking')}</button>
          <button type="button" data-question-es="¿Aceptan seguros dentales?" data-question-en="Do you accept dental insurance?" data-es="Seguro" data-en="Insurance">${t('Seguro', 'Insurance')}</button>
          <button type="button" data-question-es="Tengo una urgencia dental" data-question-en="I have a dental emergency" data-es="Urgencia" data-en="Emergency">${t('Urgencia', 'Emergency')}</button>
        </div>
        <form class="ai-foot" id="aiForm"><label class="sr-only ai-input-label" for="aiInput">${t('Escribe tu pregunta', 'Type your question')}</label><input type="text" class="ai-input" id="aiInput" placeholder="${t('Pregunta sobre la clínica…', 'Ask about the clinic…')}" data-placeholder-es="Pregunta sobre la clínica…" data-placeholder-en="Ask about the clinic…" autocomplete="off" maxlength="400"><button type="submit" class="ai-send" aria-label="${t('Enviar mensaje', 'Send message')}" data-label-es="Enviar mensaje" data-label-en="Send message">↑</button></form>
        <p class="ai-guard"><small data-es="Información general; no sustituye la valoración odontológica." data-en="General information; not a substitute for a dental assessment.">${t('Información general; no sustituye la valoración odontológica.', 'General information; not a substitute for a dental assessment.')}</small></p>
      </section>`;
    document.body.appendChild(div);

    const body = div.querySelector('#aiBody');
    const input = div.querySelector('#aiInput');
    const form = div.querySelector('#aiForm');
    const panel = div.querySelector('#aiPanel');
    const launcher = div.querySelector('#aiLaunch');
    let busy = false;

    function add(role, message) {
      const bubble = document.createElement('div');
      bubble.className = `ai-msg ${role}`;
      const urlMatch = role === 'assistant' && message.match(/https:\/\/[^\s]+/);
      if (urlMatch) {
        const href = urlMatch[0].replace(/[.,;!?]+$/, '');
        const start = message.indexOf(urlMatch[0]);
        bubble.append(document.createTextNode(message.slice(0, start)));
        const link = document.createElement('a');
        link.href = href; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = href;
        bubble.append(link, document.createTextNode(message.slice(start + urlMatch[0].length)));
      } else bubble.textContent = message;
      body.appendChild(bubble);
      body.scrollTop = body.scrollHeight;
    }
    function openPanel(open) {
      panel.classList.toggle('open', open);
      panel.setAttribute('aria-hidden', String(!open));
      launcher.setAttribute('aria-expanded', String(open));
      if (open) input.focus();
    }
    function syncLanguage() {
      const isEn = (document.documentElement.lang || 'es').toLowerCase().startsWith('en');
      div.querySelectorAll('[data-es][data-en]').forEach((el) => { el.textContent = isEn ? el.dataset.en : el.dataset.es; });
      div.querySelectorAll('[data-label-es][data-label-en]').forEach((el) => el.setAttribute('aria-label', isEn ? el.dataset.labelEn : el.dataset.labelEs));
      div.querySelectorAll('[data-question-es][data-question-en]').forEach((el) => { el.dataset.question = isEn ? el.dataset.questionEn : el.dataset.questionEs; });
      input.placeholder = isEn ? input.dataset.placeholderEn : input.dataset.placeholderEs;
      const label = div.querySelector('.ai-input-label');
      if (label) label.textContent = isEn ? 'Type your question' : 'Escribe tu pregunta';
    }
    function send(raw) {
      const question = String(raw || '').trim();
      if (!question || busy) return;
      input.value = '';
      add('user', question);
      busy = true;
      input.disabled = true;
      const typing = document.createElement('div');
      typing.className = 'ai-msg assistant ai-typing';
      typing.setAttribute('aria-label', t('Escribiendo', 'Typing'));
      typing.innerHTML = `<span>${t('Escribiendo', 'Typing')}</span><i></i><i></i><i></i>`;
      body.appendChild(typing);
      body.scrollTop = body.scrollHeight;
      global.setTimeout(() => {
        typing.remove();
        add('assistant', answer(question, cfg, (document.documentElement.lang || 'es').slice(0, 2)));
        busy = false;
        input.disabled = false;
        if (panel.classList.contains('open')) input.focus();
      }, 1000);
    }

    add('assistant', t(`Hola, soy ${name}. Puedo ayudarte con información práctica de la clínica. ¿Qué te gustaría saber?`, `Hi, I’m ${name}. I can help with practical information about the clinic. What would you like to know?`));
    launcher.addEventListener('click', () => openPanel(!panel.classList.contains('open')));
    div.querySelector('#aiClose').addEventListener('click', () => openPanel(false));
    form.addEventListener('submit', (event) => { event.preventDefault(); send(input.value); });
    div.querySelector('#aiSuggestions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-question]');
      if (button) send(button.dataset.question);
    });
    syncLanguage();
    const langObserver = new MutationObserver(syncLanguage);
    langObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && panel.classList.contains('open')) openPanel(false); });
  }

  global.DMEAI = { mount, answer, normalize };
})(typeof window !== 'undefined' ? window : globalThis);

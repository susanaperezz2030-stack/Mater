/**
 * Dental Master Enterprise — Professional Administration Dashboard
 * Tabs: overview, crm, appointments, automations, content, settings, analytics, users
 * RBAC: administrator, manager, receptionist, marketing
 */
(function (global) {
  'use strict';
  const S = global.DMEStorage;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  async function mount(container, cfg) {
    if (!container) return;

    function renderLogin() {
      const hostname = global.location?.hostname || '';
      const localDemo = global.location?.protocol === 'file:' || hostname === 'localhost' || hostname === '127.0.0.1';
      container.innerHTML = `
        <div class="adm-login">
          <div class="adm-login-card">
            <div class="adm-logo">✦ Dental Master Enterprise</div>
            <h2>Acceso al panel de administración</h2>
            <p class="dme-muted"><small>Acceso para personal autorizado.</small></p>
            <form id="admLoginForm" class="dme-form">
              <label>Email<input type="email" name="email" class="dme-input" autocomplete="username" required></label>
              <label>Contraseña<input type="password" name="pass" class="dme-input" autocomplete="current-password" required></label>
              <div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Entrar</button></div>
            </form>
            ${localDemo ? '<div class="adm-demo-creds"><small><strong>Solo demo local:</strong> admin@clinic.com / admin123</small></div>' : ''}
            <p class="dme-notice"><small><strong>Seguridad:</strong> cuentas demo disponibles solo en localhost. Para producción configura USERS y protege todas las rutas de datos con autorización; este panel no está listo para almacenar datos clínicos reales.</small></p>
          </div>
        </div>`;
      container.querySelector('#admLoginForm').onsubmit = async (e) => {
        e.preventDefault();
        const { email, pass } = Object.fromEntries(new FormData(e.target));
        const sess = await S.login(email, pass);
        if (!sess) return alert('Credenciales no válidas.');
        renderDashboard(sess);
      };
    }

    async function renderDashboard(sess) {
      const role = sess.role;
      container.innerHTML = `
        <div class="adm-shell">
          <header class="adm-bar">
            <div class="adm-bar-left">
              <a href="index.html" class="adm-back">← Ver sitio</a>
              <span class="adm-title">✦ <strong>Dental Master Enterprise</strong> · Panel</span>
            </div>
            <div class="adm-user"><span>${esc(sess.name)}</span> <span class="dme-badge">${esc(role)}</span> <button id="admLogout" class="dme-btn dme-btn-xs dme-btn-ghost">Salir</button></div>
          </header>
          <div class="adm-body">
            <aside class="adm-nav">
              <button class="adm-link active" data-tab="overview">Panel</button>
              <button class="adm-link" data-tab="crm">CRM · Leads</button>
              <button class="adm-link" data-tab="appointments">Citas</button>
              <button class="adm-link" data-tab="automations">Automatizaciones</button>
              <button class="adm-link" data-tab="content">Contenido</button>
              <button class="adm-link" data-tab="settings">Ajustes</button>
              <button class="adm-link" data-tab="analytics">Analítica</button>
              ${role === 'administrator' ? '<button class="adm-link" data-tab="users">Usuarios</button>' : ''}
            </aside>
            <main class="adm-content" id="admTabContent"></main>
          </div>
        </div>`;
      container.querySelector('#admLogout').onclick = async () => { await S.logout(); renderLogin(); };
      container.querySelectorAll('.adm-link').forEach((b) => {
        b.onclick = () => {
          container.querySelectorAll('.adm-link').forEach((x) => x.classList.remove('active'));
          b.classList.add('active');
          openTab(b.dataset.tab, sess);
        };
      });
      openTab('overview', sess);
    }

    async function openTab(tab, sess) {
      const c = container.querySelector('#admTabContent');
      if (!c) return;
      if (tab === 'overview') await renderOverview(c);
      else if (tab === 'crm') global.DMECRM ? global.DMECRM.render(c) : c.innerHTML = '<p>Módulo CRM no cargado.</p>';
      else if (tab === 'appointments') global.DMEAppointments ? global.DMEAppointments.render(c, cfg) : c.innerHTML = '<p>Módulo de citas no cargado.</p>';
      else if (tab === 'automations') global.DMEAutomations ? global.DMEAutomations.render(c) : c.innerHTML = '<p>Módulo de automatizaciones no cargado.</p>';
      else if (tab === 'content') renderContent(c);
      else if (tab === 'settings') renderSettings(c);
      else if (tab === 'analytics') renderAnalytics(c);
      else if (tab === 'users') renderUsers(c);
    }

    async function renderOverview(c) {
      const [leads, appts] = await Promise.all([S.getLeads(), S.getAppointments()]);
      const conv = leads.filter((l) => l.status === 'converted').length;
      const rate = leads.length ? Math.round((conv / leads.length) * 100) : 0;
      const pendingAppts = appts.filter((a) => a.status === 'pending');
      const upcoming = appts.filter((a) => a.status !== 'cancelled').slice(0, 5);
      const recent = leads.slice(0, 6);
      const stages = (S.PIPELINE_STAGES || []).map((stage) => ({ ...stage, count: leads.filter((lead) => lead.status === stage.id).length }));
      const stageMax = Math.max(1, ...stages.map((stage) => stage.count));
      c.innerHTML = `
        <div class="adm-section-head"><h2>Resumen del negocio</h2><p class="dme-muted"><small>Métricas calculadas en tiempo real a partir del CRM y de la agenda de citas.</small></p></div>
        <div class="adm-kpis">
          <div class="adm-kpi-card"><span class="kpi-num">${leads.length}</span><span class="kpi-label">Leads registrados</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${leads.filter((l) => l.status === 'new').length}</span><span class="kpi-label">Leads nuevos</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${pendingAppts.length}</span><span class="kpi-label">Citas pendientes de confirmar</span></div>
          <div class="adm-kpi-card"><span class="kpi-num">${rate}%</span><span class="kpi-label">Tasa de conversión</span></div>
        </div>
        <div class="adm-card adm-pipeline-card"><div class="adm-chart-head"><h3>Estado del pipeline</h3><span class="dme-badge">${leads.length} leads</span></div><div class="adm-chart" role="list" aria-label="Leads por estado">${stages.map((stage) => `<div class="adm-chart-row" role="listitem"><span class="adm-chart-label">${esc(stage.label)}</span><span class="adm-chart-track"><span class="adm-chart-bar" style="width:${Math.max(stage.count ? 5 : 0, Math.round(stage.count / stageMax * 100))}%"></span></span><strong class="adm-chart-value">${stage.count}</strong></div>`).join('')}</div></div>
        <div class="adm-two">
          <div class="adm-card"><h3>Próximas citas</h3>${upcoming.length ? `<table class="dme-table"><tbody>${upcoming.map((a) => `<tr><td>${esc(a.date)} ${esc(a.slot.split(' ')[0])}</td><td><strong>${esc(a.name)}</strong></td><td>${esc(a.service)}</td><td><span class="dme-badge">${esc(a.status)}</span></td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">No hay citas.</p>'}</div>
          <div class="adm-card"><h3>Últimos leads</h3>${recent.length ? `<table class="dme-table"><tbody>${recent.map((l) => `<tr><td><strong>${esc(l.name)}</strong></td><td><a href="tel:${esc(l.phone)}">${esc(l.phone)}</a></td><td>${esc(l.treatment || '—')}</td><td><span class="dme-badge">${esc(l.status)}</span></td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">No hay leads.</p>'}</div>
        </div>
        <div class="adm-card"><h3>Accesos rápidos</h3><div class="adm-quick"><a class="dme-btn dme-btn-primary" href="index.html" target="_blank">Abrir sitio web</a><button class="dme-btn" onclick="document.querySelector('[data-tab=crm]').click()">Ver pipeline completo</button><button class="dme-btn" onclick="document.querySelector('[data-tab=appointments]').click()">Gestionar citas</button><button class="dme-btn dme-btn-ghost" onclick="DMEStorage.resetDemo();location.reload()">Restaurar datos demo</button></div></div>`;
    }

    function renderContent(c) {
      c.innerHTML = `
        <div class="adm-section-head"><h2>Gestión de contenidos</h2><p class="dme-muted"><small>Edita los textos que se muestran en el sitio. Los cambios se guardan localmente para previsualización; para producción publica el archivo de configuración.</small></p></div>
        <div class="adm-two">
          <div class="adm-card"><h3>Tratamientos</h3><p class="dme-muted"><small>Los tratamientos se configuran en <code>siteData.js > services</code> (nombre, precio, duración, icono, categoría).</small></p><div id="svcList"></div></div>
          <div class="adm-card"><h3>Identidad y textos</h3><form id="contentForm" class="dme-form"><label>Nombre de la clínica<input name="name" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.name)}"></label><label>Lema principal (ES)<input name="tagline" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.tagline && cfg.clinic.tagline.es)}"></label><label>Ciudad<input name="city" class="dme-input" value="${esc(cfg.clinic && cfg.clinic.city)}"></label><label>Email de contacto<input name="email" class="dme-input" value="${esc(cfg.contact && cfg.contact.email)}"></label><div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Guardar</button></div></form></div>
        </div>
        <div class="adm-card"><h3>Reglas de veracidad</h3><p><small>Este producto obliga a sustituir las cifras de ejemplo (pacientes, reseñas, años) por datos verificados antes de publicar. No publiques valoraciones ni testimonios no comprobables.</small></p></div>`;
      const svcEl = c.querySelector('#svcList');
      svcEl.innerHTML = ((cfg && cfg.services) || []).map((s) => `<div class="adm-item"><div><strong>${esc(s.title?.es || s.title)}</strong> <small class="dme-muted">${esc(s.price || '')}</small></div><span class="dme-badge">${esc(s.category)}</span></div>`).join('');
      c.querySelector('#contentForm').onsubmit = (e) => {
        e.preventDefault();
        const d = Object.fromEntries(new FormData(e.target));
        cfg.clinic = cfg.clinic || {}; cfg.contact = cfg.contact || {};
        cfg.clinic.name = d.name; cfg.clinic.city = d.city;
        cfg.clinic.tagline = cfg.clinic.tagline || {}; cfg.clinic.tagline.es = d.tagline;
        cfg.contact.email = d.email;
        S.saveSettings({ ...S.getSettings(), clinicOverride: d });
        alert('Guardado en la sesión local. Actualiza la página del sitio para ver los cambios.');
      };
    }

    async function renderSettings(c) {
      const themes = await (fetch('assets/themes/themes.json').then((r) => r.json()).catch(() => []));
      const currentTheme = (cfg.settings && cfg.settings.theme) || 'luxury-studio';
      c.innerHTML = `
        <div class="adm-section-head"><h2>Ajustes del sitio</h2><p class="dme-muted"><small>Identidad visual, módulos activos y preferencias generales.</small></p></div>
        <div class="adm-card">
          <h3>Tema visual</h3>
          <p class="dme-muted"><small>Elige una de las 6 identidades visuales incluidas. Cada una define colores, contrastes y formas pensados para un tipo de clínica.</small></p>
          <div class="theme-grid">${themes.map((t) => `
            <div class="theme-card ${t.id === currentTheme ? 'selected' : ''}" data-theme="${esc(t.id)}">
              <div class="theme-swatch"><span style="background:${t.preview.bg}"></span><span style="background:${t.preview.ink}"></span><span style="background:${t.preview.accent}"></span><span style="background:${t.preview.accent2}"></span></div>
              <strong>${esc(t.name)}</strong>
              <small>${esc(t.desc)}</small>
            </div>`).join('')}</div>
        </div>
        <div class="adm-card">
          <h3>Módulos activos</h3>
          <form id="featsForm" class="adm-feats">${Object.entries((cfg.features) || {}).map(([k, v]) => `<label class="dme-check"><input type="checkbox" name="${k}" ${v ? 'checked' : ''}><span>${esc(k)}</span></label>`).join('')}</form>
          <div class="dme-actions"><button id="featsSave" class="dme-btn dme-btn-primary">Guardar módulos</button></div>
        </div>
        <div class="adm-card">
          <h3>Asistente FAQ local</h3>
          <p class="dme-muted"><small>Responde en español e inglés sobre precios, horarios, ubicación, citas, seguros y urgencias. Funciona directamente en el navegador: no necesita conexión a servicios de IA ni claves.</small></p>
        </div>`;
      c.querySelector('#featsSave').onclick = () => {
        const d = Object.fromEntries(new FormData(c.querySelector('#featsForm')));
        cfg.features = cfg.features || {};
        for (const k of Object.keys(cfg.features)) cfg.features[k] = k in d;
        S.saveSettings({ ...S.getSettings(), features: cfg.features });
        alert('Módulos actualizados.');
      };
      c.querySelector('.theme-grid').onclick = (e) => {
        const card = e.target.closest('.theme-card'); if (!card) return;
        c.querySelectorAll('.theme-card').forEach((x) => x.classList.remove('selected')); card.classList.add('selected');
        const t = card.dataset.theme; cfg.settings = cfg.settings || {}; cfg.settings.theme = t;
        localStorage.setItem('dme-preview-theme', t);
        document.documentElement.setAttribute('data-theme', t);
      };
    }

    function renderAnalytics(c) {
      const a = global.DMEAnalytics ? global.DMEAnalytics.stats() : { counts: {}, sources: {}, total: 0 };
      const labels = { 'click.phone': 'Clics en llamar', 'click.whatsapp': 'Clics en WhatsApp', 'booking.open': 'Aperturas del wizard de cita', 'booking.submit': 'Reservas completadas', 'click.exit_claim': 'Reclamaciones exit-intent' };
      c.innerHTML = `
        <div class="adm-section-head"><h2>Analítica y conversión</h2><p class="dme-muted"><small>Seguimiento de clics clave y orígenes UTM capturados en la navegación.</small></p></div>
        <div class="adm-kpis">${Object.entries(a.counts).map(([k, v]) => `<div class="adm-kpi-card"><span class="kpi-num">${v}</span><span class="kpi-label">${esc(labels[k] || k)}</span></div>`).join('') || '<p class="dme-empty">Sin eventos registrados aún.</p>'}</div>
        <div class="adm-card"><h3>Orígenes UTM</h3>${Object.keys(a.sources).length ? `<table class="dme-table"><thead><tr><th>utm_source</th><th>Eventos</th></tr></thead><tbody>${Object.entries(a.sources).map(([k, v]) => `<tr><td><code>${esc(k)}</code></td><td>${v}</td></tr>`).join('')}</tbody></table>` : '<p class="dme-empty">Sin parámetros UTM detectados. Prueba URLs con <code>?utm_source=...</code></p>'}</div>
        <p class="dme-notice"><small>Para medición formal añade el ID de GA4 en <code>integraciones.googleAnalyticsId</code> y asegúrate de configurar el aviso de cookies conforme a la normativa aplicable.</small></p>`;
    }

    function renderUsers(c) {
      const users = S.getUsers();
      c.innerHTML = `
        <div class="adm-section-head"><h2>Usuarios y permisos</h2><p class="dme-muted"><small>Roles disponibles: administrator, manager, receptionist, marketing.</small></p></div>
        <div class="adm-card"><table class="dme-table"><thead><tr><th>Nombre</th><th>Email</th><th>Rol</th><th></th></tr></thead><tbody>${users.map((u) => `<tr><td><strong>${esc(u.name)}</strong></td><td>${esc(u.email)}</td><td><span class="dme-badge">${esc(u.role)}</span></td><td>${users.length > 1 ? `<button class="dme-btn dme-btn-xs dme-btn-danger js-deluser" data-id="${u.id}">Eliminar</button>` : ''}</td></tr>`).join('')}</tbody></table></div>
        <div class="adm-card"><h3>Nuevo usuario</h3><form id="newUserForm" class="dme-form"><div class="dme-row"><label>Nombre<input name="name" class="dme-input" required></label><label>Email<input type="email" name="email" class="dme-input" required></label></div><div class="dme-row"><label>Contraseña<input name="pass" class="dme-input" value="demo123" required></label><label>Rol<select name="role" class="dme-select">${S.ROLES.map((r) => `<option value="${r}">${r}</option>`).join('')}</select></label></div><div class="dme-actions"><button type="submit" class="dme-btn dme-btn-primary">Crear</button></div></form></div>`;
      c.querySelector('#newUserForm').onsubmit = (e) => { e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)); S.saveUser(d); renderUsers(c); };
      c.querySelector('table').onclick = (e) => { const b = e.target.closest('.js-deluser'); if (b && confirm('¿Eliminar usuario?')) { S.deleteUser(b.dataset.id); renderUsers(c); } };
    }

    const sess = S.session();
    if (sess) renderDashboard(sess); else renderLogin();
  }

  global.DMEAdmin = { mount };
})(typeof window !== 'undefined' ? window : globalThis);

/**
 * Dental Master Enterprise — Storage Adapter
 * Provides a single async CRUD API that calls Cloudflare Pages Functions
 * (/api/*, backed by functions/api/*) when available and transparently falls back to localStorage
 * when offline, in demo mode or deployed as a pure static site.
 */
(function (global) {
  'use strict';

  const LS_KEYS = {
    leads: 'dme_leads',
    appointments: 'dme_appointments',
    automations: 'dme_automations',
    automationLogs: 'dme_automation_logs',
    users: 'dme_users',
    settings: 'dme_settings',
    events: 'dme_events',
    session: 'dme_session',
  };

  const SEED_USERS = [
    { id: 'u1', name: 'Admin', email: 'admin@clinic.com', pass: 'admin123', role: 'administrator' },
    { id: 'u2', name: 'Ana Gestora', email: 'manager@clinic.com', pass: 'demo123', role: 'manager' },
    { id: 'u3', name: 'Laura Recepción', email: 'recepcion@clinic.com', pass: 'demo123', role: 'receptionist' },
    { id: 'u4', name: 'Carlos Marketing', email: 'marketing@clinic.com', pass: 'demo123', role: 'marketing' },
  ];

  const SEED_LEADS = [
    { id: 'l1', name: 'María Gómez', phone: '+34600111222', email: 'maria@example.com', treatment: 'veneers', source: 'web', status: 'new', notes: 'Interesada en 8 carillas superiores', assignee: 'u3', followUp: '2026-11-12', createdAt: '2026-11-08T10:30:00Z' },
    { id: 'l2', name: 'David Navarro', phone: '+34611222333', email: 'david@example.com', treatment: 'invisalign', source: 'whatsapp', status: 'contacted', notes: 'Llamada hecha; pide valoración gratuita', assignee: 'u3', followUp: '2026-11-10', createdAt: '2026-11-07T16:00:00Z' },
    { id: 'l3', name: 'Sandra Ortiz', phone: '+34622333444', email: 'sandra@example.com', treatment: 'implants', source: 'google_ads', status: 'appointment_requested', notes: 'All-on-4 superior', assignee: 'u2', followUp: '2026-11-09', createdAt: '2026-11-06T09:15:00Z' },
    { id: 'l4', name: 'Pablo Ruiz', phone: '+34633444555', email: 'pablo@example.com', treatment: 'whitening', source: 'instagram', status: 'appointment_confirmed', notes: 'Cita 15 nov 11:00', assignee: 'u3', followUp: '2026-11-15', createdAt: '2026-11-05T12:00:00Z' },
    { id: 'l5', name: 'Claudia Vega', phone: '+34644555666', email: 'claudia@example.com', treatment: 'general', source: 'referral', status: 'consultation_done', notes: 'Revisión realizada; presupuesto carillas', assignee: 'u2', followUp: '2026-11-13', createdAt: '2026-11-02T11:00:00Z' },
    { id: 'l6', name: 'Jorge Blanco', phone: '+34655666777', email: 'jorge@example.com', treatment: 'emergency', source: 'phone', status: 'converted', notes: 'Urgencia tratada; fidelizado', assignee: 'u3', followUp: '', createdAt: '2026-10-30T17:00:00Z' },
    { id: 'l7', name: 'Elena Torres', phone: '+34666777888', email: 'elena@example.com', treatment: 'implants', source: 'facebook_ads', status: 'treatment_pending', notes: 'Esperando radiografía externa', assignee: 'u2', followUp: '2026-11-18', createdAt: '2026-10-25T14:00:00Z' },
    { id: 'l8', name: 'Rosa M.', phone: '+34677888999', email: 'rosa@example.com', treatment: 'rootcanal', source: 'exit_intent', status: 'lost', notes: 'No responde tras 3 intentos', assignee: 'u4', followUp: '', createdAt: '2026-10-20T10:00:00Z' },
  ];

  const SEED_APPOINTMENTS = [
    { id: 'a1', service: 'veneers', specialist: '[NOMBRE_DOCTOR]', location: 'goya', date: '2026-11-15', slot: 'Mañana (09:00–14:00)', name: 'Pablo Ruiz', phone: '+34633444555', email: 'pablo@example.com', notes: 'Primera valoración', status: 'confirmed', createdAt: '2026-11-05T12:00:00Z' },
    { id: 'a2', service: 'invisalign', specialist: '[NOMBRE_DOCTOR]', location: '', date: '2026-11-16', slot: 'Tarde (14:00–18:00)', name: 'Sandra Ortiz', phone: '+34622333444', email: 'sandra@example.com', notes: 'Estudio ortodóntico', status: 'pending', createdAt: '2026-11-06T09:15:00Z' },
    { id: 'a3', service: 'general', specialist: '[NOMBRE_DOCTOR]', location: 'chamartin', date: '2026-11-10', slot: 'Mañana (09:00–14:00)', name: 'Claudia Vega', phone: '+34644555666', email: 'claudia@example.com', notes: 'Revisión anual', status: 'completed', createdAt: '2026-11-02T11:00:00Z' },
  ];

  const SEED_AUTOMATIONS = [
    { id: 'auto-new-inquiry', name: 'Nueva solicitud de información', trigger: 'lead.created', condition: 'true', action: 'internal_notification', actionDetail: 'Notificar al equipo por email interno', enabled: true, lastRun: '2026-11-08T10:30:10Z' },
    { id: 'auto-appt-confirm', name: 'Confirmación de cita', trigger: 'appointment.confirmed', condition: 'true', action: 'email_patient', actionDetail: 'Enviar email con fecha, hora y ubicación', enabled: true, lastRun: '2026-11-05T12:02:00Z' },
    { id: 'auto-reminder', name: 'Recordatorio 24 h antes', trigger: 'appointment.reminder_due', condition: 'true', action: 'sms_patient', actionDetail: 'SMS con botón de confirmación', enabled: true, lastRun: null },
    { id: 'auto-missed', name: 'Seguimiento de cita no presentada', trigger: 'appointment.no_show', condition: 'true', action: 'whatsapp_followup', actionDetail: 'Mensaje amable para reprogramar', enabled: false, lastRun: null },
    { id: 'auto-review', name: 'Solicitud de reseña en Google', trigger: 'appointment.completed', condition: 'appointment.service != "emergency"', action: 'email_review_link', actionDetail: 'Email con enlace directo a la ficha de Google', enabled: true, lastRun: '2026-11-02T11:05:00Z' },
    { id: 'auto-reactivate', name: 'Reactivación de pacientes inactivos', trigger: 'schedule.monthly', condition: 'months_since_last_visit >= 12', action: 'email_recall', actionDetail: 'Recordatorio de revisión anual', enabled: false, lastRun: null },
    { id: 'auto-stalled', name: 'Seguimiento de consultas sin respuesta', trigger: 'schedule.daily', condition: 'lead.status == "new" && lead.age_hours >= 48', action: 'task_assign', actionDetail: 'Crear tarea para recepción', enabled: true, lastRun: null },
  ];

  function read(k, fallback) {
    try { const raw = localStorage.getItem(k); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
  }
  function write(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }

  function initSeeds() {
    if (!localStorage.getItem(LS_KEYS.users)) write(LS_KEYS.users, SEED_USERS);
    if (!localStorage.getItem(LS_KEYS.leads)) write(LS_KEYS.leads, SEED_LEADS);
    if (!localStorage.getItem(LS_KEYS.appointments)) write(LS_KEYS.appointments, SEED_APPOINTMENTS);
    if (!localStorage.getItem(LS_KEYS.automations)) write(LS_KEYS.automations, SEED_AUTOMATIONS);
    if (!localStorage.getItem(LS_KEYS.automationLogs)) write(LS_KEYS.automationLogs, []);
    if (!localStorage.getItem(LS_KEYS.events)) write(LS_KEYS.events, []);
    if (!localStorage.getItem(LS_KEYS.settings)) write(LS_KEYS.settings, { demoMode: true });
  }

  async function api(path, opts) {
    try {
      const res = await fetch(path, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, ...opts });
      if (!res.ok) return null;
      return await res.json();
    } catch { return null; }
  }

  // --- Auth ---
  async function login(email, pass) {
    const hostname = global.location?.hostname || '';
    const localDemo = global.location?.protocol === 'file:' || hostname === 'localhost' || hostname === '127.0.0.1';
    let response = null;
    try {
      response = await fetch('/api/auth', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, pass }) });
      if (response.ok) {
        const remote = await response.json();
        if (remote && remote.ok) { write(LS_KEYS.session, remote.session); return remote.session; }
        return null;
      }
      if (!localDemo || ![404, 501].includes(response.status)) return null;
    } catch {
      if (!localDemo) return null;
    }
    const users = read(LS_KEYS.users, SEED_USERS);
    const u = users.find((x) => x.email.toLowerCase() === (email || '').toLowerCase() && x.pass === pass);
    if (!u) return null;
    const session = { id: u.id, name: u.name, email: u.email, role: u.role, token: 'local-' + Date.now() };
    write(LS_KEYS.session, session);
    return session;
  }
  function session() { return read(LS_KEYS.session, null); }
  async function logout() {
    localStorage.removeItem(LS_KEYS.session);
    try { await fetch('/api/auth', { method: 'DELETE', credentials: 'same-origin' }); } catch {}
  }

  // --- Leads ---
  async function getLeads() {
    return (await api('/api/leads')) || read(LS_KEYS.leads, SEED_LEADS);
  }
  async function saveLead(l) {
    l.id = l.id || 'l' + Date.now();
    l.createdAt = l.createdAt || new Date().toISOString();
    const remote = await api('/api/leads', { method: 'POST', body: JSON.stringify(l) });
    const list = read(LS_KEYS.leads, SEED_LEADS).filter((x) => x.id !== l.id);
    list.unshift(remote || l);
    write(LS_KEYS.leads, list);
    logEvent({ type: 'lead.created', leadId: l.id, source: l.source || 'web' });
    runAutomationsFor('lead.created', l);
    return remote || l;
  }
  async function updateLead(id, patch) {
    const list = read(LS_KEYS.leads, SEED_LEADS);
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return null;
    list[i] = { ...list[i], ...patch, updatedAt: new Date().toISOString() };
    write(LS_KEYS.leads, list);
    await api('/api/leads', { method: 'PUT', body: JSON.stringify(list[i]) });
    return list[i];
  }
  async function deleteLead(id) {
    const list = read(LS_KEYS.leads, SEED_LEADS).filter((x) => x.id !== id);
    write(LS_KEYS.leads, list);
    await api('/api/leads', { method: 'DELETE', body: JSON.stringify({ id }) });
  }

  // --- Appointments ---
  async function getAppointments() {
    return (await api('/api/appointments')) || read(LS_KEYS.appointments, SEED_APPOINTMENTS);
  }
  async function saveAppointment(a) {
    const isUpdate = Boolean(a.id);
    a.id = a.id || 'a' + Date.now();
    a.createdAt = a.createdAt || new Date().toISOString();
    a.status = a.status || 'pending';
    const list = read(LS_KEYS.appointments, SEED_APPOINTMENTS);
    const conflict = list.find((x) => x.id !== a.id && x.status !== 'cancelled' && x.date === a.date && x.slot === a.slot && (x.location || '') === (a.location || ''));
    if (conflict) return { ok: false, conflict: true, reason: 'slot_taken' };
    const remote = await api('/api/appointments', { method: isUpdate ? 'PUT' : 'POST', body: JSON.stringify(a) });
    const saved = remote || a;
    const index = list.findIndex((x) => x.id === a.id);
    if (index >= 0) list[index] = saved;
    else list.unshift(saved);
    write(LS_KEYS.appointments, list);
    if (isUpdate) return { ok: true, appointment: saved };
    logEvent({ type: 'appointment.created', apptId: a.id });
    runAutomationsFor('appointment.created', a);
    return { ok: true, appointment: saved };
  }
  async function cancelAppointment(id, reason) {
    const list = read(LS_KEYS.appointments, SEED_APPOINTMENTS);
    const a = list.find((x) => x.id === id);
    if (a) { a.status = 'cancelled'; a.cancelReason = reason || ''; write(LS_KEYS.appointments, list); }
    await api('/api/appointments', { method: 'PUT', body: JSON.stringify({ id, status: 'cancelled', cancelReason: reason }) });
  }
  async function rescheduleAppointment(id, date, slot) {
    const list = read(LS_KEYS.appointments, SEED_APPOINTMENTS);
    const a = list.find((x) => x.id === id);
    if (!a) return { ok: false };
    const conflict = list.find((x) => x.id !== id && x.status !== 'cancelled' && x.date === date && x.slot === slot && (x.location || '') === (a.location || ''));
    if (conflict) return { ok: false, conflict: true };
    a.date = date; a.slot = slot; a.status = 'pending';
    write(LS_KEYS.appointments, list);
    await api('/api/appointments', { method: 'PUT', body: JSON.stringify(a) });
    return { ok: true, appointment: a };
  }

  // --- Automations ---
  function getAutomations() { return read(LS_KEYS.automations, SEED_AUTOMATIONS); }
  function saveAutomation(a) {
    const list = getAutomations().filter((x) => x.id !== a.id);
    list.push(a); write(LS_KEYS.automations, list); return a;
  }
  function getAutomationLogs() { return read(LS_KEYS.automationLogs, []); }
  function runAutomationsFor(trigger, payload) {
    const autos = getAutomations().filter((x) => x.enabled && x.trigger === trigger);
    const logs = getAutomationLogs();
    autos.forEach((a) => {
      a.lastRun = new Date().toISOString();
      logs.unshift({ id: 'log' + Date.now(), automationId: a.id, automationName: a.name, trigger, action: a.action, payload, at: a.lastRun, ok: true });
    });
    write(LS_KEYS.automationLogs, logs.slice(0, 200));
    write(LS_KEYS.automations, getAutomations());
  }

  // --- Analytics events ---
  function logEvent(ev) {
    ev.at = ev.at || new Date().toISOString();
    const events = read(LS_KEYS.events, []);
    events.unshift(ev);
    write(LS_KEYS.events, events.slice(0, 1000));
  }
  function getEvents() { return read(LS_KEYS.events, []); }

  // --- Settings ---
  function getSettings() { return read(LS_KEYS.settings, { demoMode: true }); }
  function saveSettings(s) { write(LS_KEYS.settings, s); }

  // --- Users (RBAC) ---
  function getUsers() { return read(LS_KEYS.users, SEED_USERS); }
  function saveUser(u) {
    u.id = u.id || 'u' + Date.now();
    const list = getUsers().filter((x) => x.id !== u.id); list.push(u);
    write(LS_KEYS.users, list); return u;
  }
  function deleteUser(id) { write(LS_KEYS.users, getUsers().filter((x) => x.id !== id)); }

  // --- Reset demo data ---
  function resetDemo() {
    write(LS_KEYS.leads, SEED_LEADS); write(LS_KEYS.appointments, SEED_APPOINTMENTS);
    write(LS_KEYS.automations, SEED_AUTOMATIONS); write(LS_KEYS.automationLogs, []);
    write(LS_KEYS.events, []);
  }

  initSeeds();

  global.DMEStorage = {
    login, session, logout,
    getLeads, saveLead, updateLead, deleteLead,
    getAppointments, saveAppointment, cancelAppointment, rescheduleAppointment,
    getAutomations, saveAutomation, getAutomationLogs, runAutomationsFor,
    logEvent, getEvents, getSettings, saveSettings,
    getUsers, saveUser, deleteUser, resetDemo,
    PIPELINE_STAGES: [
      { id: 'new', label: 'Nuevo' },
      { id: 'contacted', label: 'Contactado' },
      { id: 'appointment_requested', label: 'Cita solicitada' },
      { id: 'appointment_confirmed', label: 'Cita confirmada' },
      { id: 'consultation_done', label: 'Consulta realizada' },
      { id: 'treatment_pending', label: 'Tratamiento pendiente' },
      { id: 'converted', label: 'Convertido' },
      { id: 'lost', label: 'Perdido' },
    ],
    ROLES: ['administrator', 'manager', 'receptionist', 'marketing'],
  };
})(typeof window !== 'undefined' ? window : globalThis);

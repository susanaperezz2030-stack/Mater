import assert from 'node:assert/strict';

const store = new Map();
globalThis.localStorage = {
  getItem: (key) => store.has(key) ? store.get(key) : null,
  setItem: (key, value) => store.set(key, String(value)),
  removeItem: (key) => store.delete(key),
};
globalThis.window = {};
const calls = [];
globalThis.fetch = async (path, options = {}) => {
  calls.push({ path: String(path), method: options.method || 'GET', body: options.body ? JSON.parse(options.body) : null });
  if (String(path) === '/api/leads' && !options.method) return new Response(JSON.stringify([{ id: 'd1-lead', name: 'D1 Patient', phone: '+1 555 0100', status: 'new' }]), { status: 200 });
  if (String(path) === '/api/appointments' && !options.method) return new Response(JSON.stringify([{ id: 'd1-appt', name: 'D1 Patient', date: '2099-02-02', slot: 'AM', status: 'pending' }]), { status: 200 });
  if (String(path) === '/api/leads' && options.method === 'POST') return new Response(JSON.stringify(JSON.parse(options.body)), { status: 200 });
  if (String(path) === '/api/appointments' && options.method === 'POST') return new Response(JSON.stringify(JSON.parse(options.body)), { status: 200 });
  return new Response(JSON.stringify({ ok: true }), { status: 200 });
};
await import('../modules/storage-adapter.js');
const S = window.DMEStorage;
assert.deepEqual(await S.getLeads(), [{ id: 'd1-lead', name: 'D1 Patient', phone: '+1 555 0100', status: 'new' }]);
assert.deepEqual(await S.getAppointments(), [{ id: 'd1-appt', name: 'D1 Patient', date: '2099-02-02', slot: 'AM', status: 'pending' }]);
await S.saveLead({ name: 'New D1 lead', phone: '+1 555 0101' });
const savedAppt = await S.saveAppointment({ name: 'New D1 appointment', phone: '+1 555 0102', date: '2099-02-03', slot: 'PM' });
assert.equal(savedAppt.ok, true);
assert.ok(calls.some((call) => call.path === '/api/leads' && call.method === 'GET'));
assert.ok(calls.some((call) => call.path === '/api/leads' && call.method === 'POST'));
assert.ok(calls.some((call) => call.path === '/api/appointments' && call.method === 'GET'));
assert.ok(calls.some((call) => call.path === '/api/appointments' && call.method === 'POST'));
assert.ok(calls.every((call) => !call.path.includes('/functions/') && !/chat/i.test(call.path)));
console.log('CLOUDFLARE ROUTE TESTS PASSED: CRM and appointments use /api/* Functions routes; no remote chat route');

/**
 * DENTAL MASTER ENTERPRISE — Comprehensive E2E test suite
 * Tests the enhanced product: themes, i18n, slider, calculator, booking CRM flow,
 * conflict detection, exit intent, gallery modal, FAQ, admin dashboard, analytics, SEO.
 */
import puppeteer from 'puppeteer-core';
import fs from 'fs';

const BASE = process.env.BASE || 'http://localhost:8000';
const SHOT_DIR = '/home/ubuntu/workspace/screenshots';
fs.mkdirSync(SHOT_DIR, { recursive: true });

const results = [];
function report(name, ok, detail = '') {
  results.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}${detail ? ' — ' + detail : ''}`);
}

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/chromium',
  headless: 'new',
  protocolTimeout: 60000,
  args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--window-size=1400,900', '--lang=es'],
});

try {
  const page = await browser.newPage();
  page.setDefaultTimeout(60000);
  page.setDefaultNavigationTimeout(60000);
  await page.setViewport({ width: 1400, height: 900 });
  async function openSectionPage(slug) {
    await page.goto(`${BASE}/${slug}.html`, { waitUntil: 'load', timeout: 30000 });
    await page.waitForSelector(`body[data-page="${slug}"]`);
    await page.waitForFunction(() => { const p = document.querySelector('#preloader'); return !p || p.style.display === 'none' || p.classList.contains('done'); }, { timeout: 6000 }).catch(() => {});
    await new Promise((r) => setTimeout(r, 250));
  }

  // 1. Load index.html
  await page.goto(`${BASE}/index.html`, { waitUntil: 'load', timeout: 30000 });
  await page.evaluate(() => { localStorage.setItem('dental-cookie', 'necessary'); localStorage.removeItem('dental-lang'); localStorage.removeItem('dental-theme'); });
  await page.evaluate(() => sessionStorage.removeItem('dental-exit-shown'));
  await page.waitForFunction(() => { const p = document.querySelector('#preloader'); return !p || p.style.display === 'none' || p.classList.contains('done'); }, { timeout: 8000 });
  await new Promise((r) => setTimeout(r, 900));

  const themeAttr = await page.$eval('html', (e) => e.getAttribute('data-theme'));
  report('1. Default theme attribute present on <html>', ['luxury-studio','modern-family','cosmetic','premium-implants','orthodontic','boutique'].includes(themeAttr), `theme=${themeAttr}`);
  const homeSummary = await page.$eval('#resumen-menu', (e) => getComputedStyle(e).display !== 'none' && e.querySelectorAll('.menu-summary-card').length === 7);
  const homeServicesHidden = await page.$eval('#servicios', (e) => getComputedStyle(e).display === 'none');
  report('1b. Homepage shows a concise seven-link menu summary, not all sections', homeSummary && homeServicesHidden);
  await page.$eval('#hamb', (e) => e.click());
  const menuOpened = await page.$eval('#mobileNav', (e) => e.classList.contains('active') && e.getAttribute('aria-hidden') === 'false');
  await page.$eval('#navServicesToggle', (e) => e.click());
  const submenuOpened = await page.$eval('#serviceSubMenu', (e) => !e.hidden && e.querySelectorAll('a').length >= 6);
  await page.$eval('#mobileClose', (e) => e.click());
  const menuClosed = await page.$eval('#mobileNav', (e) => !e.classList.contains('active') && e.getAttribute('aria-hidden') === 'true');
  report('1c. Full-screen overlay opens, expands Services accordion and closes accessibly', menuOpened && submenuOpened && menuClosed);
  const desktopActionBarHidden = await page.$eval('#mobileActionBar', (e) => getComputedStyle(e).display === 'none');
  report('1d. Three-action floating bar stays hidden on desktop', desktopActionBarHidden);
  const referenceHeaderOrder = await page.evaluate(() => {
    const header = document.querySelector('#header');
    const brand = header.querySelector('.brand').getBoundingClientRect();
    const phone = header.querySelector('.header-phone').getBoundingClientRect();
    const menu = header.querySelector('#hamb').getBoundingClientRect();
    const theme = document.querySelector('#mobileNav #themeToggle');
    const language = document.querySelector('#mobileNav #langSwitch');
    return brand.left < phone.left && phone.left < menu.left && !!theme && !!language && !header.querySelector('#themeToggle,#langSwitch');
  });
  report('1e. Header follows reference: boxed wordmark, call and menu; theme/language remain in overlay', referenceHeaderOrder);
  const noDuplicateMobileBar = await page.evaluate(() => document.querySelectorAll('.mobile-action-bar').length === 0 && document.querySelectorAll('#mobileActionBar').length === 1);
  report('1f. Legacy lower access buttons are removed; only the compact pill remains', noDuplicateMobileBar);

  // 2. Screenshots: desktop hero
  await page.screenshot({ path: `${SHOT_DIR}/01-desktop-hero.png` });
  report('2. Desktop hero screenshot captured', fs.existsSync(`${SHOT_DIR}/01-desktop-hero.png`));

  // 3. Language switch ES -> EN -> ES
  await page.evaluate(() => DENTAL_APP.setLanguage('es'));
  const esTitle = await page.title();
  await page.evaluate(() => DENTAL_APP.setLanguage('en'));
  const enTitle = await page.title();
  const langEn = await page.$eval('html', (e) => e.lang);
  await page.evaluate(() => DENTAL_APP.setLanguage('es'));
  report('3. Bilingual i18n toggle changes title and html lang', enTitle !== esTitle && langEn === 'en', `EN="${enTitle.slice(0,35)}..." ES="${esTitle.slice(0,35)}..." lang=${langEn}`);

  // 4. Dark theme toggle
  const darkBefore = await page.$eval('body', (b) => b.classList.contains('dark'));
  await page.$eval('#hamb', (e) => e.click());
  await page.$eval('#themeToggle', (e) => e.click());
  await new Promise((r) => setTimeout(r, 100));
  const darkAfter = await page.$eval('body', (b) => b.classList.contains('dark'));
  const rootDark = await page.$eval('html', (e) => e.classList.contains('dark'));
  const darkSurface = await page.$eval('.trust-card', (e) => getComputedStyle(e).backgroundColor);
  await page.$eval('#themeToggle', (e) => e.click());
  await page.$eval('#mobileClose', (e) => e.click());
  report('4. Dark/light theme toggle updates body and root theme tokens', darkBefore !== darkAfter && rootDark === darkAfter && darkSurface !== 'rgb(255, 255, 255)', `before=${darkBefore} after=${darkAfter} root=${rootDark} card=${darkSurface}`);

  // 5. Before/after comparison slider
  await openSectionPage('casos');
  const stage = await page.$('#baStage');
  const box = await stage.boundingBox();
  await stage.focus();
  await page.keyboard.press('ArrowRight');
  await page.keyboard.press('ArrowRight');
  await page.mouse.move(box.x + 20, box.y + 20);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.75, box.y + 20, { steps: 5 });
  await page.mouse.up();
  const valNow = await page.$eval('#baStage', (e) => +e.getAttribute('aria-valuenow'));
  report('5. Comparison slider responds to drag and updates aria-valuenow', valNow > 50, `now=${valNow}`);

  // 6. Extended financing calculator
  await openSectionPage('financiacion');
  await page.evaluate(() => { const s = document.querySelector('#calcAmount'); s.value = 6000; s.dispatchEvent(new Event('input')); });
  await page.click('.calc-month[data-months="24"]');
  const monthly = await page.$eval('#calcMonthly', (e) => +e.textContent.replace(/[^0-9]/g, ''));
  report('6. Financing calculator with down-payment recalculates correctly (6000/24=250)', Math.abs(monthly - 250) <= 2, `monthly=${monthly}`);

  // 7. Booking wizard -> persists lead + appointment into DMEStorage
  await page.$eval('#hamb', (e) => e.click());
  await page.$eval('.nav-booking.js-open-booking', (e) => e.click());
  await page.waitForSelector('.modal.open .service-opt', { timeout: 8000 });
  await page.$eval('.modal.open #serviceSelectGrid .service-opt[data-service="veneers"]', (e) => e.click());
  await page.$eval('.modal.open .wizard-panel.active .wizard-btn[data-next="2"]', (e) => e.click());
  await new Promise((r) => setTimeout(r, 200));
  await page.$eval('#fDate', (i) => (i.value = '2030-05-10'));
  await page.$eval('.modal.open .wizard-panel.active .slot-btn[data-slot="Tarde (14:00–18:00)"]', (e) => e.click());
  await page.$eval('.modal.open .wizard-panel.active .wizard-btn[data-next="3"]', (e) => e.click());
  await new Promise((r) => setTimeout(r, 200));
  await page.type('#fName', 'Test Paciente');
  await page.type('#fPhone', '+34600123456');
  await page.type('#fEmail', 'paciente@test.com');
  await page.type('#fNotes', 'Consulta de valoración E2E');
  await page.$eval('#modalSubmit', (e) => e.click());
  await new Promise((r) => setTimeout(r, 1400));
  const successVisible = await page.$eval('#wizardSuccess', (e) => getComputedStyle(e).display !== 'none');
  const bookingPass = await page.evaluate(() => ({
    active: document.querySelector('#bookingSuccessOverlay')?.classList.contains('active'),
    locked: document.body.classList.contains('booking-pass-open'),
    name: document.querySelector('#bookingPassName')?.textContent,
    treatment: document.querySelector('#bookingPassTreatment')?.textContent,
    date: document.querySelector('#bookingPassDate')?.textContent,
    time: document.querySelector('#bookingPassTime')?.textContent,
    status: document.querySelector('#bookingPassStatus')?.textContent,
    referenceBlock: !!document.querySelector('.booking-pass-reference'),
    calendar: !!document.querySelector('#bookingPassCalendar'),
  }));
  const storedAppts = await page.evaluate(() => JSON.parse(localStorage.getItem('dme_appointments') || '[]'));
  const storedLeads = await page.evaluate(() => JSON.parse(localStorage.getItem('dme_leads') || '[]'));
  const foundAppt = storedAppts.find((a) => a.date === '2030-05-10' && a.slot === 'Tarde (14:00–18:00)');
  const foundLead = storedLeads.find((l) => l.name === 'Test Paciente');
  const passValid = bookingPass.active && bookingPass.locked && bookingPass.name === 'Test Paciente' && /veneers|carilla/i.test(bookingPass.treatment) && bookingPass.date && bookingPass.time.includes('Tarde') && /PENDIENTE|AWAITING/i.test(bookingPass.status) && !bookingPass.referenceBlock && !bookingPass.calendar;
  report('7. Booking shows a request summary, pending status and no fake pass credentials', successVisible && passValid, JSON.stringify(bookingPass));
  await page.$eval('#bookingPassDone', (e) => e.click());
  const passDismissed = await page.$eval('#bookingSuccessOverlay', (e) => !e.classList.contains('active') && e.getAttribute('aria-hidden') === 'true');
  report('7b. Pass CTA closes the overlay and unlocks the booking page', passDismissed && !(await page.$eval('body', (e) => e.classList.contains('booking-pass-open'))));

  // 8. Slot conflict detection
  const conflictResult = await page.evaluate(async () => {
    return await DMEStorage.saveAppointment({
      service: 'invisalign', date: '2030-05-10', slot: 'Tarde (14:00–18:00)',
      location: '', name: 'Otro Paciente', phone: '+34600654321', email: 'otro@test.com', status: 'pending',
    });
  });
  report('8. Duplicate slot booking triggers conflict rejection', conflictResult && conflictResult.ok === false && conflictResult.conflict === true);

  // 9. Exit-intent popup captures lead with source exit_intent
  await page.evaluate(() => {
    sessionStorage.removeItem('dental-exit-shown');
    const m = document.querySelector('#bookingModal'); if (m) m.classList.remove('open');
  });
  await new Promise((r) => setTimeout(r, 300));
  await page.evaluate(() => document.dispatchEvent(new MouseEvent('mouseleave', { clientX: 700, clientY: 2, bubbles: true })));
  await new Promise((r) => setTimeout(r, 500));
  const exitOpen = await page.$eval('#exitModal', (e) => e.classList.contains('open'));
  await page.type('#exitName', 'Exit Lead');
  await page.type('#exitPhone', '+34600111999');
  await page.evaluate(() => document.querySelector('#exitForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true })));
  await new Promise((r) => setTimeout(r, 300));
  const exitLead = await page.evaluate(() => (JSON.parse(localStorage.getItem('dme_leads') || '[]')).find((l) => l.name === 'Exit Lead' && l.source === 'exit_intent'));
  report('9. Exit-intent popup opens on mouse leave and captures lead in CRM', exitOpen && !!exitLead);

  // 10. Gallery fullscreen modal
  await page.evaluate(() => { const em = document.querySelector('#exitModal'); if (em) em.classList.remove('open'); });
  await openSectionPage('casos');
  await page.evaluate(() => { const img = document.querySelector('.cases-grid .case-card img'); if (img) img.click(); });
  await new Promise((r) => setTimeout(r, 400));
  const modalOpen = await page.$eval('#galleryModal', (e) => e.classList.contains('open'));
  const capText = await page.$eval('#galleryModalCap', (e) => e.textContent);
  await page.keyboard.press('Escape');
  await new Promise((r) => setTimeout(r, 200));
  const modalClosed = await page.$eval('#galleryModal', (e) => !e.classList.contains('open'));
  report('10. Gallery case image opens fullscreen modal with caption and Escape closes it', modalOpen && !!capText && modalClosed, `cap="${capText.slice(0,30)}..."`);

  // 11. FAQ accordion single-open
  await openSectionPage('preguntas');
  const faqs = await page.$$('.faq-item');
  if (faqs.length >= 2) {
    await page.evaluate(() => { const f = document.querySelectorAll('.faq-item summary'); f[0].click(); f[1].click(); });
    await new Promise((r) => setTimeout(r, 100));
    const opened = await page.$$eval('.faq-item[open]', (xs) => xs.length);
    report('11. FAQ accordion keeps only one item open at once', opened === 1, `open=${opened}`);
  }

  // 12. Reviews swiper
  await openSectionPage('opiniones');
  const slides = await page.$$eval('.swiper-slide', (xs) => xs.length);
  report('12. Testimonials Swiper carousel initializes with slides', slides >= 5, `slides=${slides}`);

  // 13. Accessibility smoke
  const missingAlt = await page.$$eval('img:not([alt])', (xs) => xs.length);
  report('13. Accessibility smoke: every image has alt attribute', missingAlt === 0, `missingAlt=${missingAlt}`);

  // 14. Theme system: all 6 themes differ in tokens
  const themes = ['luxury-studio','modern-family','cosmetic','premium-implants','orthodontic','boutique'];
  const accents = [];
  for (const t of themes) {
    await page.evaluate((th) => document.documentElement.setAttribute('data-theme', th), t);
    const accent = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim());
    accents.push(accent);
  }
  const uniqueAccents = new Set(accents);
  report('14. All 6 themes produce distinct design token palettes', uniqueAccents.size === 6, accents.join(' | '));
  await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'luxury-studio'));

  // 15. Analytics UTM capture & click tracking
  await page.goto(`${BASE}/index.html?utm_source=adwords&utm_campaign=winter26`, { waitUntil: 'load', timeout: 30000 });
  await page.evaluate(() => { const a = document.querySelector('a[href^="tel:"]'); if (a) a.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  await page.evaluate(() => { const a = document.querySelector('#whatsappBtn'); if (a) a.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  const utm = await page.evaluate(() => JSON.parse(sessionStorage.getItem('dme_utm') || '{}'));
  const events = await page.evaluate(() => JSON.parse(localStorage.getItem('dme_events') || '[]'));
  report('15. UTM capture and phone-click event tracking functional', utm.utm_source === 'adwords' && events.some((e) => e.type === 'click.phone'), `utm_source=${utm.utm_source} events=${events.length}`);

  // 16. Admin dashboard E2E
  const adminPage = await browser.newPage();
  await adminPage.setViewport({ width: 1400, height: 900 });
  await adminPage.goto(`${BASE}/admin.html`, { waitUntil: 'load', timeout: 30000 });
  const loginCard = await adminPage.$('.adm-login-card');
  report('16a. Admin login screen renders with demo credentials', !!loginCard);
  await adminPage.type('#admLoginForm input[name="email"]', 'admin@clinic.com');
  await adminPage.type('#admLoginForm input[name="pass"]', 'admin123');
  await adminPage.evaluate(() => document.querySelector('#admLoginForm').dispatchEvent(new Event('submit', { cancelable: true, bubbles: true })));
  await new Promise((r) => setTimeout(r, 600));
  const kpis = await adminPage.$$eval('.adm-kpi-card', (xs) => xs.length);
  report('16b. Admin dashboard loads with KPI cards', kpis >= 4, `kpis=${kpis}`);
  await adminPage.screenshot({ path: `${SHOT_DIR}/02-admin-overview.png` });

  // CRM tab
  await adminPage.click('.adm-link[data-tab="crm"]');
  await new Promise((r) => setTimeout(r, 400));
  const stages = await adminPage.$$eval('.crm-col', (xs) => xs.length);
  report('16c. CRM pipeline renders the 8 sales stages', stages === 8, `stages=${stages}`);
  await adminPage.screenshot({ path: `${SHOT_DIR}/03-admin-crm-pipeline.png` });

  // Appointments tab
  await adminPage.click('.adm-link[data-tab="appointments"]');
  await new Promise((r) => setTimeout(r, 400));
  const apptCards = await adminPage.$$eval('.appt-card', (xs) => xs.length);
  const apptListRendered = await adminPage.$('#apptList');
  const emptyAppointments = await adminPage.$('.dme-empty');
  report('16d. Appointments tab renders D1 records or a clean empty state', !!apptListRendered && (apptCards > 0 || !!emptyAppointments), `cards=${apptCards}; empty=${!!emptyAppointments}`);
  await adminPage.screenshot({ path: `${SHOT_DIR}/04-admin-appointments.png` });

  await adminPage.click('#apptNewBtn');
  await adminPage.evaluate(() => {
    const form = document.querySelector('#apptNewForm');
    for (const [name, value] of [['name', 'Paciente E2E Simulado'], ['phone', '+15550109999'], ['date', '2099-03-14']]) {
      const input = form.querySelector(`[name="${name}"]`);
      input.value = value;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  await adminPage.click('#apptNewForm button[type="submit"]');
  await adminPage.waitForFunction(() => [...document.querySelectorAll('.appt-card')].some((card) => card.textContent.includes('Paciente E2E Simulado')));
  report('16d.1 Admin creates a simulated appointment and it appears in the list', await adminPage.$eval('#apptList', (el) => el.textContent.includes('Paciente E2E Simulado')));

  // Automations tab
  await adminPage.click('.adm-link[data-tab="automations"]');
  await new Promise((r) => setTimeout(r, 400));
  const autos = await adminPage.$$eval('.auto-card', (xs) => xs.length);
  report('16e. Automations tab shows workflow templates', autos >= 7, `workflows=${autos}`);

  // Settings tab: 6 theme previews
  await adminPage.click('.adm-link[data-tab="settings"]');
  await new Promise((r) => setTimeout(r, 400));
  const themeCards = await adminPage.$$eval('.theme-card', (xs) => xs.length);
  report('16f. Website settings shows 6 theme palettes', themeCards === 6, `themes=${themeCards}`);

  // Analytics tab
  await adminPage.click('.adm-link[data-tab="analytics"]');
  await new Promise((r) => setTimeout(r, 400));
  const akpi = await adminPage.$$eval('.adm-kpi-card', (xs) => xs.length);
  report('16g. Analytics tab aggregates click events', akpi >= 1);

  // Logout
  await adminPage.click('#admLogout');
  await adminPage.waitForSelector('.adm-login-card', { visible: true, timeout: 5000 }).catch(() => {});
  const loginBack = await adminPage.$('.adm-login-card');
  report('16h. Logout returns to login screen', !!loginBack);

  // 17. Legal pages reachable
  for (const pageName of ['aviso-legal.html', 'politica-privacidad.html', 'politica-cookies.html', '404.html']) {
    const p = await browser.newPage();
    const res = await p.goto(`${BASE}/${pageName}`, { waitUntil: 'load', timeout: 15000 });
    const h1 = await p.$eval('h1', (e) => e.textContent).catch(() => '');
    report(`17. Legal page ${pageName} returns HTTP 200 with content`, res && res.status() === 200 && h1.length > 2, `h1="${h1}"`);
    await p.close();
  }

  // 18. Mobile view screenshot
  await page.setViewport({ width: 390, height: 844 });
  await page.screenshot({ path: `${SHOT_DIR}/05-mobile-view.png` });
  const mobileBarSize = await page.$eval('#mobileActionBar', (e) => ({ visible: getComputedStyle(e).display !== 'none' && e.querySelectorAll('a,button').length === 3, width: e.getBoundingClientRect().width, height: e.getBoundingClientRect().height, label: e.querySelector('#mobileBookingButton [data-i18n="mob.book"]')?.textContent, ai: !!e.querySelector('#mobileAIAssistantButton'), aiIcon: !!e.querySelector('#mobileAIAssistantButton .fa-wand-magic-sparkles'), a11y: !!e.querySelector('#mobileA11yButton') }));
  report('18. Mobile pill shows call, book appointment and premium AI assistant', fs.existsSync(`${SHOT_DIR}/05-mobile-view.png`) && mobileBarSize.visible && mobileBarSize.width <= 301 && mobileBarSize.height <= 57 && /pedir cita/i.test(mobileBarSize.label) && mobileBarSize.ai && mobileBarSize.aiIcon && !mobileBarSize.a11y, `size=${mobileBarSize.width}x${mobileBarSize.height}`);
  await page.$eval('#mobileBookingButton', (e) => e.click());
  const mobileBookingOpens = await page.$eval('#bookingModal', (e) => e.classList.contains('open'));
  await page.$eval('#modalClose', (e) => e.click());
  report('18b. Pedir cita pill action opens the booking wizard', mobileBookingOpens);
  await page.$eval('#mobileAIAssistantButton', (e) => e.click());
  const localAssistantOpen = await page.waitForSelector('#aiPanel.open', { timeout: 5000 }).then(() => true).catch(() => false);
  const aiButtonExpanded = await page.$eval('#mobileAIAssistantButton', (e) => e.getAttribute('aria-expanded') === 'true');
  report('19. The pill AI button opens the local FAQ agent', localAssistantOpen && aiButtonExpanded);

  await adminPage.close();
  await page.close();
} finally {
  await browser.close();
}

const passed = results.filter((r) => r.ok).length;
console.log(`\n========================================`);
console.log(`E2E SUITE: ${passed}/${results.length} tests passed`);
console.log(`========================================`);
process.exit(passed === results.length ? 0 : 1);

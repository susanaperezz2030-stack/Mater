import assert from 'node:assert/strict';
import '../modules/ai-assistant.js';

const faq = globalThis.DMEAI;
const config = {
  clinic: { city: 'Madrid' },
  contact: { phoneFormatted: '+34 910 000 000', address: 'Calle Mayor 12', addressLine2: 'Madrid', mapsUrl: 'https://maps.example/clinic' },
  whatsapp: { number: '34910000000' },
  hours: [
    { days: { es: 'Lunes a viernes', en: 'Monday to Friday' }, time: { es: '09:00–19:00', en: '9 am–7 pm' } },
    { days: { es: 'Sábados', en: 'Saturdays' }, time: { es: '10:00–14:00', en: '10 am–2 pm' } },
  ],
  services: [{ title: { es: 'Implantes', en: 'Implants' }, price: 'desde 1200 €' }],
  financing: { subheadline: { es: 'Financiación flexible', en: 'Flexible financing' } },
  faqs: [{ q: { es: '¿Trabajan con seguros dentales?', en: 'Do you accept dental insurance?' }, a: { es: 'Aceptamos Seguros Aurora.', en: 'We accept Aurora Insurance.' } }],
};

assert.ok(faq, 'DMEAI module exports');
const cases = [
  ['¿Cuánto cuesta un implante?', 'es', '1200'],
  ['What are your prices?', 'en', '1200'],
  ['¿Cuál es el horario?', 'es', 'Lunes a viernes'],
  ['What are your opening hours?', 'en', 'Monday to Friday'],
  ['¿Dónde están ubicados?', 'es', 'Calle Mayor 12'],
  ['Where are you located?', 'en', 'Calle Mayor 12'],
  ['¿Cómo puedo reservar una cita?', 'es', 'Pedir cita'],
  ['How do I book an appointment?', 'en', 'Book Visit'],
  ['¿Aceptan seguros dentales?', 'es', 'Seguros Aurora'],
  ['Do you accept dental insurance?', 'en', 'Aurora Insurance'],
  ['Tengo una urgencia dental', 'es', '+34 910 000 000'],
  ['I have a dental emergency', 'en', '+34 910 000 000'],
];
for (const [question, lang, expected] of cases) {
  const response = faq.answer(question, config, lang);
  assert.ok(response.includes(expected), `${lang} response for ${question} should include ${expected}: ${response}`);
}
const unknownEs = faq.answer('¿Pueden ayudarme con una consulta legal?', config, 'es');
const unknownEn = faq.answer('Can you help with taxes?', config, 'en');
assert.match(unknownEs, /llama a la clínica|formulario de cita/i);
assert.match(unknownEn, /call the clinic|booking form/i);
assert.equal(faq.normalize('¿Dónde está la clínica?'), 'donde esta la clinica');
console.log(`ALL ${cases.length + 3} LOCAL FAQ TESTS PASSED`);

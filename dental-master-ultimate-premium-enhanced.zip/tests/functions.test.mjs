import { DatabaseSync } from 'node:sqlite';
import { pbkdf2Sync } from 'node:crypto';
import fs from 'fs';
import * as auth from '../functions/api/auth.js';
import * as leads from '../functions/api/leads.js';
import * as appointments from '../functions/api/appointments.js';
import * as automations from '../functions/api/automations.js';
import * as aichat from '../functions/api/ai-chat.js';
import * as settings from '../functions/api/settings.js';
import * as apiMiddleware from '../functions/api/_middleware.js';
import { signSession, verifySession } from '../functions/api/session.js';

function p(rel) { return new URL(rel, import.meta.url); }

function makeD1() {
  const db = new DatabaseSync(':memory:');
  db.exec(fs.readFileSync(p('../db/schema.sql'), 'utf8'));
  db.exec(fs.readFileSync(p('../db/seed.sql'), 'utf8'));
  function shim(sql) {
    let bound = [];
    return {
      bind(...args) { bound = args; return this; },
      run() { return db.prepare(sql).run(...bound); },
      all() { return { results: db.prepare(sql).all(...bound) }; },
      first() { return db.prepare(sql).get(...bound) || null; },
    };
  }
  return { prepare: shim };
}

function req(method, body) {
  return new Request('http://test', {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const env = { DB: makeD1(), DEMO_MODE: 'true', SESSION_SECRET: 'local-test-secret-with-more-than-32-bytes' };
let passes = 0;
function ok(cond, msg) { if (!cond) throw new Error(msg); passes++; }

// --- AUTH ---
const unconfiguredAuth = await auth.onRequestPost({ request: req('POST', { email: 'admin@clinic.com', pass: 'admin123' }), env: {} });
ok(unconfiguredAuth.status === 503, 'auth fails closed when no users or demo mode is configured');
const salt = Buffer.from('test-salt-value-16');
const hash = pbkdf2Sync('Strong-test-password-123!', salt, 100000, 32, 'sha256');
const hashedUserEnv = {
  SESSION_SECRET: env.SESSION_SECRET,
  USERS: JSON.stringify([{ id: 'hash-user', name: 'Hashed User', email: 'hash@example.test', role: 'administrator', passwordHash: `pbkdf2$100000$${salt.toString('base64url')}$${hash.toString('base64url')}` }]),
};
const hashedLogin = await auth.onRequestPost({ request: req('POST', { email: 'hash@example.test', pass: 'Strong-test-password-123!' }), env: hashedUserEnv });
ok(hashedLogin.status === 200, 'PBKDF2 password hash authenticates');
const wrongHashLogin = await auth.onRequestPost({ request: req('POST', { email: 'hash@example.test', pass: 'wrong' }), env: hashedUserEnv });
ok(wrongHashLogin.status === 401, 'PBKDF2 password hash rejects wrong password');
const plaintextProduction = await auth.onRequestPost({ request: req('POST', { email: 'plain@example.test', pass: 'secret' }), env: { SESSION_SECRET: env.SESSION_SECRET, USERS: JSON.stringify([{ id: 'plain', name: 'Plain', email: 'plain@example.test', role: 'administrator', pass: 'secret' }]) } });
ok(plaintextProduction.status === 503, 'production USERS config rejects plaintext password entries');
const a1 = await (await auth.onRequestPost({ request: req('POST', { email: 'admin@clinic.com', pass: 'admin123' }), env })).json();
ok(a1.ok && a1.session && a1.session.role === 'administrator', 'auth success');
const loginResponse = await auth.onRequestPost({ request: req('POST', { email: 'admin@clinic.com', pass: 'admin123' }), env });
const sessionCookie = loginResponse.headers.get('Set-Cookie')?.split(';')[0];
ok(!!sessionCookie && /HttpOnly/.test(loginResponse.headers.get('Set-Cookie')) && /SameSite=Strict/.test(loginResponse.headers.get('Set-Cookie')), 'login issues secure HttpOnly SameSite cookie');
ok(/Secure/.test(loginResponse.headers.get('Set-Cookie')) && /Max-Age=28800/.test(loginResponse.headers.get('Set-Cookie')), 'session cookie is Secure and expires after eight hours');
const validToken = sessionCookie.split('=')[1];
ok((await verifySession(validToken, env.SESSION_SECRET))?.role === 'administrator', 'signed session verifies');
ok(await verifySession(`${validToken}x`, env.SESSION_SECRET) === null, 'modified signed session is rejected');
const expiredToken = await signSession({ id: 'expired', role: 'administrator', exp: Math.floor(Date.now() / 1000) - 1 }, env.SESSION_SECRET);
ok(await verifySession(expiredToken, env.SESSION_SECRET) === null, 'expired signed session is rejected');
const middleware = (path, method, cookie = '', headers = {}) => apiMiddleware.onRequest({
  request: new Request(`https://clinic.test${path}`, { method, headers: { ...(cookie ? { Cookie: cookie } : {}), ...headers } }),
  env,
  next: async () => new Response('passed', { status: 200 }),
});
ok((await middleware('/api/leads', 'GET')).status === 401, 'anonymous CRM list denied');
ok((await middleware('/api/appointments', 'GET')).status === 401, 'anonymous appointment list denied');
ok((await middleware('/api/settings', 'GET')).status === 401 && (await middleware('/api/automations', 'GET')).status === 401, 'anonymous settings and automation access denied');
ok((await middleware('/api/appointments', 'POST')).status === 200, 'public appointment intake remains available');
ok((await middleware('/api/leads', 'GET', sessionCookie)).status === 200, 'admin can read CRM with signed cookie');
const managerToken = await signSession({ id: 'm1', name: 'Manager', email: 'manager@test.invalid', role: 'manager', exp: Math.floor(Date.now() / 1000) + 300 }, env.SESSION_SECRET);
ok((await middleware('/api/settings', 'GET', `dme_session=${managerToken}`)).status === 403, 'manager cannot access administrator-only settings');
ok((await middleware('/api/leads', 'POST', '', { Origin: 'https://attacker.invalid' })).status === 403, 'cross-origin form submission rejected');
const a2 = await auth.onRequestPost({ request: req('POST', { email: 'admin@clinic.com', pass: 'wrong' }), env });
ok(a2.status === 401, 'auth rejection 401');

// --- LEADS CRUD ---
const l1Response = await leads.onRequestPost({ request: req('POST', { id: 'client-chosen-id', name: 'Elena TEST', phone: '+34600999999', email: 'test@example.com', treatment: 'implants', source: 'web', status: 'administrator', assignee: 'attacker' }), env });
const l1 = await l1Response.json();
ok(l1Response.status === 201 && l1.id !== 'client-chosen-id' && l1.status === 'new' && !l1.assignee, 'lead created with server-controlled ID and status');
const invalidLead = await leads.onRequestPost({ request: req('POST', { name: '', phone: 'bad', email: 'bad-email' }), env });
ok(invalidLead.status === 400, 'invalid public lead rejected');
const list = await (await leads.onRequestGet({ env })).json();
ok(Array.isArray(list) && list.some((x) => x.id === l1.id), 'lead listed');
await leads.onRequestPut({ request: req('PUT', { id: l1.id, name: 'Elena UPDATED', phone: '+34600999999', status: 'converted' }), env });
const list2 = await (await leads.onRequestGet({ env })).json();
ok(list2.find((x) => x.id === l1.id).name === 'Elena UPDATED', 'lead updated');
await leads.onRequestDelete({ request: req('DELETE', { id: l1.id }), env });
const list3 = await (await leads.onRequestGet({ env })).json();
ok(!list3.some((x) => x.id === l1.id), 'lead deleted');

// --- APPOINTMENTS + CONFLICT CHECK ---
const ap1 = await (await appointments.onRequestPost({ request: req('POST', { service: 'veneers', date: '2030-01-01', slot: 'Mañana (09:00–14:00)', name: 'Ana', phone: '+34600000001' }), env })).json();
ok(ap1.id, 'appointment created');
const invalidAppointment = await appointments.onRequestPost({ request: req('POST', { service: 'veneers', date: '2030-02-31', slot: 'Mañana', name: 'Bad', phone: '123' }), env });
ok(invalidAppointment.status === 400, 'invalid appointment date and fields rejected');
const ap2 = await appointments.onRequestPost({ request: req('POST', { service: 'invisalign', date: '2030-01-01', slot: 'Mañana (09:00–14:00)', name: 'Beto', phone: '+34600000002' }), env });
ok(ap2.status === 409, 'slot conflict returns 409');
const apl = await (await appointments.onRequestGet({ env })).json();
ok(apl.some((x) => x.id === ap1.id), 'appointment listed');
await appointments.onRequestPut({ request: req('PUT', { id: ap1.id, status: 'confirmed', date: '2030-01-01', slot: 'Mañana (09:00–14:00)' }), env });
const aplUpdated = await (await appointments.onRequestGet({ env })).json();
ok(aplUpdated.filter((x) => x.id === ap1.id).length === 1 && aplUpdated.find((x) => x.id === ap1.id).status === 'confirmed', 'appointment update persists without duplicate');
let uniqueIndexBlocksRace = false;
try {
  env.DB.prepare("INSERT INTO appointments (id, service, date, slot, name, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .bind('race-duplicate', 'general', '2030-01-01', 'Mañana (09:00–14:00)', 'Concurrente', '+34600999999', 'pending').run();
} catch (error) { uniqueIndexBlocksRace = /unique/i.test(String(error)); }
ok(uniqueIndexBlocksRace, 'D1 unique index blocks concurrent active slot duplicate');

// --- AUTOMATIONS ---
const au1 = await automations.onRequestPost({ request: req('POST', { trigger: 'lead.created', payload: { test: 1 } }), env });
ok(au1.status === 200, 'automation triggered');
const au2 = await (await automations.onRequestGet({ env })).json();
ok(au2.logs && au2.logs.length > 0 && au2.logs[0].trigger === 'lead.created', 'automation logged');

// --- LEGACY AI ROUTE DISABLED: no provider calls or secret keys ---
const ai1 = await aichat.onRequestPost({ request: req('POST', { message: 'Hola' }), env: {} });
const ai1j = await ai1.json();
ok(ai1.status === 410 && ai1j.error === 'local_faq_assistant_enabled', 'legacy remote chat disabled');
const ai2 = await aichat.onRequestPost({ request: req('POST', { message: 'Tengo una pregunta' }), env: {} });
ok(ai2.status === 410, 'legacy chat route always stays disabled');

// --- SETTINGS ---
await settings.onRequestPut({ request: req('PUT', { clinicOverride: { name: 'New Name' } }), env });
const s = await (await settings.onRequestGet({ env })).json();
ok(s.clinicOverride && s.clinicOverride.name === 'New Name', 'settings round-trip');

console.log(`ALL ${passes} FUNCTIONS TESTS PASSED`);

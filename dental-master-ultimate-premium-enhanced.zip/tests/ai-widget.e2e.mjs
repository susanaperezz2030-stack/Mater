import assert from 'node:assert/strict';
import puppeteer from 'puppeteer-core';

const base = process.env.BASE || 'http://127.0.0.1:8000';
const browser = await puppeteer.launch({ executablePath: '/usr/bin/chromium', headless: 'new', args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'] });
try {
  const page = await browser.newPage();
  await page.setViewport({ width: 1360, height: 900 });
  await page.evaluateOnNewDocument(() => localStorage.setItem('dental-lang', 'es'));
  const forbiddenRequests = [];
  page.on('request', (request) => {
    if (/ai-chat|chat\/completions|\/api\/chat/i.test(request.url())) forbiddenRequests.push(request.url());
  });
  await page.goto(`${base}/index.html`, { waitUntil: 'load', timeout: 30000 });
  await page.waitForFunction(() => { const preloader = document.querySelector('#preloader'); return !preloader || getComputedStyle(preloader).visibility === 'hidden'; }, { timeout: 12000 });
  await page.waitForSelector('#aiLaunch', { timeout: 15000 });
  await page.click('#aiLaunch');
  await page.waitForSelector('#aiPanel.open');
  await new Promise((resolve) => setTimeout(resolve, 350));
  const started = Date.now();
  await page.click('#aiSuggestions [data-question-es]');
  await page.waitForSelector('.ai-typing', { timeout: 3000 });
  const typingLabel = await page.$eval('.ai-typing', (el) => el.textContent);
  assert.match(typingLabel, /Escribiendo/);
  await page.waitForFunction(() => document.querySelectorAll('#aiBody .ai-msg.assistant:not(.ai-typing)').length >= 2, { timeout: 5000 });
  const elapsed = Date.now() - started;
  assert.ok(elapsed >= 900, `typing delay should be about 1 second (observed ${elapsed}ms)`);
  const spanish = await page.$eval('#aiBody', (el) => el.textContent);
  assert.match(spanish, /valoración|presupuesto/i);

  await page.$eval('#hamb', (el) => el.click());
  await page.$eval('#langSwitch', (el) => el.click());
  await page.waitForFunction(() => document.documentElement.lang === 'en');
  await page.$eval('#mobileClose', (el) => el.click());
  await page.waitForFunction(() => document.querySelector('#aiSuggestions button')?.textContent === 'Pricing');
  await page.click('#aiSuggestions button[data-question-en="I have a dental emergency"]');
  await page.waitForFunction(() => Array.from(document.querySelectorAll('#aiBody .ai-msg.assistant')).some((el) => /For a dental emergency/.test(el.textContent)), { timeout: 5000 });
  const english = await page.$eval('#aiBody', (el) => el.textContent);
  assert.match(english, /For a dental emergency/);

  await page.type('#aiInput', 'Can you give me tax advice?');
  await page.click('.ai-send');
  await page.waitForFunction(() => Array.from(document.querySelectorAll('#aiBody .ai-msg.assistant')).some((el) => /call the clinic|booking form/i.test(el.textContent)), { timeout: 5000 });
  assert.deepEqual(forbiddenRequests, [], 'the local FAQ bot must not issue remote chat requests');
  console.log(`LOCAL FAQ WIDGET E2E PASSED: ~${elapsed}ms typing indicator, ES+EN, unknown-question redirect, zero chat requests`);
} finally {
  await browser.close();
}

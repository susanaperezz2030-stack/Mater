import fs from 'fs';
import vm from 'vm';
import Validator from '../config/validator.js';

function p(rel) { return new URL(rel, import.meta.url); }

function loadJsConfig(url, globalName) {
  const code = fs.readFileSync(url, 'utf8');
  const ctx = { window: {}, module: { exports: {} } };
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  return ctx.module?.exports && Object.keys(ctx.module.exports).length ? ctx.module.exports : ctx.window[globalName] || ctx[globalName];
}

const example = loadJsConfig(p('../config/examples/auradental.config.js'), 'CLINIC_CONFIG');
const r1 = Validator.validate(example);
console.log('[example]', r1.ok ? 'OK' : 'FAIL', r1.summary);
if (!r1.ok) { console.error(r1.errors); process.exit(1); }
if (r1.placeholders.length !== 0) { console.error('example has placeholders:', r1.placeholders); process.exit(1); }

// Negative tests
const r2 = Validator.validate({ clinic: { name: 'X', city: 'C', country: 'P' }, contact: { phone: '123', email: 'bad', address: 'a' }, services: [] });
if (r2.ok) { console.error('expected invalid'); process.exit(1); }
console.log('[negative]', 'OK invalid config correctly caught with', r2.errors.length, 'errors');

// Placeholder detection test
const r3 = Validator.validate({ clinic: { name: '[NOMBRE]', city: 'C', country: 'P' }, contact: { phone: '+34600000000', email: 'a@b.com', address: 'a' }, services: [{ id: 's', title: { es: '[TITULO]' } }] });
if (r3.placeholders.length !== 2) { console.error('expected 2 placeholders, got', r3.placeholders.length); process.exit(1); }
console.log('[placeholders]', 'OK', r3.placeholders.map(pp => `${pp.path}=${pp.placeholder}`).join(', '));

// Final siteData.js validation: valid structure and no visible demo placeholders.
const template = loadJsConfig(p('../siteData.js'), 'SITE_CONFIG');
const r4 = Validator.validate(template);
console.log('[template]', r4.summary);
if (r4.placeholders.length !== 0) { console.error('template still contains placeholders:', r4.placeholders); process.exit(1); }
if (!template.clinic || !template.contact || !template.services) { console.error('template missing required blocks'); process.exit(1); }
console.log('ALL VALIDATOR TESTS PASSED');

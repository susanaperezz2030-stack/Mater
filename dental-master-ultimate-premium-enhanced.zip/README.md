# Dental Master Ultimate

Edición Ultimate del proyecto dental: sitio público rediseñado, seis temas visuales, panel de administración con estilo SaaS, CRM de leads, agenda, automatizaciones y asistente FAQ local bilingüe. Los archivos `index.html` y `admin.html` están en la raíz del proyecto.

## Qué incluye la mejora Ultimate

- Tipografía editorial moderna, paleta refinada, superficies suaves, sombras, hover states, microinteracciones y estilos compatibles con los seis temas y modo oscuro.
- Dashboard de administración con tarjetas métricas, distribución visual del pipeline y estilos coherentes para CRM, citas, automatizaciones, tablas y formularios.
- Asistente local en español e inglés para precios, horarios, ubicación, reservas, seguros y urgencias. Usa coincidencia de palabras clave, muestra «escribiendo…» durante un segundo y deriva con amabilidad a la llamada o formulario cuando no conoce la respuesta. No utiliza servicios externos de IA, claves ni peticiones de chat.
- Se conservan `functions/`, el esquema D1 y las rutas de backend existentes.

## CRM y Cloudflare D1

En Cloudflare Pages, `functions/api/leads.js` y `functions/api/appointments.js` se exponen como `/api/leads` y `/api/appointments`. El adaptador del navegador consulta esas rutas; las Pages Functions usan el binding `DB` para persistencia en D1. La autenticación, automatizaciones y ajustes mantienen sus rutas `/api/*`. En una instalación estática sin backend, la aplicación conserva su modo de demostración con almacenamiento local.

La prueba automatizada confirma que el cliente usa `/api/leads` y `/api/appointments` y no llama a ninguna ruta remota de chat. La conexión a D1 en producción depende de que Cloudflare Pages tenga configurado el binding D1 `DB` para este proyecto.

El paquete incluye `wrangler.toml` y un build limpio en `dist/`. Si el proyecto de Cloudflare ya tiene D1 conectado, primero importa su configuración real con `pnpm run pages:sync-config`, conserva el bloque `[[d1_databases]]` con `binding = "DB"` y deja `pages_build_output_dir = "./dist"`. Después ejecuta `pnpm run deploy`. El preflight detiene el despliegue si falta el binding real. Pasos completos: [`docs/DEPLOY-CLOUDFLARE.md`](docs/DEPLOY-CLOUDFLARE.md).

## Sitio multipágina

La portada (`/`) ofrece el resumen del menú y enlaza a páginas independientes para `/servicios`, `/casos`, `/equipo`, `/financiacion`, `/opiniones`, `/preguntas` y `/contacto`. Cada URL sirve su propio HTML con título, descripción y datos SEO bilingües, mientras mantiene navegación, reserva, FAQ y pie de página compartidos. `pnpm run prepare:pages` genera las rutas y recursos en `dist/`; Cloudflare Pages sirve esas páginas estáticas junto con las Functions existentes.

El encabezado público es transparente y pasa a vidrio oscuro al superar 50 px de scroll; el wordmark queda a la izquierda y los controles de llamada y menú a la derecha. El menú abre un overlay de pantalla completa con acordeón de tratamientos y controles ES/EN y claro/oscuro. En móvil se muestra una sola píldora compacta con llamada, acceso directo al agente FAQ local, acción «Pedir cita» y accesibilidad; sus opciones incluyen texto grande y alto contraste. Al enviar una reserva aparece un pase premium sobre un fondo oscurecido y desenfocado con paciente, tratamiento, fecha, hora, referencia y un patrón QR meramente ilustrativo (no escaneable). La persistencia de CRM y citas mantiene las rutas `/api/*` y las Pages Functions existentes; estas mejoras no modifican `functions/`, el binding `DB` ni las operaciones D1.

## Inicio local

```bash
python3 -m http.server 8000
```

Abre `http://localhost:8000/` para el sitio y `http://localhost:8000/admin.html` para el panel. Las credenciales `admin@clinic.com` / `admin123` solo sirven para demo local; no están precargadas en el login ni deben habilitarse en producción. Para desplegar autenticación con Pages Functions configura `SESSION_SECRET` y `USERS` con contraseñas PBKDF2 (consulta `docs/DEPLOY-CLOUDFLARE.md`).

## Pruebas

```bash
pnpm install
pnpm run test:validator
pnpm run test:functions
pnpm run test:storage
pnpm run test:assistant
pnpm run test:assistant-e2e  # requiere el servidor local activo
pnpm run test:e2e            # requiere el servidor local activo
pnpm test                    # suite completa
```

Las pruebas de backend ejecutan Pages Functions con un binding D1 simulado en SQLite en memoria; la prueba de rutas comprueba los endpoints públicos usados por el adaptador. Antes de publicar, comprueba las credenciales, el binding D1, la configuración real de la clínica y los consentimientos legales.

## Publicación y seguridad

Consulta [`docs/DEPLOY-CLOUDFLARE.md`](docs/DEPLOY-CLOUDFLARE.md) para el despliegue. Sustituye los datos de demostración, textos, precios, imágenes y testimonios por información autorizada y verificada. El sistema recoge datos de contacto de marketing; no almacenes historias clínicas ni otra información sanitaria sensible en el CRM.

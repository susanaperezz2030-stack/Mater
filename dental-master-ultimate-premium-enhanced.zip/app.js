/**
 * =====================================================================
 *  PLANTILLA MAESTRA PREMIUM — DENTAL CLINIC MASTER TEMPLATE
 *  JavaScript Application Core
 * =====================================================================
 */

(function () {
  'use strict';

  // -------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const cfg = (typeof SITE_CONFIG !== "undefined" ? SITE_CONFIG : window.SITE_CONFIG) || {};

  function getPath(obj, path) {
    if (!obj) return '';
    return path.split('.').reduce((acc, k) => (acc != null ? acc[k] : undefined), obj) ?? '';
  }

  // -------------------------------------------------------------------
  // I18N DICTIONARY (ES default / EN)
  // -------------------------------------------------------------------
  const I18N = {
    es: {
      'preload.tag': 'ESTÉTICA DENTAL DE ÉLITE',
      'brand.sub': 'CLÍNICA DENTAL BOUTIQUE',
      'nav.home': 'Inicio', 'nav.services': 'Servicios', 'nav.gallery': 'Casos',
      'nav.doctor': 'Equipo', 'nav.financing': 'Financiación', 'nav.reviews': 'Opiniones',
      'nav.faq': 'FAQ', 'nav.contact': 'Contacto',
      'menu.about': 'La clínica', 'menu.cosmeticTitle': 'ESTÉTICA DENTAL', 'menu.orthoTitle': 'ORTODONCIA',
      'menu.implantTitle': 'IMPLANTES', 'menu.generalTitle': 'CUIDADO GENERAL',
      'menu.veneers': '– Carillas de porcelana', 'menu.whitening': '– Blanqueamiento dental',
      'menu.aligners': '– Alineadores invisibles', 'menu.implants': '– Implantes dentales',
      'menu.general': '– Odontología general', 'menu.emergency': '– Atención de urgencias', 'menu.darkMode': 'Modo oscuro',
      'mobile.call': 'Llamar ahora',
      'cta.book': 'Pedir Cita', 'cta.bookFree': 'Pedir Cita Gratuita', 'cta.callNow': 'Llamar',
      'hero.eyebrow': `CLÍNICA DENTAL BOUTIQUE · ${(cfg.clinic && cfg.clinic.city) || '[CIUDAD]'}`,
      'hero.titleA': 'La sonrisa que', 'hero.titleB': ' siempre has querido,', 'hero.titleC': 'con la precisión que mereces.',
      'hero.copy': 'Diseño digital de sonrisa, carillas ultrafinas, implantes y ortodoncia invisible con tecnología 3D mínimamente invasiva. Primera valoración gratuita y sin compromiso.',
      'hero.exp': 'años transformando sonrisas',
      'trust.a': 'Valoración 100% gratuita', 'trust.b': 'Financiación 0% interés', 'trust.c': 'Urgencias en el día',
      'trustcard.label': '+520 reseñas reales en Google',
      'trustbar.title': 'Aceptamos las principales aseguradoras · Financiación compatible',
      'stats.a': 'Pacientes satisfechos', 'stats.b': 'Años de excelencia', 'stats.c': 'Tratamientos realizados', 'stats.d': 'Reseñas 5 estrellas',
      'stats.years': 'Años de experiencia', 'stats.patients': 'Sonrisas transformadas', 'stats.guarantee': 'Atención personalizada',
      'services.kicker': 'Tratamientos',
      'services.title': 'Especialidades diseñadas para <em>resultados impecables.</em>',
      'services.lead': 'Cada tratamiento se planifica digitalmente en 3D para que veas el resultado antes de empezar.',
      'services.priceNote': 'Precios orientativos “desde”. El presupuesto final se confirma después de una valoración personalizada.',
      'services.filterAll': 'Todos', 'services.filterCosmetic': 'Estética dental',
      'services.filterOrtho': 'Ortodoncia', 'services.filterImplant': 'Implantes', 'services.filterGeneral': 'General & familia',
      'gallery.kicker': 'Casos reales',
      'gallery.title': 'Resultados que <em>hablan por sí mismos.</em>',
      'gallery.lead': 'Desliza el comparador para ver la transformación real de nuestros pacientes.',
      'gallery.before': 'ANTES', 'gallery.after': 'DESPUÉS', 'gallery.cta': 'Quiero un resultado así',
      'doctor.kicker': 'Directora médica', 'doctor.avg': 'Valoración media verificada',
      'doctor.book': 'Agendar con el doctor', 'doctor.virtual': 'Consulta virtual',
      'fin.title': 'Financia tu tratamiento en hasta 24 cuotas sin intereses',
      'fin.sub': 'La sonrisa que quieres no tiene por qué esperar. Aprobación inmediata en la clínica, sin letra pequeña.',
      'fin.b1': 'Aprobación en 3 minutos en la propia clínica', 'fin.b2': 'Hasta 24 cuotas al 0% TAE',
      'fin.b3': 'Compatible con tus seguros dentales', 'fin.b4': 'Sin comisiones de apertura ni estudio',
      'fin.partners': 'Entidades colaboradoras:',
      'calc.title': 'Calcula tu cuota mensual', 'calc.amount': 'Importe estimado del tratamiento:',
      'calc.months': 'Plazo:', 'calc.result': 'Tu cuota mensual aproximada:', 'calc.hint': 'Al 0% de interés · sin sorpresas',
      'calc.cta': 'Solicitar financiación',
      'reviews.kicker': 'Testimonios verificados',
      'reviews.title': 'Historias de pacientes <em>que ya sonríen sin complejos.</em>',
      'google.badge': 'Basado en 520+ reseñas verificadas de Google', 'google.view': 'Ver reseñas ↗',
      'faq.kicker': 'Dudas resueltas', 'faq.title': 'Preguntas <em>frecuentes.</em>',
      'faq.lead': 'Transparencia total: sin costes ocultos ni tratamientos innecesarios.',
      'faq.moreq': '¿Tienes otra pregunta?', 'faq.moreqSub': 'Escríbenos por WhatsApp y te respondemos en minutos.',
      'contact.kicker': 'Encuéntranos', 'contact.title': `Tu clínica en <em>el corazón de ${(cfg.clinic && cfg.clinic.city) || '[CIUDAD]'}.</em>`,
      'contact.addrLabel': 'Dirección', 'contact.phoneLabel': 'Teléfono directo', 'contact.emailLabel': 'Email',
      'contact.phoneHint': 'Atención telefónica en horario de clínica', 'contact.waHint': 'Respuesta rápida también fines de semana',
      'contact.maps': 'Cómo llegar en Google Maps', 'contact.hours': 'Horario de atención',
      'map.parking': 'Parking gratuito concertado',
      'ctaband.kicker': 'Primera cita gratuita', 'ctaband.title': 'Tu nueva sonrisa <em>empieza con una simple conversación.</em>',
      'ctaband.sub': 'Exploración clínica completa + radiografía digital 3D 100% sin coste ni compromiso.',
      'footer.desc': 'Clínica dental boutique especializada en diseño de sonrisa, carillas de porcelana, implantes y ortodoncia invisible con tecnología de última generación.',
      'footer.col1': 'Tratamientos', 'footer.col2': 'La clínica', 'footer.col3': 'Contacto',
      'footer.rights': 'Todos los derechos reservados.',
      'wiz.s1': 'Servicio', 'wiz.s2': 'Fecha', 'wiz.s3': 'Datos',
      'wiz.p1hint': '¿Qué tratamiento te interesa?', 'wiz.p2hint': 'Elige día y franja horaria preferida', 'wiz.p3hint': 'Tus datos para confirmar la cita',
      'wiz.next': 'Siguiente', 'wiz.prev': 'Atrás',
      'modal.title': 'Reserva tu cita de valoración gratuita',
      'modal.sub': 'Completa los 3 pasos en 30 segundos. Te confirmaremos por WhatsApp.',
      'form.date': 'Fecha preferida', 'form.slot': 'Franja horaria', 'slot.morning': 'Mañana',
      'slot.afternoon': 'Tarde', 'slot.evening': 'Noche', 'form.docPref': 'Profesional de preferencia:',
      'form.name': 'Nombre y apellidos *', 'form.phone': 'Teléfono / WhatsApp *',
      'form.notes': 'Observaciones (opcional)', 'form.consent': 'Acepto la política de privacidad y autorizo el contacto para gestionar mi cita.',
      'modal.submit': 'Enviar solicitud de cita',
      'success.title': '¡Solicitud recibida correctamente!',
      'success.sub': 'Nos pondremos en contacto contigo en menos de 2 horas laborables para confirmar fecha y hora.',
      'success.wa': 'Confirmar más rápido por WhatsApp',
      'pass.badge': 'SOLICITUD DE CITA', 'pass.status': 'PENDIENTE DE CONFIRMACIÓN', 'pass.eyebrow': 'RESUMEN DE TU SOLICITUD',
      'pass.title': 'Solicitud de cita', 'pass.copy': 'La fecha y franja son preferencias, no una cita confirmada.',
      'pass.patient': 'Paciente', 'pass.treatment': 'Servicio', 'pass.location': 'Ubicación', 'pass.date': 'Fecha', 'pass.time': 'Hora',
      'pass.protectedTitle': 'Pendiente de confirmación', 'pass.protectedCopy': 'El equipo debe confirmar fecha y hora antes de considerarla una cita.',
      'pass.reference': 'NÚMERO DE REFERENCIA', 'pass.qrNote': 'Patrón visual de referencia · no escaneable', 'pass.print': 'Guardar / imprimir', 'pass.calendar': 'Añadir al calendario', 'pass.done': 'Entendido, volver al sitio',
      'exit.badge': 'RESERVA TU CONSULTA', 'exit.title': 'No te vayas sin reservar tu consulta',
      'exit.sub': 'Déjanos tus datos y continúa con la reserva de tu consulta. El equipo de la clínica confirmará los detalles directamente.',
      'exit.cta': 'Reservar mi consulta', 'exit.note': 'Tus datos se usan únicamente para gestionar tu consulta.',
      'wa.tooltip': '¿Dudas? Chatea con nosotros',
      'mob.call': 'Llamar', 'mob.book': 'Pedir cita', 'mob.maps': 'Cómo llegar',
      'a11y.text': 'Texto grande', 'a11y.contrast': 'Alto contraste',
      'cookie.title': 'Tu privacidad importa', 'cookie.desc': 'Usamos cookies para mejorar tu experiencia y medir visitas. Puedes aceptarlas o rechazar las no esenciales.',
      'cookie.accept': 'Aceptar todas', 'cookie.reject': 'Solo necesarias',
    },
    en: {
      'preload.tag': 'ELITE DENTAL AESTHETICS',
      'brand.sub': 'BOUTIQUE DENTAL CLINIC',
      'nav.home': 'Home', 'nav.services': 'Services', 'nav.gallery': 'Cases',
      'nav.doctor': 'Doctor', 'nav.financing': 'Financing', 'nav.reviews': 'Reviews',
      'nav.faq': 'FAQ', 'nav.contact': 'Contact',
      'menu.about': 'Our Clinic', 'menu.cosmeticTitle': 'COSMETIC DENTISTRY', 'menu.orthoTitle': 'ORTHODONTICS',
      'menu.implantTitle': 'IMPLANTS', 'menu.generalTitle': 'GENERAL CARE',
      'menu.veneers': '– Porcelain veneers', 'menu.whitening': '– Teeth whitening',
      'menu.aligners': '– Clear aligners', 'menu.implants': '– Dental implants',
      'menu.general': '– General dentistry', 'menu.emergency': '– Emergency care', 'menu.darkMode': 'Dark mode',
      'mobile.call': 'Call now',
      'cta.book': 'Book Visit', 'cta.bookFree': 'Book Free Assessment', 'cta.callNow': 'Call',
      'hero.eyebrow': `BOUTIQUE DENTAL CLINIC · ${(cfg.clinic && cfg.clinic.city) || '[CITY]'}`,
      'hero.titleA': 'The smile you’ve', 'hero.titleB': ' always wanted,', 'hero.titleC': 'with the precision you deserve.',
      'hero.copy': 'Digital smile design, ultra-thin veneers, implants and clear aligners with minimally invasive 3D technology. First assessment free, no obligation.',
      'hero.exp': 'years transforming smiles',
      'trust.a': '100% free assessment', 'trust.b': '0% interest financing', 'trust.c': 'Same-day emergencies',
      'trustcard.label': '+520 real Google reviews',
      'trustbar.title': 'Major dental insurances accepted · Financing compatible',
      'stats.a': 'Satisfied patients', 'stats.b': 'Years of excellence', 'stats.c': 'Procedures performed', 'stats.d': '5-star reviews',
      'stats.years': 'Years of experience', 'stats.patients': 'Smiles transformed', 'stats.guarantee': 'Personalized care',
      'services.kicker': 'Treatments',
      'services.title': 'Specialties designed for <em>flawless results.</em>',
      'services.lead': 'Every treatment is digitally planned in 3D so you can see the result before we start.',
      'services.priceNote': 'Indicative “from” prices. The final quote is confirmed after a personalized consultation.',
      'services.filterAll': 'All', 'services.filterCosmetic': 'Cosmetic dentistry',
      'services.filterOrtho': 'Orthodontics', 'services.filterImplant': 'Implants', 'services.filterGeneral': 'General & family',
      'gallery.kicker': 'Real cases',
      'gallery.title': 'Results that <em>speak for themselves.</em>',
      'gallery.lead': 'Drag the slider to see real transformations from our patients.',
      'gallery.before': 'BEFORE', 'gallery.after': 'AFTER', 'gallery.cta': 'I want a result like this',
      'doctor.kicker': 'Medical director', 'doctor.avg': 'Verified average rating',
      'doctor.book': 'Book with the doctor', 'doctor.virtual': 'Virtual consultation',
      'fin.title': 'Finance your treatment in up to 24 interest-free installments',
      'fin.sub': 'The smile you want doesn’t have to wait. Immediate in-clinic approval, no fine print.',
      'fin.b1': 'Approval in 3 minutes right at the clinic', 'fin.b2': 'Up to 24 installments at 0% APR',
      'fin.b3': 'Compatible with your dental insurance', 'fin.b4': 'No setup or assessment fees',
      'fin.partners': 'Financing partners:',
      'calc.title': 'Estimate your monthly payment', 'calc.amount': 'Estimated treatment amount:',
      'calc.months': 'Term:', 'calc.result': 'Your estimated monthly payment:', 'calc.hint': 'At 0% interest · no surprises',
      'calc.cta': 'Apply for financing',
      'reviews.kicker': 'Verified testimonials',
      'reviews.title': 'Stories from patients <em>who now smile with confidence.</em>',
      'google.badge': 'Based on 520+ verified Google reviews', 'google.view': 'View reviews ↗',
      'faq.kicker': 'Answers', 'faq.title': 'Frequently <em>asked questions.</em>',
      'faq.lead': 'Total transparency: no hidden costs, no unnecessary treatments.',
      'faq.moreq': 'Have another question?', 'faq.moreqSub': 'Message us on WhatsApp and we’ll reply in minutes.',
      'contact.kicker': 'Find us', 'contact.title': `Your clinic in <em>the heart of ${(cfg.clinic && cfg.clinic.city) || '[CITY]'}.</em>`,
      'contact.addrLabel': 'Address', 'contact.phoneLabel': 'Direct phone', 'contact.emailLabel': 'Email',
      'contact.phoneHint': 'Phone care during clinic hours', 'contact.waHint': 'Quick replies also on weekends',
      'contact.maps': 'Get directions on Google Maps', 'contact.hours': 'Opening hours',
      'map.parking': 'Validated free parking',
      'ctaband.kicker': 'First visit free', 'ctaband.title': 'Your new smile <em>starts with a simple conversation.</em>',
      'ctaband.sub': 'Full clinical examination + 3D digital X-ray 100% free of charge and obligation.',
      'footer.desc': 'Boutique dental clinic specializing in smile design, porcelain veneers, implants and clear aligners with next-generation technology.',
      'footer.col1': 'Treatments', 'footer.col2': 'The clinic', 'footer.col3': 'Contact',
      'footer.rights': 'All rights reserved.',
      'wiz.s1': 'Service', 'wiz.s2': 'Date', 'wiz.s3': 'Details',
      'wiz.p1hint': 'Which treatment are you interested in?', 'wiz.p2hint': 'Pick your preferred date and time slot', 'wiz.p3hint': 'Your details to confirm the appointment',
      'wiz.next': 'Next', 'wiz.prev': 'Back',
      'modal.title': 'Book your free assessment visit',
      'modal.sub': 'Complete the 3 steps in 30 seconds. We will confirm via WhatsApp.',
      'form.date': 'Preferred date', 'form.slot': 'Time slot', 'slot.morning': 'Morning',
      'slot.afternoon': 'Afternoon', 'slot.evening': 'Evening', 'form.docPref': 'Preferred professional:',
      'form.name': 'Full name *', 'form.phone': 'Phone / WhatsApp *',
      'form.notes': 'Notes (optional)', 'form.consent': 'I accept the privacy policy and authorize contact to manage my appointment.',
      'modal.submit': 'Send appointment request',
      'success.title': 'Request received successfully!',
      'success.sub': 'We will contact you within 2 working hours to confirm date and time.',
      'success.wa': 'Confirm faster via WhatsApp',
      'pass.badge': 'APPOINTMENT REQUEST', 'pass.status': 'AWAITING CONFIRMATION', 'pass.eyebrow': 'YOUR REQUEST SUMMARY',
      'pass.title': 'Appointment request', 'pass.copy': 'Your selected date and time are preferences, not a confirmed appointment.',
      'pass.patient': 'Patient', 'pass.treatment': 'Service', 'pass.location': 'Location', 'pass.date': 'Date', 'pass.time': 'Time',
      'pass.protectedTitle': 'Awaiting confirmation', 'pass.protectedCopy': 'The clinic team must confirm the date and time before this is an appointment.',
      'pass.reference': 'REFERENCE NUMBER', 'pass.qrNote': 'Visual reference pattern · not scannable', 'pass.print': 'Save / print', 'pass.calendar': 'Add to calendar', 'pass.done': 'Done, back to the site',
      'exit.badge': 'BOOK YOUR CONSULTATION', 'exit.title': 'Don’t leave without booking your consultation',
      'exit.sub': 'Leave your details and continue booking your consultation. The clinic team will confirm the details directly.',
      'exit.cta': 'Book my consultation', 'exit.note': 'Your details are used only to manage your consultation.',
      'wa.tooltip': 'Questions? Chat with us',
      'mob.call': 'Call', 'mob.book': 'Book appointment', 'mob.maps': 'Directions',
      'a11y.text': 'Larger text', 'a11y.contrast': 'High contrast',
      'cookie.title': 'Your privacy matters', 'cookie.desc': 'We use cookies to improve your experience and measure visits. You can accept all or reject non-essential ones.',
      'cookie.accept': 'Accept all', 'cookie.reject': 'Essential only',
    },
  };

  // -------------------------------------------------------------------
  // LANGUAGE MANAGER
  // -------------------------------------------------------------------
  let currentLang = localStorage.getItem('dental-lang') ||
    (navigator.language && navigator.language.startsWith('en') ? 'en' : 'es');

  function setLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('dental-lang', lang);
    document.documentElement.lang = lang;
    document.body.classList.toggle('lang-en', lang === 'en');

    // Update switch UI
    const sw = $('#langSwitch');
    if (sw) {
      $('.lang-es', sw).classList.toggle('active', lang === 'es');
      $('.lang-en', sw).classList.toggle('active', lang === 'en');
    }
    $$('[data-label-es][data-label-en]').forEach((el) => el.setAttribute('aria-label', lang === 'en' ? el.dataset.labelEn : el.dataset.labelEs));
    const ml = $('#mobileLang');
    if (ml) {
      $('.lang-es', ml).classList.toggle('active', lang === 'es');
      $('.lang-en', ml).classList.toggle('active', lang === 'en');
    }

    // Translate all [data-i18n] nodes
    const dict = I18N[lang] || I18N.es;
    $$('[data-i18n]').forEach((el) => {
      const key = el.dataset.i18n;
      if (dict[key] !== undefined) el.innerHTML = dict[key];
    });

    // Re-render dynamic sections with new language
    renderServices();
    renderCases();
    renderReviews();
    renderFaqs();
    renderHours();
    renderWizardServices();
    renderFinancing();
    renderDoctor();
    bindConfigData();
    updateWhatsAppTooltip();

    const formLang = $('#formLang');
    if (formLang) formLang.value = lang;
  }

  // -------------------------------------------------------------------
  // DATA BINDER: populates placeholders from siteData.js
  // -------------------------------------------------------------------
  function bindConfigData() {
    $$('[data-bind]').forEach((el) => {
      const val = getPath(cfg, el.dataset.bind);
      if (val !== '') el.textContent = val;
    });

    // Attribute bindings
    const phone = getPath(cfg, 'contact.phone');
    const phoneFmt = getPath(cfg, 'contact.phoneFormatted') || phone;
    $$('[data-phone-link]').forEach((a) => {
      a.href = `tel:${phone}`;
    });
    const wa = getPath(cfg, 'whatsapp.number');
    const waMsg = encodeURIComponent(getPath(cfg, `whatsapp.messages.general.${currentLang}`) || '');
    $$('[data-wa-link]').forEach((a) => {
      a.href = `https://wa.me/${wa}${waMsg ? '?text=' + waMsg : ''}`;
    });
    const maps = getPath(cfg, 'contact.mapsUrl');
    $$('[data-maps-link]').forEach((a) => {
      if (maps) a.href = maps;
    });
    const embed = getPath(cfg, 'contact.mapsEmbedUrl');
    const iframe = $('#mapsFrame');
    if (iframe && embed) iframe.src = embed;

    // Doctor photo
    const photo = getPath(cfg, 'doctor.photo');
    const photoImg = $('.doctor-photo');
    if (photoImg && photo) photoImg.src = photo;

    // Dynamic SEO from config
    const seo = cfg.seo;
    if (seo) {
      const pageSuffix = currentLang === 'en' ? 'En' : 'Es';
      const clinicName = getPath(cfg, 'clinic.nameShort') || getPath(cfg, 'clinic.name') || '';
      const city = getPath(cfg, 'clinic.city') || '';
      const fillPageMeta = (value) => String(value || '')
        .replaceAll('[NOMBRE_CLINICA]', clinicName)
        .replaceAll('[CIUDAD]', city)
        .replaceAll('[CITY]', city);
      const configuredTitle = (seo.title && (seo.title[currentLang] || seo.title.es)) || '';
      const configuredDescription = (seo.description && (seo.description[currentLang] || seo.description.es)) || '';
      const t = fillPageMeta(document.body.dataset[`pageTitle${pageSuffix}`] || configuredTitle);
      const d = fillPageMeta(document.body.dataset[`pageDescription${pageSuffix}`] || configuredDescription);
      if (t) document.title = t;
      const dm = $('meta[name="description"]'); if (dm && d) dm.setAttribute('content', d);
      const ogt = $('meta[property="og:title"]'); if (ogt && t) ogt.setAttribute('content', t);
      const ogd = $('meta[property="og:description"]'); if (ogd && d) ogd.setAttribute('content', d);
      const can = $('#canonicalLink');
      if (can && seo.canonicalUrl) {
        try {
          const canonical = new URL(seo.canonicalUrl);
          if (document.body.dataset.pagePath) canonical.pathname = document.body.dataset.pagePath;
          canonical.search = ''; canonical.hash = ''; can.href = canonical.href;
        } catch { can.href = seo.canonicalUrl; }
      }
      const ogi = $('meta[property="og:image"]'); if (ogi && seo.ogImage) ogi.setAttribute('content', seo.ogImage);
    }
    const gsc = getPath(cfg, 'integrations.googleSearchConsoleMeta');
    const gscEl = $('#gscMeta'); if (gscEl && gsc) gscEl.setAttribute('content', gsc);

    // Virtual consultation link
    const vbtn = $('#virtualConsultBtn');
    const vurl = getPath(cfg, 'doctor.virtualConsultation.url');
    if (vbtn && vurl && vurl !== '#') vbtn.href = vurl;

    // Google badge link
    const gbadge = $('#googleBadge');
    const gurl = getPath(cfg, 'google.businessUrl');
    if (gbadge && gurl && gurl !== '[ENLACE_GOOGLE_RESEÑAS]') gbadge.href = gurl;

    // Form action
    const form = $('#bookingForm');
    const fid = getPath(cfg, 'form.formspreeId');
    if (form && fid && fid !== 'YOUR_FORM_ID') {
      form.action = `https://formspree.io/f/${fid}`;
    }
    const demoNotice = $('#demoNotice');
    if (demoNotice) demoNotice.style.display = cfg.form && cfg.form.demoMode ? 'block' : 'none';

    // Doctor preference options
    const dname = getPath(cfg, 'doctor.name');
    const dopt = $('#fDocOption');
    if (dopt && dname) dopt.value = dopt.textContent = dname;

    // Multi-location: populate location select (hide if none)
    const locSelect = $('#fLocation');
    const locGroup = $('#locationGroup');
    const locs = cfg.locations || [];
    if (locSelect && locGroup) {
      if (locs.length) {
        locGroup.style.display = 'block';
        locSelect.innerHTML = '<option value="">Sin preferencia — cualquiera</option>' +
          locs.map((l) => `<option value="${l.id}">${l.name}</option>`).join('');
      } else {
        locGroup.style.display = 'none';
      }
    }

    // Multi-team: populate doctors from team array when defined
    const docSelect = $('#fDoctor');
    const team = cfg.team || [];
    if (docSelect && team.length) {
      docSelect.innerHTML = '<option value="Sin preferencia — cualquiera del equipo">Sin preferencia</option>' +
        team.map((t) => `<option value="${t.name}">${t.name} — ${(t.role && (t.role[currentLang] || t.role.es)) || ''}</option>`).join('');
    }
  }

  // -------------------------------------------------------------------
  // RENDER: SERVICES
  // -------------------------------------------------------------------
  function renderServices(filter = 'all') {
    const grid = $('#servicesGrid');
    if (!grid) return;
    const services = cfg.services || [];
    grid.innerHTML = services
      .map((s) => {
        const title = s.title ? (s.title[currentLang] || s.title.es) : '';
        const desc = s.desc ? (s.desc[currentLang] || s.desc.es) : '';
        const tag = s.tag ? (s.tag[currentLang] || s.tag.es) : '';
        const price = s.price || '';
        const hidden = filter !== 'all' && s.category !== filter ? ' hidden' : '';
        const popular = s.popular ? ' popular' : '';
        const waMsg = encodeURIComponent(getPath(cfg, `whatsapp.messages.${s.id}.${currentLang}`) || '');
        const waNumber = getPath(cfg, 'whatsapp.number');
        return `
        <article class="service-card${popular}${hidden}" data-category="${s.category}" data-service-id="${s.id}" data-aos="fade-up">
          ${tag ? `<span class="service-card-tag">${tag}</span>` : ''}
          <div class="service-card-icon"><img src="${s.icon}" alt="" width="30" height="30"></div>
          <h3>${title}</h3>
          <p>${desc}</p>
          <div class="service-card-foot">
            <span class="service-price">${price}<small>${s.duration || ''}</small></span>
            <div style="display:flex;gap:6px">
              <a href="https://wa.me/${waNumber}?text=${waMsg}" target="_blank" rel="noopener" class="pill pill-outline service-cta" aria-label="Consultar por WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
              <button type="button" class="pill pill-glow service-cta js-open-booking" data-service-preset="${s.id}">${currentLang === 'en' ? 'Book' : 'Agendar'}</button>
            </div>
          </div>
        </article>`;
      })
      .join('');
    if (window.AOS) AOS.refresh();
  }

  // -------------------------------------------------------------------
  // RENDER: GALLERY CASES
  // -------------------------------------------------------------------
  function renderCases() {
    const grid = $('#casesGrid');
    if (!grid) return;
    const g = cfg.gallery || {};
    const cases = g.cases || [];
    grid.innerHTML = cases
      .map((c) => {
        const title = c.title ? (c.title[currentLang] || c.title.es) : '';
        const treatment = c.treatment ? (c.treatment[currentLang] || c.treatment.es) : '';
        const hasBefore = !!c.before;
        const media = hasBefore
          ? `<div class="case-card-media case-pair js-zoomable">
              <div class="case-pair-cell"><img src="${c.before}" alt="Antes"><span class="case-badge-label">${currentLang === 'en' ? 'BEFORE' : 'ANTES'}</span></div>
              <div class="case-pair-cell"><img src="${c.after}" alt="Después"><span class="case-badge-label">${currentLang === 'en' ? 'AFTER' : 'DESPUÉS'}</span></div>
            </div>`
          : `<div class="case-card-media js-zoomable"><img src="${c.after}" alt="${title}"><span class="case-badge-label">${currentLang === 'en' ? 'FINAL RESULT' : 'RESULTADO FINAL'}</span></div>`;
        return `
        <article class="case-card" data-aos="fade-up" data-title="${title.replace(/"/g, '&quot;')}" data-treatment="${treatment.replace(/"/g, '&quot;')}">
          ${media}
          <div class="case-card-body">
            <h4 class="case-card-title">${title}</h4>
            <p class="case-card-treatment"><i class="fa-solid fa-tooth"></i> ${treatment}</p>
            ${c.patient ? `<div class="case-card-patient">${c.patient}</div>` : ''}
          </div>
        </article>`;
      })
      .join('');
  }

  // -------------------------------------------------------------------
  // RENDER: REVIEWS + SWIPER
  // -------------------------------------------------------------------
  let reviewsSwiper = null;
  function renderReviews() {
    const track = $('#reviewsTrack');
    if (!track) return;
    const items = cfg.testimonials || [];
    track.innerHTML = items
      .map((t) => {
        const text = t.text ? (t.text[currentLang] || t.text.es) : '';
        const date = t.date ? (t.date[currentLang] || t.date.es) : '';
        const treatment = t.treatment ? (t.treatment[currentLang] || t.treatment.es) : '';
        const stars = '★'.repeat(t.rating || 5);
        return `
        <div class="swiper-slide">
          <article class="review-card">
            <div class="review-card-head">
              <div class="review-avatar" aria-hidden="true">${t.avatar || '★'}</div>
              <div class="review-meta">
                <strong>${t.author}</strong>
                <small>${t.city || ''} · ${date}</small>
              </div>
            </div>
            <div class="review-stars" aria-label="${t.rating} de 5 estrellas">${stars}</div>
            <p class="review-text">“${text}”</p>
            <div class="review-footer">
              <span>${treatment}</span>
              <span class="review-verified"><i class="fa-solid fa-badge-check"></i> ${currentLang === 'en' ? 'Google Review' : 'Reseña de Google'}</span>
            </div>
          </article>
        </div>`;
      })
      .join('');

    if (window.Swiper) {
      if (reviewsSwiper) reviewsSwiper.destroy(true, true);
      reviewsSwiper = new Swiper('#reviewsSwiper', {
        loop: true,
        autoplay: { delay: 6000, disableOnInteraction: false },
        speed: 700,
        spaceBetween: 20,
        slidesPerView: 1.1,
        breakpoints: { 680: { slidesPerView: 2.1 }, 1100: { slidesPerView: 3 } },
        pagination: { el: '.swiper-pagination', clickable: true },
        navigation: { nextEl: '.swiper-next', prevEl: '.swiper-prev' },
      });
    }
  }

  // -------------------------------------------------------------------
  // RENDER: FAQS
  // -------------------------------------------------------------------
  function renderFaqs() {
    const list = $('#faqList');
    if (!list) return;
    const faqs = cfg.faqs || [];
    list.innerHTML = faqs
      .map((f, i) => {
        const q = f.q ? (f.q[currentLang] || f.q.es) : '';
        const a = f.a ? (f.a[currentLang] || f.a.es) : '';
        return `
        <details class="faq-item" ${i === 0 ? 'open' : ''}>
          <summary class="faq-question">
            <span>${q}</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </summary>
          <p class="faq-answer">${a}</p>
        </details>`;
      })
      .join('');
  }

  // -------------------------------------------------------------------
  // RENDER: HOURS TABLE
  // -------------------------------------------------------------------
  function renderHours() {
    const table = $('#hoursTable');
    if (!table) return;
    const hours = cfg.hours || [];
    table.innerHTML = hours
      .map((h) => {
        const days = h.days ? (h.days[currentLang] || h.days.es) : '';
        const time = typeof h.time === 'object' ? (h.time[currentLang] || h.time.es) : h.time;
        return `<tr><td>${days}</td><td>${time}</td></tr>`;
      })
      .join('');
  }

  // -------------------------------------------------------------------
  // RENDER: DOCTOR SECTION
  // -------------------------------------------------------------------
  function renderDoctor() {
    const role = $('.doctor-role');
    const bio = $('.doctor-bio');
    if (role && cfg.doctor && cfg.doctor.role) role.textContent = cfg.doctor.role[currentLang] || cfg.doctor.role.es;
    if (bio && cfg.doctor && cfg.doctor.bio) bio.textContent = cfg.doctor.bio[currentLang] || cfg.doctor.bio.es;
  }

  // -------------------------------------------------------------------
  // RENDER: FINANCING BULLETS
  // -------------------------------------------------------------------
  function renderFinancing() {
    const ul = $('#financingBullets');
    if (!ul) return;
    const bullets = (cfg.financing && cfg.financing.bullets && cfg.financing.bullets[currentLang]) || [];
    ul.innerHTML = bullets
      .map((b) => `<li><i class="fa-solid fa-check"></i> <span>${b}</span></li>`)
      .join('');
  }

  // -------------------------------------------------------------------
  // RENDER: WIZARD SERVICE PICKER (Step 1)
  // -------------------------------------------------------------------
  function renderWizardServices() {
    const grid = $('#serviceSelectGrid');
    if (!grid) return;
    const services = cfg.services || [];
    grid.innerHTML = services
      .map((s, i) => {
        const title = s.title ? (s.title[currentLang] || s.title.es) : '';
        return `
        <button type="button" class="service-opt${i === 0 ? ' selected' : ''}" data-service="${s.id}">
          <img src="${s.icon}" alt="" width="26" height="26">
          <span>${title}</span>
          <span class="service-opt-check" aria-hidden="true">✓</span>
        </button>`;
      })
      .join('');
    const input = $('#selectedServiceInput');
    if (input && services[0]) input.value = services[0].id;

    $$('.service-opt', grid).forEach((btn) => {
      btn.onclick = () => {
        $$('.service-opt', grid).forEach((b) => b.classList.remove('selected'));
        btn.classList.add('selected');
        if (input) input.value = btn.dataset.service;
      };
    });
  }

  // -------------------------------------------------------------------
  // BEFORE/AFTER COMPARISON SLIDER
  // -------------------------------------------------------------------
  function initBeforeAfter() {
    const stage = $('#baStage');
    const beforeWrap = $('#baBeforeWrap');
    const handle = $('#baHandle');
    if (!stage || !beforeWrap || !handle) return;

    let dragging = false;
    function syncImageWidth() {
      const img = $('.ba-before', beforeWrap);
      if (img) img.style.width = stage.offsetWidth + 'px';
    }
    syncImageWidth();
    window.addEventListener('resize', syncImageWidth);

    function setPos(pct) {
      pct = Math.max(0, Math.min(100, pct));
      beforeWrap.style.width = pct + '%';
      handle.style.left = pct + '%';
      stage.setAttribute('aria-valuenow', Math.round(pct));
    }
    function posFromEvent(e) {
      const rect = stage.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      return ((clientX - rect.left) / rect.width) * 100;
    }
    stage.addEventListener('mousedown', (e) => { stage.focus(); dragging = true; setPos(posFromEvent(e)); });
    stage.addEventListener('touchstart', (e) => { stage.focus(); dragging = true; setPos(posFromEvent(e)); }, { passive: true });
    window.addEventListener('mousemove', (e) => { if (dragging) setPos(posFromEvent(e)); });
    window.addEventListener('touchmove', (e) => { if (dragging) setPos(posFromEvent(e)); }, { passive: true });
    window.addEventListener('mouseup', () => (dragging = false));
    window.addEventListener('touchend', () => (dragging = false));
    stage.addEventListener('keydown', (e) => {
      const cur = +stage.getAttribute('aria-valuenow') || 50;
      if (e.key === 'ArrowLeft') setPos(cur - 2);
      if (e.key === 'ArrowRight') setPos(cur + 2);
    });
    setPos(50);
  }

  // -------------------------------------------------------------------
  // FINANCING CALCULATOR
  // -------------------------------------------------------------------
  function initCalculator() {
    const slider = $('#calcAmount');
    const label = $('#calcAmountLabel');
    const out = $('#calcMonthly');
    const curEl = $('#calcCurrency');
    const monthsWrap = $('#calcMonths');
    const downSlider = $('#calcDown');
    const downLabel = $('#calcDownLabel');
    const hintEl = $('#calcHint');
    if (!slider || !label || !out) return;

    const currency = (cfg.settings && cfg.settings.currency) || '$';
    const interestRate = (cfg.financing && typeof cfg.financing.interestRate === 'number') ? cfg.financing.interestRate : 0;
    if (curEl) curEl.textContent = currency;

    let months = 12;
    function pmt(principal, ratePct, n) {
      if (!ratePct || ratePct <= 0) return principal / n;
      const r = ratePct / 12 / 100;
      return principal * (r / (1 - Math.pow(1 + r, -n)));
    }
    function recalc() {
      const amt = +slider.value;
      const down = Math.min(amt, +(downSlider && downSlider.value) || 0);
      if (downSlider && downSlider.max !== String(Math.floor(amt * 0.6))) downSlider.max = Math.floor(amt * 0.6);
      label.textContent = `${currency}${amt.toLocaleString('es-ES')}`;
      if (downLabel) downLabel.textContent = `${currency}${down.toLocaleString('es-ES')}`;
      const financed = Math.max(0, amt - down);
      out.textContent = Math.round(pmt(financed, interestRate, months));
      if (hintEl) {
        hintEl.textContent = interestRate === 0
          ? (currentLang === 'en' ? 'At 0% interest · no surprises' : 'Al 0% de interés · sin sorpresas')
          : (currentLang === 'en' ? `Interest ${interestRate}% APR · indicative estimate` : `Interés orientativo ${interestRate}% TAE · estimación no vinculante`);
      }
    }
    slider.addEventListener('input', recalc);
    if (downSlider) downSlider.addEventListener('input', recalc);
    if (monthsWrap) {
      $$('.calc-month', monthsWrap).forEach((btn) => {
        btn.onclick = () => {
          $$('.calc-month', monthsWrap).forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
          months = +btn.dataset.months;
          recalc();
        };
      });
    }
    recalc();
  }

  // -------------------------------------------------------------------
  // BOOKING MODAL (3-step wizard)
  // -------------------------------------------------------------------
  function initModal() {
    const modal = $('#bookingModal');
    if (!modal) return;
    const form = $('#bookingForm');
    const closeBtn = $('#modalClose');
    const backdrop = $('#modalBackdrop');
    const fDate = $('#fDate');
    const passOverlay = $('#bookingSuccessOverlay');
    let lastBookingTrigger = null;
    const localToday = () => {
      const now = new Date();
      return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    };
    if (fDate) fDate.min = localToday();

    function open(presetService, triggerElement) {
      lastBookingTrigger = triggerElement || document.activeElement;
      form.reset();
      $$('.service-opt').forEach((option) => option.classList.remove('selected'));
      const selectedService = $('#selectedServiceInput');
      if (selectedService) selectedService.value = '';
      const firstSlot = $('.slot-btn');
      $$('.slot-btn').forEach((button) => button.classList.toggle('active', button === firstSlot));
      const slotValue = $('#slotInput');
      if (slotValue) slotValue.value = firstSlot ? firstSlot.dataset.slot : '';
      if (fDate) { fDate.min = localToday(); fDate.value = ''; }
      form.style.display = '';
      const t = $('.modal-title'), s = $('.modal-sub'), ws = $('.wizard-steps'), sx = $('#wizardSuccess');
      if (t) t.style.display = '';
      if (s) s.style.display = '';
      if (ws) ws.style.display = '';
      if (sx) sx.style.display = 'none';
      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('lock-scroll');
      goStep(1);
      if (presetService) {
        const opt = $(`.service-opt[data-service="${presetService}"]`);
        if (opt) opt.click();
      }
    }
    function close() {
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('lock-scroll');
      const focusTarget = lastBookingTrigger && lastBookingTrigger.isConnected && lastBookingTrigger.getClientRects().length
        ? lastBookingTrigger : $('#hamb');
      if (focusTarget) focusTarget.focus({ preventScroll: true });
    }
    function dismissBookingPass() {
      if (passOverlay) {
        passOverlay.classList.remove('active');
        passOverlay.setAttribute('aria-hidden', 'true');
      }
      document.body.classList.remove('booking-pass-open');
      close();
    }
    function createReferenceQr(reference) {
      const size = 21;
      let seed = Array.from(reference).reduce((sum, char) => (sum * 31 + char.charCodeAt(0)) >>> 0, 7);
      const inFinder = (x, y, ox, oy) => {
        if (x < ox || x >= ox + 7 || y < oy || y >= oy + 7) return null;
        const dx = x - ox, dy = y - oy;
        return dx === 0 || dx === 6 || dy === 0 || dy === 6 || (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4);
      };
      let cells = '';
      for (let y = 0; y < size; y += 1) {
        for (let x = 0; x < size; x += 1) {
          let dark = inFinder(x, y, 0, 0);
          if (dark === null) dark = inFinder(x, y, size - 7, 0);
          if (dark === null) dark = inFinder(x, y, 0, size - 7);
          if (dark === null) {
            seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
            dark = (seed & 3) !== 0;
          }
          if (dark) cells += `<rect x="${x}" y="${y}" width="1" height="1"/>`;
        }
      }
      return `<svg viewBox="-1 -1 23 23" aria-hidden="true" focusable="false"><rect x="-1" y="-1" width="23" height="23" rx="1" fill="#fff"/><g fill="#111">${cells}</g></svg>`;
    }
    function showBookingPass(patientName) {
      if (!passOverlay) return;
      const passCard = passOverlay.querySelector('.booking-pass-card');
      const passConfig = cfg.bookingPass || {};
      const passValue = (key, fallback) => {
        const value = passConfig[key];
        if (typeof value === 'string') return value;
        if (value && typeof value === 'object') return value[currentLang] || value.es || value.en || fallback;
        return fallback;
      };
      if (passCard) {
        if (passConfig.accent) passCard.style.setProperty('--pass-accent', passConfig.accent);
        if (passConfig.accentDeep) passCard.style.setProperty('--pass-deep', passConfig.accentDeep);
        if (passConfig.headerColor) passCard.style.setProperty('--pass-header', passConfig.headerColor);
      }
      const passText = {
        bookingPassMark: passConfig.logoMark || '✦',
        bookingPassBrandLabel: passValue('brandLabel', 'PREMIUM DENTAL CARE'),
        bookingPassStatus: currentLang === 'en' ? 'AWAITING CONFIRMATION' : 'PENDIENTE DE CONFIRMACIÓN',
        bookingPassEyebrow: currentLang === 'en' ? 'YOUR REQUEST SUMMARY' : 'RESUMEN DE TU SOLICITUD',
        bookingPassTitle: currentLang === 'en' ? 'Appointment request' : 'Solicitud de cita',
        bookingPassCopy: currentLang === 'en' ? 'Your selected date and time are preferences, not a confirmed appointment.' : 'La fecha y franja son preferencias, no una cita confirmada.',
        bookingPassProtectedTitle: currentLang === 'en' ? 'Awaiting confirmation' : 'Pendiente de confirmación',
        bookingPassProtectedCopy: currentLang === 'en' ? 'The clinic team must confirm the date and time before this is an appointment.' : 'El equipo debe confirmar fecha y hora antes de considerarla una cita.',
      };
      Object.entries(passText).forEach(([id, text]) => { const el = $(`#${id}`); if (el) el.textContent = text; });
      const serviceId = ($('#selectedServiceInput') && $('#selectedServiceInput').value) || '';
      const service = (cfg.services || []).find((item) => item.id === serviceId);
      const serviceTitle = service && service.title
        ? (typeof service.title === 'string' ? service.title : (service.title[currentLang] || service.title.es))
        : serviceId;
      const rawDate = ($('#fDate') && $('#fDate').value) || '';
      let displayDate = rawDate || '—';
      if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
        const [year, month, day] = rawDate.split('-').map(Number);
        displayDate = new Intl.DateTimeFormat(currentLang, { dateStyle: 'long' }).format(new Date(year, month - 1, day, 12));
      }
      $('#bookingPassName').textContent = patientName.trim() || '—';
      $('#bookingPassTreatment').textContent = serviceTitle || '—';
      const configuredAddress = cfg.contact && (cfg.contact.address || cfg.contact.addressLine2);
      $('#bookingPassLocation').textContent = configuredAddress || (cfg.clinic && cfg.clinic.city) || '—';
      $('#bookingPassDate').textContent = displayDate;
      $('#bookingPassTime').textContent = ($('#slotInput') && $('#slotInput').value) || '—';
      passOverlay.classList.add('active');
      passOverlay.setAttribute('aria-hidden', 'false');
      document.body.classList.add('booking-pass-open');
      requestAnimationFrame(() => $('#bookingPassClose') && $('#bookingPassClose').focus());
    }
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.js-open-booking');
      if (btn) {
        e.preventDefault();
        open(btn.dataset.servicePreset, btn);
      }
    });
    closeBtn.onclick = close;
    backdrop.onclick = close;
    document.addEventListener('keydown', (e) => {
      if (passOverlay && passOverlay.classList.contains('active')) {
        if (e.key === 'Escape') { dismissBookingPass(); return; }
        if (e.key === 'Tab') {
          const focusables = Array.from(passOverlay.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), [tabindex]:not([tabindex="-1"])'))
            .filter((el) => el.getClientRects().length > 0);
          const first = focusables[0], last = focusables[focusables.length - 1];
          if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last && last.focus(); }
          else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first && first.focus(); }
        }
        return;
      }
      if (e.key === 'Escape' && modal.classList.contains('open')) close();
    });
    const passClose = $('#bookingPassClose');
    const passDone = $('#bookingPassDone');
    if (passClose) passClose.addEventListener('click', dismissBookingPass);
    if (passDone) passDone.addEventListener('click', dismissBookingPass);
    const passPrint = $('#bookingPassPrint');
    const passCalendar = $('#bookingPassCalendar');
    if (passPrint) passPrint.addEventListener('click', () => window.print());
    if (passCalendar) passCalendar.addEventListener('click', () => {
      const rawDate = ($('#fDate') && $('#fDate').value) || '';
      if (!/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) return;
      const serviceName = ($('#bookingPassTreatment') && $('#bookingPassTreatment').textContent) || 'Consulta dental';
      const location = ($('#bookingPassLocation') && $('#bookingPassLocation').textContent) || '';
      const reference = ($('#bookingPassReference') && $('#bookingPassReference').textContent) || '';
      const [year, month, day] = rawDate.split('-');
      const nextDay = new Date(Number(year), Number(month) - 1, Number(day) + 1);
      const endDate = `${nextDay.getFullYear()}${String(nextDay.getMonth() + 1).padStart(2, '0')}${String(nextDay.getDate()).padStart(2, '0')}`;
      const ics = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Dental Master//Booking//ES', 'BEGIN:VEVENT', `UID:${reference}@dental-master`, `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')}`, `DTSTART;VALUE=DATE:${year}${month}${day}`, `DTEND;VALUE=DATE:${endDate}`, `SUMMARY:${serviceName.replace(/[\r\n,;]/g, ' ')}`, `LOCATION:${location.replace(/[\r\n,;]/g, ' ')}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
      const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = `consulta-${rawDate}.ics`;
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });

    // Step navigation
    function goStep(step) {
      $$('.wizard-panel').forEach((p) => p.classList.toggle('active', +p.dataset.panel === step));
      $$('.wizard-step').forEach((s) => {
        const n = +s.dataset.step;
        s.classList.toggle('active', n === step);
        s.classList.toggle('done', n < step);
      });
    }
    $$('.wizard-btn[data-next]').forEach((b) => {
      b.onclick = () => {
        const cur = b.closest('.wizard-panel');
        if (cur && cur.dataset.panel === '1' && !($('#selectedServiceInput') && $('#selectedServiceInput').value)) {
          alert(currentLang === 'en' ? 'Choose a service to continue.' : 'Elige un servicio para continuar.');
          const option = $('.service-opt'); if (option) option.focus();
          return;
        }
        if (cur && cur.dataset.panel === '2') {
          const date = $('#fDate');
          if (date && (!date.value || date.value < localToday())) {
            date.setCustomValidity(date.value && date.value < localToday() ? (currentLang === 'en' ? 'Choose today or a future date.' : 'Elige hoy o una fecha futura.') : '');
            date.focus(); date.reportValidity(); date.setCustomValidity(''); return;
          }
          if (!($('#slotInput') && $('#slotInput').value)) {
            alert(currentLang === 'en' ? 'Choose a preferred time slot.' : 'Elige una franja horaria preferida.');
            return;
          }
        }
        goStep(+b.dataset.next);
      };
    });
    $$('.wizard-btn[data-prev]').forEach((b) => (b.onclick = () => goStep(+b.dataset.prev)));

    // Time slot buttons
    const slotInput = $('#slotInput');
    $$('.slot-btn').forEach((btn) => {
      btn.onclick = () => {
        $$('.slot-btn').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        if (slotInput) slotInput.value = btn.dataset.slot;
      };
    });

    // Form submit
    if (form) {
      form.addEventListener('submit', (e) => { e.preventDefault(); return false; });
      async function handleFormSubmit() {
        const name = $('#fName'), phone = $('#fPhone'), email = $('#fEmail');
        if (!($('#selectedServiceInput') && $('#selectedServiceInput').value)) {
          alert(currentLang === 'en' ? 'Choose a service first.' : 'Selecciona primero un servicio.'); goStep(1); return;
        }
        if (!fDate || !fDate.value || fDate.value < localToday() || !($('#slotInput') && $('#slotInput').value)) {
          alert(currentLang === 'en' ? 'Choose a valid preferred date and time slot.' : 'Selecciona una fecha y franja horaria válidas.'); goStep(2); return;
        }
        if (!name || !name.checkValidity()) { name && name.reportValidity(); return; }
        if (!phone || !phone.checkValidity()) { phone && phone.reportValidity(); return; }
        if (!email || !email.checkValidity()) { email && email.reportValidity(); return; }
        const demo = cfg.form && cfg.form.demoMode;
        const fid = cfg.form && cfg.form.formspreeId;
        const submitBtn = $('#modalSubmit');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ' + (currentLang === 'en' ? 'Sending...' : 'Enviando...');

        // Persist appointment + lead through DMEStorage with double-booking prevention
        if (window.DMEStorage) {
          const res = await DMEStorage.saveAppointment({
            service: ($('#selectedServiceInput') && $('#selectedServiceInput').value) || '',
            date: ($('#fDate') && $('#fDate').value) || '',
            slot: ($('#slotInput') && $('#slotInput').value) || '',
            specialist: ($('#fDoctor') && $('#fDoctor').value) || '',
            location: ($('#fLocation') && $('#fLocation').value) || '',
            name: name.value, phone: phone.value, email: email.value,
            notes: ($('#fNotes') && $('#fNotes').value) || '',
            status: 'pending',
          });
          if (!res.ok && res.conflict) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = currentLang === 'en' ? '<i class="fa-solid fa-check"></i> Confirm my free appointment' : '<i class="fa-solid fa-check"></i> Confirmar mi cita gratuita';
            alert(currentLang === 'en' ? 'That date and time slot is already taken. Please pick another one.' : 'Esa fecha y franja horaria ya está ocupada. Por favor, elige otra.');
            return;
          }
          await DMEStorage.saveLead({
            name: name.value, phone: phone.value, email: email.value,
            treatment: ($('#selectedServiceInput') && $('#selectedServiceInput').value) || '',
            source: 'web', status: 'appointment_requested',
            notes: ($('#fNotes') && $('#fNotes').value) || '',
          });
        }
        window.DMEAnalytics && DMEAnalytics.event && DMEAnalytics.event('booking.submit');

        const done = () => {
          form.style.display = 'none';
          $('.modal-title').style.display = 'none';
          $('.modal-sub').style.display = 'none';
          $('.wizard-steps').style.display = 'none';
          $('#wizardSuccess').style.display = 'block';
          showBookingPass(name.value);
          if (window.confetti) {
            window.confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
          }
        };

        if (demo || !fid || fid === 'YOUR_FORM_ID') {
          setTimeout(done, 900);
        } else {
          try {
            const data = new FormData(form);
            const res = await fetch(`https://formspree.io/f/${fid}`, { method: 'POST', body: data, headers: { Accept: 'application/json' } });
            if (res.ok) done();
            else alert(currentLang === 'en' ? 'Could not send. Please call us directly.' : 'No se pudo enviar. Llámanos directamente.');
          } catch {
            alert(currentLang === 'en' ? 'Network error. Please try WhatsApp.' : 'Error de red. Usa WhatsApp.');
          } finally {
            submitBtn.disabled = false;
          }
        }
      }
      const submitBtn = $('#modalSubmit');
      if (submitBtn) submitBtn.onclick = handleFormSubmit;
    }
  }

  // -------------------------------------------------------------------
  // EXIT-INTENT POPUP
  // -------------------------------------------------------------------
  function initExitIntent() {
    const modal = $('#exitModal');
    if (!modal) return;
    const enabled = getPath(cfg, 'exitPopup.enabled') !== false;
    if (!enabled) return;

    let shown = sessionStorage.getItem('dental-exit-shown');
    function show() {
      if (shown) return;
      shown = true;
      sessionStorage.setItem('dental-exit-shown', '1');
      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
    }
    function hide() {
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden', 'true');
    }
    // Desktop: mouse leaves top of window
    document.addEventListener('mouseleave', (e) => {
      if (e.clientY <= 5) show();
    });
    // Mobile timer fallback
    const mobDelay = (getPath(cfg, 'exitPopup.mobileDelaySeconds') || 45) * 1000;
    setTimeout(() => { if (window.innerWidth <= 768) show(); }, mobDelay);

    $('#exitClose').onclick = hide;
    $('#exitBackdrop').onclick = hide;
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.classList.contains('open')) hide(); });

    // Mini form saves the lead and continues with the on-site booking flow.
    const form = $('#exitForm');
    if (form) {
      form.onsubmit = (e) => {
        e.preventDefault();
        const name = $('#exitName').value;
        const phone = $('#exitPhone').value;
        if (window.DMEStorage) {
          DMEStorage.saveLead({ name, phone, source: 'exit_intent', status: 'new', notes: 'Solicitud de consulta desde el pop-up de salida.' });
        }
        window.DMEAnalytics && DMEAnalytics.event && DMEAnalytics.event('click.exit_claim');
        const nameField = $('#fName');
        const phoneField = $('#fPhone');
        if (nameField) nameField.value = name;
        if (phoneField) phoneField.value = phone;
        hide();
        const bookingTrigger = $('.js-open-booking');
        if (bookingTrigger) bookingTrigger.click();
      };
    }
  }

  // -------------------------------------------------------------------
  // SMART WHATSAPP (dynamic message per section)
  // -------------------------------------------------------------------
  function initSmartWhatsApp() {
    const wa = $('#whatsappBtn');
    if (!wa) return;
    const number = getPath(cfg, 'whatsapp.number');
    const msgs = cfg.whatsapp && cfg.whatsapp.messages;

    const sections = [
      { sel: '#inicio', key: 'general', tipES: '¿Dudas? Chatea con nosotros', tipEN: 'Questions? Chat with us' },
      { sel: '#servicios', key: 'general', tipES: 'Consulta precios y tratamientos', tipEN: 'Ask about pricing & treatments' },
      { sel: '#galeria', key: 'veneers', tipES: 'Quiero un resultado así', tipEN: 'I want a result like this' },
      { sel: '#doctora', key: 'virtual', tipES: 'Agenda con el doctor', tipEN: 'Book with the doctor' },
      { sel: '#financiamiento', key: 'implants', tipES: 'Pregunta por la financiación 0%', tipEN: 'Ask about 0% financing' },
      { sel: '#opiniones', key: 'general', tipES: 'Habla con un asesor', tipEN: 'Talk to an advisor' },
      { sel: '#contacto', key: 'general', tipES: 'Escríbenos ahora', tipEN: 'Message us now' },
    ];
    let currentKey = 'general';

    function setKey(key, tipES, tipEN) {
      if (key === currentKey && currentKey !== 'general') return;
      currentKey = key;
      const msg = encodeURIComponent(getPath(msgs, `${key}.${currentLang}`) || getPath(msgs, `general.${currentLang}`) || '');
      wa.href = `https://wa.me/${number}?text=${msg}`;
      const tip = $('#whatsappTooltip');
      if (tip) tip.textContent = currentLang === 'en' ? tipEN : tipES;
    }

    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            const match = sections.find((s) => s.sel === '#' + en.target.id);
            if (match) setKey(match.key, match.tipES, match.tipEN);
          }
        });
      },
      { threshold: 0.35 }
    );
    sections.forEach((s) => {
      const el = $(s.sel);
      if (el) obs.observe(el);
    });
    setKey('general', sections[0].tipES, sections[0].tipEN);

    // One-time hint pulse on page load
    const tip = $('#whatsappTooltip');
    if (tip) {
      setTimeout(() => tip.classList.add('hint-show'), 2600);
      setTimeout(() => tip.classList.remove('hint-show'), 7200);
    }
  }

  function updateWhatsAppTooltip() {
    const tip = $('#whatsappTooltip');
    if (!tip) return;
    tip.textContent = currentLang === 'en' ? 'Questions? Chat with us' : '¿Dudas? Chatea con nosotros';
  }

  // -------------------------------------------------------------------
  // THEME (light/dark)
  // -------------------------------------------------------------------
  function initTheme() {
    const saved = localStorage.getItem('dental-theme') || (getPath(cfg, 'settings.defaultTheme') || 'light');
    const toggle = $('#themeToggle');
    function apply(mode) {
      document.body.classList.toggle('dark', mode === 'dark');
      document.documentElement.classList.toggle('dark', mode === 'dark');
      localStorage.setItem('dental-theme', mode);
      const icon = toggle && toggle.querySelector('i');
      if (icon) icon.className = mode === 'dark' ? 'fa-regular fa-sun' : 'fa-regular fa-moon';
    }
    apply(saved);
    if (toggle) toggle.onclick = () => apply(document.body.classList.contains('dark') ? 'light' : 'dark');
  }

  // -------------------------------------------------------------------
  // CUSTOM CURSOR
  // -------------------------------------------------------------------
  function initCursor() {
    if (!matchMedia('(pointer:fine)').matches || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const dot = $('#cursorDot');
    const ring = $('#cursorRing');
    if (!dot || !ring) return;
    let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y;
    addEventListener('mousemove', (e) => {
      x = e.clientX;
      y = e.clientY;
      dot.style.left = x + 'px';
      dot.style.top = y + 'px';
    });
    (function follow() {
      rx += (x - rx) * 0.16;
      ry += (y - ry) * 0.16;
      ring.style.left = rx + 'px';
      ring.style.top = ry + 'px';
      requestAnimationFrame(follow);
      window.DENTAL_APP = { setLanguage, setFilter: renderServices, config: cfg };
})();
    function bindHovers() {
      $$('a, button, input, select, label, .service-card, .case-card, .trust-card, .google-badge, .ba-stage').forEach((el) => {
        el.onmouseenter = () => ring.classList.add('hover');
        el.onmouseleave = () => ring.classList.remove('hover');
      });
    }
    bindHovers();
    document.addEventListener('click', bindHovers);
  }

  // -------------------------------------------------------------------
  // SCROLL EFFECTS (progress, header, toTop, parallax, sticky bar)
  // -------------------------------------------------------------------
  function initScrollEffects() {
    const header = $('#header');
    const toTop = $('#toTop');
    const progress = $('#progress');
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const parallaxEls = reduce ? [] : $$('.parallax');
    let scrollFrame = 0;

    function paintScrollState() {
      const max = document.documentElement.scrollHeight - innerHeight;
      if (progress) progress.style.width = (max > 0 ? (scrollY / max) * 100 : 0) + '%';
      if (header) header.classList.toggle('scrolled', scrollY > 50);
      if (toTop) toTop.classList.toggle('show', scrollY > 700);

      parallaxEls.forEach((el) => { el.style.transform = `translateY(${scrollY * 0.1}px) scale(1.06)`; });
      scrollFrame = 0;
    }
    function onScroll() {
      if (!scrollFrame) scrollFrame = requestAnimationFrame(paintScrollState);
    }
    addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    if (toTop) toTop.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // -------------------------------------------------------------------
  // STAT COUNTERS
  // -------------------------------------------------------------------
  function initCounters() {
    const obs = new IntersectionObserver(
      (entries) =>
        entries.forEach((en) => {
          if (!en.isIntersecting) return;
          const el = en.target;
          const end = +el.dataset.count;
          const suffix = end === 98 ? '%' : '+';
          const start = performance.now();
          function tick(now) {
            const p = Math.min((now - start) / 1500, 1);
            const ease = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(end * ease).toLocaleString('es-ES') + (p >= 1 ? suffix : '');
            if (p < 1) requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);
          obs.unobserve(el);
        }),
      { threshold: 0.6 }
    );
    $$('[data-count]').forEach((el) => obs.observe(el));
  }

  // -------------------------------------------------------------------
  // MOBILE NAV
  // -------------------------------------------------------------------
  function initMobileNav() {
    const nav = $('#mobileNav');
    const hamb = $('#hamb');
    const close = $('#mobileClose');
    const backdrop = $('#mobileBackdrop');
    if (!nav || !hamb) return;
    function open() {
      nav.classList.add('active');
      nav.setAttribute('aria-hidden', 'false');
      hamb.setAttribute('aria-expanded', 'true');
      document.body.classList.add('lock-scroll');
    }
    function hide() {
      nav.classList.remove('active');
      nav.setAttribute('aria-hidden', 'true');
      hamb.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('lock-scroll');
    }
    hamb.onclick = open;
    if (close) close.onclick = hide;
    if (backdrop) backdrop.onclick = hide;
    nav.querySelectorAll('.nav-overlay-links a, .nav-booking').forEach((item) => item.addEventListener('click', hide));
    const serviceToggle = $('#navServicesToggle');
    const serviceMenu = $('#serviceSubMenu');
    if (serviceToggle && serviceMenu) serviceToggle.addEventListener('click', () => {
      const expanded = serviceToggle.getAttribute('aria-expanded') === 'true';
      serviceToggle.setAttribute('aria-expanded', String(!expanded));
      serviceMenu.hidden = expanded;
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && nav.classList.contains('active')) hide(); });
  }

  function initMobileActionBar() {
    const assistantTrigger = $('#mobileAIAssistantButton');
    const assistantPanel = $('#aiPanel');
    if (assistantTrigger) {
      assistantTrigger.addEventListener('click', () => {
        const launcher = $('#aiLaunch');
        if (launcher) launcher.click();
        if (assistantPanel) assistantTrigger.setAttribute('aria-expanded', String(assistantPanel.classList.contains('open')));
      });
      if (assistantPanel) new MutationObserver(() => assistantTrigger.setAttribute('aria-expanded', String(assistantPanel.classList.contains('open')))).observe(assistantPanel, { attributes: true, attributeFilter: ['class'] });
    }
    const trigger = $('#mobileA11yButton');
    const panel = $('#mobileAccessibilityPanel');
    if (!trigger || !panel) return;
    function setPanelOpen(open) {
      panel.classList.toggle('active', open);
      panel.setAttribute('aria-hidden', String(!open));
      trigger.setAttribute('aria-expanded', String(open));
    }
    trigger.addEventListener('click', () => setPanelOpen(!panel.classList.contains('active')));
    const textToggle = $('#mobileTextToggle');
    if (textToggle) textToggle.addEventListener('click', () => {
      const enabled = document.documentElement.classList.toggle('a11y-large-text');
      textToggle.setAttribute('aria-pressed', String(enabled));
    });
    const contrastToggle = $('#mobileContrastToggle');
    if (contrastToggle) contrastToggle.addEventListener('click', () => {
      const enabled = document.body.classList.toggle('a11y-high-contrast');
      contrastToggle.setAttribute('aria-pressed', String(enabled));
    });
    document.addEventListener('click', (event) => {
      if (panel.classList.contains('active') && !panel.contains(event.target) && !trigger.contains(event.target)) setPanelOpen(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && panel.classList.contains('active')) {
        setPanelOpen(false);
        trigger.focus();
      }
    });
  }

  // -------------------------------------------------------------------
  // PRELOADER
  // -------------------------------------------------------------------
  function initPreloader() {
    const pre = $('#preloader');
    const num = $('#loadnum');
    if (!pre) return;
    let n = 0;
    const iv = setInterval(() => {
      n += Math.floor(Math.random() * 9) + 4;
      if (n >= 100) { n = 100; clearInterval(iv); setTimeout(() => { pre.classList.add('done'); setTimeout(() => pre.style.display = 'none', 700); }, 200); }
      if (num) num.textContent = String(n).padStart(2, '0');
    }, 45);
    window.addEventListener('load', () => setTimeout(() => { clearInterval(iv); pre.classList.add('done'); setTimeout(() => pre.style.display = 'none', 700); }, 600));
  }

  // -------------------------------------------------------------------
  // COOKIE BANNER
  // -------------------------------------------------------------------
  function initCookie() {
    const banner = $('#cookieBanner');
    if (!banner) return;
    function loadAnalytics() {
      const gid = getPath(cfg, 'integrations.googleAnalyticsId');
      if (!gid || gid.startsWith('[') || window.__ga4Loaded) return;
      window.__ga4Loaded = true;
      const s = document.createElement('script');
      s.async = true; s.src = `https://www.googletagmanager.com/gtag/js?id=${gid}`;
      document.head.appendChild(s);
      window.dataLayer = window.dataLayer || [];
      function gtag(){ dataLayer.push(arguments); }
      gtag('js', new Date()); gtag('config', gid);
    }
    if (localStorage.getItem('dental-cookie') === 'all') loadAnalytics();
    if (!localStorage.getItem('dental-cookie')) setTimeout(() => banner.classList.add('show'), 1500);
    const save = (v) => { localStorage.setItem('dental-cookie', v); banner.classList.remove('show'); if (v === 'all') loadAnalytics(); };
    const a = $('#cookieAccept'); if (a) a.onclick = () => save('all');
    const r = $('#cookieReject'); if (r) r.onclick = () => save('necessary');
  }

  // -------------------------------------------------------------------
  // HERO VIDEO / IMAGE TOGGLE
  // -------------------------------------------------------------------
  function initHeroMedia() {
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    const slowConnection = connection && (connection.saveData || ['slow-2g', '2g'].includes(connection.effectiveType) || connection.downlink < 1.5);
    const useVideo = Boolean(getPath(cfg, 'settings.heroUseVideo')) && !reduce && !slowConnection;
    const v = $('#heroBgVideo');
    const img = $('#heroBgImage');
    if (v && img) {
      v.style.display = useVideo ? 'block' : 'none';
      img.style.display = useVideo ? 'none' : 'block';
    }
  }

  // -------------------------------------------------------------------
  // MISC: footer year, service filter buttons, AOS, Lenis
  // -------------------------------------------------------------------
  function initMisc() {
    const y = $('#year'); if (y) y.textContent = new Date().getFullYear();

    const currentPage = document.body.dataset.page || 'home';
    $$('[data-page-link]').forEach((link) => {
      if (link.dataset.pageLink === currentPage) link.setAttribute('aria-current', 'page');
    });

    // Service category filter
    $$('.service-filters .filter').forEach((btn) => {
      btn.onclick = () => {
        $$('.service-filters .filter').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        renderServices(btn.dataset.filter);
      };
    });
    const requestedFilter = new URLSearchParams(location.search).get('filter');
    if (['cosmetic', 'ortho', 'implant', 'general'].includes(requestedFilter)) {
      const filterButton = $(`.service-filters .filter[data-filter="${requestedFilter}"]`);
      if (filterButton) {
        $$('.service-filters .filter').forEach((b) => b.classList.remove('active'));
        filterButton.classList.add('active');
        renderServices(requestedFilter);
      }
    }

    // Language switch button
    const sw = $('#langSwitch');
    if (sw) sw.onclick = () => setLanguage(currentLang === 'es' ? 'en' : 'es');

    // FAQ single-open
    document.addEventListener('toggle', (e) => {
      if (e.target.matches && e.target.matches('.faq-item[open]')) {
        $$('.faq-item').forEach((d) => { if (d !== e.target) d.removeAttribute('open'); });
      }
    }, true);

    // AOS
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (window.AOS) AOS.init({ duration: 800, once: true, offset: 60, disable: reduce });

    // Lenis smooth scroll
    // Deep links / hash navigation
    function handleHash() {
      if (location.hash) {
        const t = $(location.hash);
        if (t) {
          if (window.__lenis) window.__lenis.scrollTo(t, { offset: -70 });
          else t.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
    window.addEventListener('hashchange', handleHash);
    window.addEventListener('load', handleHash);

    if (window.Lenis && !reduce) {
      const lenis = new Lenis({ duration: 1.15, smoothWheel: true });
      window.__lenis = lenis;
      lenis.on('scroll', () => { if (window.AOS) AOS.refresh(); });
      function raf(t) { lenis.raf(t); requestAnimationFrame(raf); }
      requestAnimationFrame(raf);
      $$('a[href^="#"]').forEach((a) =>
        a.addEventListener('click', (e) => {
          const target = $(a.getAttribute('href'));
          if (target) {
            e.preventDefault();
            lenis.scrollTo(target, { offset: -70 });
          }
        })
      );
    }
  }

  // -------------------------------------------------------------------
  // FULLSCREEN GALLERY MODAL
  // -------------------------------------------------------------------
  function initGalleryModal() {
    const modal = $('#galleryModal');
    if (!modal) return;
    const img = $('#galleryModalImg');
    const cap = $('#galleryModalCap');
    let current = 0;
    function collect() {
      return $$('.cases-grid .case-card img').map((im) => {
        const card = im.closest('.case-card');
        return { src: im.src, title: (card && card.dataset.title) || im.alt, treatment: card && card.dataset.treatment };
      });
    }
    function show(i) {
      const items = collect();
      if (!items.length) return;
      current = (i + items.length) % items.length;
      img.src = items[current].src;
      img.alt = items[current].title || '';
      cap.textContent = items[current].title ? `${items[current].title}${items[current].treatment ? ' · ' + items[current].treatment : ''}` : '';
      modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
    }
    function hide() { modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); }
    document.addEventListener('click', (e) => {
      const c = e.target.closest('.cases-grid .case-card img');
      if (c) { const items = collect(); const i = items.findIndex((x) => x.src === c.src); show(i >= 0 ? i : 0); }
    });
    $('#galleryClose').onclick = hide;
    $('#galleryBackdrop').onclick = hide;
    $('#galleryPrev').onclick = () => show(current - 1);
    $('#galleryNext').onclick = () => show(current + 1);
    document.addEventListener('keydown', (e) => {
      if (!modal.classList.contains('open')) return;
      if (e.key === 'Escape') hide();
      if (e.key === 'ArrowLeft') show(current - 1);
      if (e.key === 'ArrowRight') show(current + 1);
    });
  }

  // -------------------------------------------------------------------
  // THEME SYSTEM (data-theme on html)
  // -------------------------------------------------------------------
  function initThemeSystem() {
    const t = localStorage.getItem('dme-preview-theme') || (cfg.settings && cfg.settings.theme) || 'luxury-studio';
    document.documentElement.setAttribute('data-theme', t);
  }

  // -------------------------------------------------------------------
  // ANALYTICS & AI WIDGET
  // -------------------------------------------------------------------
  function initAnalyticsAndAI() {
    window.DMEAnalytics && DMEAnalytics.bindTrackers && DMEAnalytics.bindTrackers();
    window.DMEAI && DMEAI.mount && DMEAI.mount(cfg);
  }

  // -------------------------------------------------------------------
  // FEATURE FLAGS (cfg.features)
  // -------------------------------------------------------------------
  function initFeatureFlags() {
    const f = cfg.features || {};
    if (f.financingCalculator === false) { const s = $('#financiamiento'); if (s) s.style.display = 'none'; }
    if (f.googleReviews === false) { const s = $('#opiniones'); if (s) s.style.display = 'none'; }
    if (f.faq === false) { const s = $('#faq'); if (s) s.style.display = 'none'; }
    if (f.beforeAfterGallery === false) { const s = $('#galeria'); if (s) s.style.display = 'none'; }
    if (f.darkThemeToggle === false) { const b = $('#themeToggle'); if (b) b.style.display = 'none'; }
    if (f.languageSwitch === false) { const s = $('#langSwitch'); if (s) s.style.display = 'none'; }
  }

  // -------------------------------------------------------------------
  // MODERN IMAGE FORMATS (WebP with JPG fallback)
  // -------------------------------------------------------------------
  function initModernImages() {
    const canvas = document.createElement('canvas');
    const supported = canvas.toDataURL('image/webp').startsWith('data:image/webp');
    if (!supported) return;
    $$('img[src$=".jpg"], img[src$=".jpeg"]').forEach((img) => {
      img.src = img.src.replace(/\.(jpe?g)(\?.*)?$/i, '.webp$2');
    });
    $$('[style*="background-image"]').forEach((el) => {
      el.style.backgroundImage = el.style.backgroundImage.replace(/\.(jpe?g)([\'\")])/gi, '.webp$2');
    });
  }

  // -------------------------------------------------------------------
  // BOOTSTRAP
  // -------------------------------------------------------------------
  document.addEventListener('DOMContentLoaded', () => {
    initPreloader();
    initThemeSystem();
    initTheme();
    setLanguage(currentLang);
    initModernImages();
    initHeroMedia();
    initBeforeAfter();
    initCalculator();
    initModal();
    initExitIntent();
    initSmartWhatsApp();
    initCursor();
    initScrollEffects();
    initCounters();
    initMobileNav();
    initCookie();
    initGalleryModal();
    initAnalyticsAndAI();
    initMobileActionBar();
    initFeatureFlags();
    initMisc();
  });
  window.DENTAL_APP = { setLanguage, setFilter: renderServices, config: cfg };
})();

-- DENTAL MASTER ENTERPRISE — demo seed data
-- Apply with: wrangler d1 execute <DB_NAME> --file=db/seed.sql

INSERT OR IGNORE INTO leads (id, name, phone, email, treatment, source, status, notes, assignee, follow_up, created_at) VALUES
 ('l1','María Gómez','+34600111222','maria@example.com','veneers','web','new','Interesada en 8 carillas superiores','u3','2026-11-12','2026-11-08T10:30:00Z'),
 ('l2','David Navarro','+34611222333','david@example.com','invisalign','whatsapp','contacted','Llamada hecha; pide valoración gratuita','u3','2026-11-10','2026-11-07T16:00:00Z'),
 ('l3','Sandra Ortiz','+34622333444','sandra@example.com','implants','google_ads','appointment_requested','All-on-4 superior','u2','2026-11-09','2026-11-06T09:15:00Z'),
 ('l4','Pablo Ruiz','+34633444555','pablo@example.com','whitening','instagram','appointment_confirmed','Cita 15 nov 11:00','u3','2026-11-15','2026-11-05T12:00:00Z'),
 ('l5','Claudia Vega','+34644555666','claudia@example.com','general','referral','consultation_done','Revisión realizada; presupuesto carillas','u2','2026-11-13','2026-11-02T11:00:00Z'),
 ('l6','Jorge Blanco','+34655666777','jorge@example.com','emergency','phone','converted','Urgencia tratada; fidelizado','u3',NULL,'2026-10-30T17:00:00Z'),
 ('l7','Elena Torres','+34666777888','elena@example.com','implants','facebook_ads','treatment_pending','Esperando radiografía externa','u2','2026-11-18','2026-10-25T14:00:00Z'),
 ('l8','Rosa M.','+34677888999','rosa@example.com','rootcanal','exit_intent','lost','No responde tras 3 intentos','u4',NULL,'2026-10-20T10:00:00Z');

INSERT OR IGNORE INTO appointments (id, service, specialist, location, date, slot, name, phone, email, notes, status, created_at) VALUES
 ('a1','veneers','[NOMBRE_DOCTOR]','goya','2026-11-15','Mañana (09:00–14:00)','Pablo Ruiz','+34633444555','pablo@example.com','Primera valoración','confirmed','2026-11-05T12:00:00Z'),
 ('a2','invisalign','[NOMBRE_DOCTOR]',NULL,'2026-11-16','Tarde (14:00–18:00)','Sandra Ortiz','+34622333444','sandra@example.com','Estudio ortodóntico','pending','2026-11-06T09:15:00Z'),
 ('a3','general','[NOMBRE_DOCTOR]','chamartin','2026-11-10','Mañana (09:00–14:00)','Claudia Vega','+34644555666','claudia@example.com','Revisión anual','completed','2026-11-02T11:00:00Z');

INSERT OR IGNORE INTO automations (id, name, trigger, condition, action, action_detail, enabled, last_run) VALUES
 ('auto-new-inquiry','Nueva solicitud de información','lead.created','true','internal_notification','Notificar al equipo por email interno',1,'2026-11-08T10:30:10Z'),
 ('auto-appt-confirm','Confirmación de cita','appointment.confirmed','true','email_patient','Enviar email con fecha, hora y ubicación',1,'2026-11-05T12:02:00Z'),
 ('auto-reminder','Recordatorio 24 h antes','appointment.reminder_due','true','sms_patient','SMS con botón de confirmación',1,NULL),
 ('auto-missed','Seguimiento de cita no presentada','appointment.no_show','true','whatsapp_followup','Mensaje amable para reprogramar',0,NULL),
 ('auto-review','Solicitud de reseña en Google','appointment.completed','appointment.service <> ''emergency''','email_review_link','Email con enlace directo a la ficha de Google',1,'2026-11-02T11:05:00Z'),
 ('auto-reactivate','Reactivación de pacientes inactivos','schedule.monthly','months_since_last_visit >= 12','email_recall','Recordatorio de revisión anual',0,NULL),
 ('auto-stalled','Seguimiento de consultas sin respuesta','schedule.daily','lead.status == ''new'' AND lead.age_hours >= 48','task_assign','Crear tarea para recepción',1,NULL);

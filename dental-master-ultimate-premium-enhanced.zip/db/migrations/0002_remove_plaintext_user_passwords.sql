-- PRECAUCIÓN: ejecutar solo tras exportar/respaldar la D1 y verificar los datos.
-- Elimina contraseñas heredadas en claro; no intenta convertirlas a hashes.
-- Las cuentas para el login actual se configuran en el secreto USERS.
-- Ejecutar únicamente en una copia de staging primero.
ALTER TABLE users ADD COLUMN password_hash TEXT;
UPDATE users SET password_hash = NULL;
ALTER TABLE users DROP COLUMN pass;

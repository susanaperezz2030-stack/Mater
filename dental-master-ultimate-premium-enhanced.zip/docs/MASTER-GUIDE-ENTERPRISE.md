# DENTAL MASTER ENTERPRISE v2.0 — Guía Maestra

Esta guía documenta la versión **Enterprise** de la plantilla web para clínicas dentales: qué incluye, cómo se personaliza para cada cliente, cómo operarla y cómo monetizarla como servicio de agencia.

---

## 1. Qué es este producto

**Dental Master Enterprise** es una solución web completa para odontología que une diseño premium (inspirado en la estética Apple/macOS pero con 6 identidades visuales distintas), un **CRM de pacientes** con canalización de 8 estados, un **sistema de citas inteligentes** con prevención de dobles reservas, un **motor de automatizaciones**, un **asistente FAQ local bilingüe** y un **panel de administración con roles**, todo sobre una arquitectura que funciona **estática** (100% independiente de backend) o con un **backend opcional en Cloudflare (Pages + Functions + D1 + KV)** sin coste recurrente.

## 2. Mapa de archivos

| Carpeta / archivo | Propósito |
|---|---|
| `index.html` | Sitio público rediseñado con placeholders estandarizados |
| `admin.html` | Panel de administración |
| `aviso-legal.html`, `politica-privacidad.html`, `politica-cookies.html`, `404.html` | Páginas legales reales y 404 de marca |
| `siteData.js` | Configuración de cada clínica |
| `app.js`, `style.css` | Motor interactivo y sistema de diseño (CSS variables) |
| `assets/themes/` | 6 temas CSS independientes (`themes.json` con metadatos) |
| `assets/icons/`, `assets/images/` | 22 iconos SVG y 12 fotos optimizadas + video demo |
| `config/` | `schema.json`, `validator.js`, ejemplos validados |
| `modules/` | CRM, citas, automatizaciones, IA, analítica, panel admin, storage adapter |
| `functions/api/` | Endpoints Cloudflare Pages Functions para auth, CRM, citas, automatizaciones y ajustes |
| `db/` | Esquema D1 SQLite + datos demo |
| `tests/` | Suites del validador, Pages Functions/D1, rutas Cloudflare, FAQ local y E2E |
| `docs/` | Esta documentación + capturas verificadas |

## 3. Los 6 temas visuales

| ID | Nombre | Especialidad sugerida | Colores clave |
|---|---|---|---|
| `luxury-studio` | Luxury Dental Studio | Alta gama / diseño de sonrisa | Marfil, champán, café |
| `modern-family` | Modern Family Dentistry | Clínica familiar | Azul marino, cielo |
| `cosmetic` | Cosmetic Dentistry | Estética dental | Negro editorial, oro rosa |
| `premium-implants` | Premium Implant Center | Implantología | Pizarra, titanio, cerceta |
| `orthodontic` | Orthodontic Specialist | Ortodoncia / Invisalign | Menta, índigo |
| `boutique` | Boutique Dental Clinic | Clínica boutique | Arena, terracota, salvia |

El tema se define en `siteData.js > settings.theme` y se aplica como `data-theme` en el elemento `<html>`. Cada tema define más de 40 tokens CSS propios (colores, sombras, contrastes, fuentes).

## 4. Personalización paso a paso

1. **Copia de seguridad**: haz una copia de `siteData.js` antes de editar.
2. **Rellena los datos**: reemplaza los valores entre corchetes (`[NOMBRE_CLINICA]`, `[TELEFONO]`, `[EMAIL_CLINICA]`, etc.) según [EDITABLE-FIELDS.md](EDITABLE-FIELDS.md).
3. **Elige tema**: `settings.theme = 'modern-family'` (o el que corresponda).
4. **Valida**: ejecuta `pnpm run test:validator` o abre el panel (`admin.html`) para comprobar que no quedan placeholders.
5. **Fotos**: sustituye las imágenes de `assets/images/` respetando los nombres de archivo recomendados en EDITABLE-FIELDS.md.
6. **Citas y formulario**: introduce tu `form.formspreeId` (gratis en [formspree.io](https://formspree.io)) o usa el backend Cloudflare.
7. **Páginas legales**: completa los datos fiscales reales en las tres páginas legales antes de publicar.
8. **Prueba final**: ejecuta `pnpm test` (suite completa automatizada) y revisa visualmente con el checklist de entrega.

## 5. CRM de pacientes

El CRM registra automáticamente cada interacción comercial:

- **Origen**: web, WhatsApp, Google Ads, Instagram, Facebook Ads, teléfono, recomendación, pop-up de salida.
- **Canalización**: Nuevo → Contactado → Cita solicitada → Cita confirmada → Consulta realizada → Tratamiento pendiente → Convertido → Perdido.
- **Funciones**: búsqueda en tiempo real, filtros por estado y origen, tarjetas con datos de contacto, tratamiento, responsable asignado y fecha de seguimiento; vista tabla alternativa; exportación CSV; panel de KPIs (leads totales, nuevos, convertidos, tasa de conversión).
- **Aviso de privacidad integrado**: el CRM almacena únicamente datos de marketing; los datos médicos se gestionan en sistemas sanitarios independientes.

## 6. Sistema de citas inteligentes

- CRUD completo de citas con estados: pendiente, confirmada, realizada, cancelada (con motivo).
- Detección de dobles reservas: el sistema rechaza una segunda reserva con la misma combinación **fecha + franja horaria + sede**, tanto en el cliente como en el endpoint del servidor (HTTP 409).
- Reprogramación asistida con cambio de franja.
- Selector de sede para clínicas multi-ubicación y selector de profesional para equipos con varios especialistas.

## 7. Motor de automatizaciones

7 flujos pre-configurados:

1. **Nueva solicitud**: notificación interna al equipo
2. **Confirmación de cita**: email al paciente con fecha, hora y sede
3. **Recordatorio 24 h antes**: SMS con confirmación
4. **Cita no presentada**: seguimiento empático para reprogramar
5. **Solicitud de reseña en Google**: tras cada cita completada (excluye urgencias)
6. **Reactivación**: pacientes sin visita en más de 12 meses
7. **Consultas sin respuesta**: alerta cuando un lead nuevo lleva 48 h estancado

Cada flujo tiene interruptor, botón «Probar ahora», fecha de última ejecución y registro con estado de éxito/error. En producción con Cloudflare Functions se conectan proveedores reales (Resend para email, Twilio para SMS) respetando el consentimiento del paciente y las solicitudes de baja.

## 8. Asistente FAQ local bilingüe (Sofía)

- Widget flotante en la esquina inferior derecha con conversación en español e inglés.
- Conocimiento base sobre tratamientos, precios orientativos, financiación, horarios y reserva de cita.
- **Guardrails médicos**: nunca diagnostica, prescribe ni promete resultados clínicos; ante urgencias remite al teléfono de la clínica o al WhatsApp de atención prioritaria.
- El asistente FAQ es completamente local: búsqueda por palabras clave en español e inglés, sin proveedor externo, llamadas de red ni claves de API.
- El módulo se puede desactivar con `features.aiAssistant = false`.

## 9. SEO y analítica

- Schema.org JSON-LD `Dentist` en `index.html` (completa los datos reales antes de publicar; no añadas valoraciones agregadas no verificables).
- `sitemap.xml` y `robots.txt` listos para producción; `_headers` con cabeceras de seguridad estrictas (CSP, HSTS, frame-ancestors).
- Metadatos dinámicos desde `siteData.js > seo` (título, descripción, canonical, `og:image`, Google Search Console).
- Captura de parámetros UTM (`utm_source`, `utm_medium`, `utm_campaign`...) en cada contacto.
- Google Analytics 4 se carga **únicamente tras el consentimiento explícito** del usuario en el banner de cookies.

## 10. Despliegue

### Opción A — Sitio estático puro (gratuito)
Arrastra la carpeta a **Cloudflare Pages**, o conecta un repositorio GitHub. Funciona también en Vercel, Netlify o cualquier hosting estático. El CRM y las citas usan almacenamiento local del navegador en este modo.

### Opción B — Con backend opcional (Cloudflare gratuito)
Consulta la guía paso a paso: [DEPLOY-CLOUDFLARE.md](DEPLOY-CLOUDFLARE.md). Incluye base de datos D1 SQLite, KV para ajustes y las Pages Functions de origen en `functions/api/`, expuestas al navegador como rutas `/api/*`.

## 11. Modelo de seguridad y datos de salud

- Este producto es una herramienta de marketing. La conformidad HIPAA/GDPR completa exige medidas adicionales más allá del software.
- Los formularios recogen solo datos de contacto. La información médica vive en el historial clínico de la clínica.
- Consulta [SECURITY-HIPAA.md](SECURITY-HIPAA.md) para el análisis de riesgos y la lista de control.

## 12. Cómo monetizarlo como agencia

**Propuesta de valor**: vendes a cada clínica una presencia web de calidad quirúrgica (6 temas a elegir, CRM, citas y automatizaciones) que tardas **~2–4 horas** en personalizar y validar con la suite automatizada.

**Estructura de precios sugerida**:

| Servicio | Precio recomendado |
|---|---|
| Personalización y lanzamiento (sitio + CRM demo) | 1.200–2.000 € / $ |
| Activación backend Cloudflare + asistente FAQ local + GA4 | +600–1.000 € / $ |
| Mantenimiento mensual (hosting, backups, contenidos) | 100–250 €/mes |

Con una única clínica cierras el producto; con tres o más la rentabilidad es excelente porque el 90% del trabajo es reutilizable.

---

**Soporte**: las pruebas automáticas (`pnpm test`) son el árbitro de calidad. Si alguna falla, no entregues el sitio hasta resolverla.

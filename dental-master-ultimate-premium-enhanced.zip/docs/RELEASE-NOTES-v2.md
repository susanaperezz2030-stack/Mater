> Documento histórico de la versión 2.0. Para el estado actual de la edición Ultimate, consulta [RELEASE-NOTES-ULTIMATE.md](RELEASE-NOTES-ULTIMATE.md).

# DENTAL MASTER ENTERPRISE — Notas de la Versión 2.0

*9 de noviembre de 2026*

Esta versión histórica transformó una plantilla web premium de una sola página en un **producto comercial completo** con panel de administración, CRM, citas inteligentes, automatizaciones, asistente FAQ local, backend opcional y suite de pruebas.

---

## Novedades principales

### Sistema de temas 6-en-1 (Fase 4–5)
- 6 identidades visuales completas con más de 40 tokens CSS cada una: Luxury Dental Studio, Modern Family Dentistry, Cosmetic Dentistry, Premium Implant Center, Orthodontic Specialist, Boutique Dental Clinic.
- Cargador CSS (`themes.css`) y metadatos (`themes.json`) listos para selectores y herramientas.
- Esquema de configuración `schema.json` y validador `validator.js` que detecta campos obligatorios, formatos y marcadores pendientes.
- Configuración de ejemplo 100% validada (`config/examples/auradental.config.js`).

### Panel de administración profesional (Fase 6)
- Entrada dedicada `admin.html` con inicio de sesión por roles (`administrator`, `manager`, `receptionist`, `marketing`).
- Cuadro de mando con KPIs en tiempo real (leads totales, nuevos, citas pendientes, tasa de conversión).
- Próximas citas y últimos leads agregados desde el CRM.

### CRM de pacientes (Fase 7)
- Canalización de 8 estados con tarjetas drag-style.
- Filtros por estado y origen, búsqueda en tiempo real, vista tabla, exportación CSV.
- Ficha de lead editable con notas, responsable y fecha de seguimiento.
- Aviso de privacidad integrado que recuerda no almacenar datos médicos sensibles.

### Citas inteligentes (Fase 7)
- CRUD con estados (pendiente, confirmada, realizada, cancelada con motivo), reprogramación.
- **Prevención de dobles reservas** validada en cliente y en servidor (HTTP 409).
- Soporte para selectores de sede y de profesional en el wizard público.

### Motor de automatizaciones (Fase 7)
- 7 flujos pre-configurados con disparadores, condiciones y acciones.
- Botón «Probar ahora», fecha de última ejecución y registro de éxitos/errores.
- Simulación de canales y conexión preparada con proveedores reales (Resend, Twilio).

### Asistente FAQ local premium — Sofía (Ultimate)
- Widget bilingüe con coincidencia inteligente de palabras clave para precios, horarios, ubicación, citas, seguros y urgencias.
- Indicador animado «Escribiendo…» con demora real de 1 segundo.
- **Sin llamadas remotas, proveedores de IA ni claves API.**

### Arquitectura y backend opcional (Fases 8–9)
- Capa de almacenamiento transparente (`storage-adapter.js`) con fallback a localStorage en modo estático.
- Cloudflare Pages Functions de auth, leads, appointments, automations y settings; la ruta legacy de chat queda desactivada. CRM y citas conservan su integración D1.
- Esquema D1 SQLite + datos demo.
- `sitemap.xml`, `robots.txt`, `_headers` de seguridad, `_redirects`.
- GA4 cargado tras consentimiento explícito; captura UTM en cada contacto.

### Páginas legales reales
- `aviso-legal.html`, `politica-privacidad.html`, `politica-cookies.html`, `404.html` sustituyen los antiguos `alert()` del footer.

### Calidad y pruebas (Fase 10)
- Suite de pruebas inicial de validador, backend y navegación E2E; consulta `RELEASE-NOTES-ULTIMATE.md` para el estado vigente.
- 10 capturas de verificación visual en `docs/screenshots/`.

### Documentación completa (Fase 11)
- 7 guías: Guía Maestra, referencia de campos, despliegue Cloudflare, seguridad/HIPAA, notas de versión, hoja comercial, y centro interactivo `docs/index.html`.

## Correcciones respecto a la versión 1.0

- Corregido el bug por el cual reabrir el modal de cita no restauraba la vista del formulario tras un envío completado.
- Corregida la ausencia de foco en el comparador antes/después para mejorar accesibilidad por teclado.
- Los enlaces legales del footer ahora apuntan a páginas reales con contenido adaptado a clínicas odontológicas.
- Los iconos inline base64 de la versión original ya no existen; el HTML es ~99% más ligero.

## Compatibilidad

- Funciona como sitio **100% estático** sin ningún servidor especial (el CRM opera en el navegador).
- El backend opcional requiere Cloudflare Pages + D1 (ambos gratuitos).
- Compatible con Chrome, Safari, Firefox, Edge en escritorio y móvil.

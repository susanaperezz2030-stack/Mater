# Publicar Dental Master Ultimate en Cloudflare Pages

La configuración añade Wrangler y una carpeta `dist/` con los archivos públicos del sitio. Las Pages Functions se conservan en `functions/` en la raíz del repositorio; Cloudflare las convierte en rutas `/api/*`. No copies `functions/` dentro de `dist/` ni reemplaces los HTML, CSS o módulos del panel.

El nombre tomado del ZIP de producción es `rhd-dental-group`. Si el proyecto Pages existente tiene otro nombre, cámbialo en `wrangler.toml` y en los comandos de `package.json` antes de desplegar.

## Importante para un proyecto que ya tiene D1

Wrangler puede usar `wrangler.toml` como fuente de configuración de Pages. Antes de desplegar a un proyecto existente, inicia sesión y descarga su configuración real para conservar el binding D1 conectado. Cloudflare recomienda sincronizar la configuración del Dashboard antes de activar Wrangler como fuente de verdad. [Configuración Wrangler de Pages](https://developers.cloudflare.com/pages/functions/wrangler-configuration/)

```bash
pnpm install
pnpm exec wrangler login
pnpm run pages:sync-config
```

`pages:sync-config` descarga la configuración actual del proyecto y puede reemplazar `wrangler.toml`. En ese archivo conserva el bloque `[[d1_databases]]` existente con `binding = "DB"`, `database_name` y el `database_id` real. Cambia `pages_build_output_dir` a `"./dist"` y conserva el nombre del proyecto. No sustituyas el ID por un ejemplo ni borres el bloque D1. El comando de despliegue incluye una comprobación y se detendrá si no encuentra ese binding.

En Cloudflare, la carpeta `functions/` debe permanecer en la raíz del proyecto, fuera de `dist/`. El binding `DB` es lo que usan las Functions para leer y escribir en D1. [Estructura de Pages Functions](https://developers.cloudflare.com/pages/functions/get-started/) · [Bindings D1](https://developers.cloudflare.com/pages/functions/bindings/)

## Despliegue Direct Upload con Functions

Desde la raíz del proyecto ejecuta:

```bash
pnpm run deploy
```

El comando comprueba que Wrangler conserva el binding D1 `DB`, prepara `dist/` y publica esa carpeta junto a las Functions detectadas en la raíz. Para crear el proyecto por primera vez, usa el nombre indicado en `wrangler.toml`; si ya existe, no crees otro. El ZIP por sí solo no despliega. Tampoco uses `wrangler deploy`: este proyecto es Cloudflare Pages, así que el comando correcto es `wrangler pages deploy`.

No uses el arrastrar y soltar del Dashboard para una publicación que necesite CRM, citas o D1: la carga manual del Dashboard publica assets estáticos y no compila la carpeta `functions/`. Para Direct Upload con Functions, Cloudflare requiere Wrangler. [Direct Upload y Functions](https://developers.cloudflare.com/pages/get-started/direct-upload/)

## Git integration alternativa

Si el proyecto está conectado a Git, conserva `functions/` en la raíz del repositorio y configura **Framework preset: None**, **Build command: `pnpm run prepare:pages`** y **Build output directory: `dist`**. Sincroniza antes `wrangler.toml` con la configuración del proyecto que ya tiene D1, y comprueba que el binding `DB` figure allí. No despliegues con un `wrangler.toml` parcial: al usar la configuración Wrangler, esa configuración pasa a ser la referencia del proyecto.

## Variables y bindings

Las Pages Functions actuales leen el binding `DB` para CRM, citas, automatizaciones y ajustes. Si ya está vinculado en el proyecto existente, mantenlo; no crees una base nueva ni vuelvas a cargar el esquema sólo por esta integración. No ejecuté migraciones ni escribí en D1 durante esta preparación.

Configura `SESSION_SECRET` como secreto de Pages con al menos 32 caracteres aleatorios (por ejemplo, genera el valor fuera del repositorio con `openssl rand -base64 48`). No lo guardes en Git.

Para las cuentas, genera un hash PBKDF2 desde la raíz del proyecto con `pnpm run hash-password` (requiere una terminal interactiva y al menos 14 caracteres). Guarda `USERS` como secreto JSON con el hash, nunca con la contraseña:

```json
[{"id":"admin-1","name":"Administración","email":"admin@tuclinica.com","passwordHash":"pbkdf2$310000$...$...","role":"administrator"}]
```

El modo demo requiere `DEMO_MODE=true` y no debe activarse en producción. Sin `USERS` válido y `SESSION_SECRET`, el login responde `503`. Se emite una cookie firmada, `HttpOnly`, `Secure`, `SameSite=Strict`, con expiración de 8 horas.

El middleware protege las lecturas y cambios de CRM, agenda, automatizaciones y ajustes con roles; solo se mantienen públicos los `POST` de captura de leads y creación de cita. Se rechazan orígenes cruzados. Aplica `db/schema.sql` en el entorno de prueba para activar el índice único de disponibilidad. Antes de aplicar ese índice a una D1 existente, consulta y resuelve los duplicados activos.

Para una instalación antigua, `db/migrations/0002_remove_plaintext_user_passwords.sql` elimina la columna heredada de contraseñas en claro y no convierte esas claves. Requiere respaldo y ejecución manual en staging; **no la ejecutes si el esquema ya tiene `password_hash` ni contra producción sin aprobación y plan de recuperación**. Las cuentas del login implementado se leen desde `USERS`; el alta de usuarios en el panel aún no está conectada al backend.

`KV` es opcional para ajustes; si no está vinculado, los ajustes usan la tabla `settings` de D1. **La administración de usuarios del panel sigue siendo solo local y no crea cuentas en el backend.** Las rutas públicas de captura todavía necesitan límites de frecuencia y protección anti-spam (por ejemplo, Turnstile/Rate Limiting) antes de abrirlas a tráfico público.

## Previsualización local y comprobaciones

```bash
pnpm run dev:pages
pnpm test
```

`dev:pages` prepara `dist/` y levanta Pages localmente. No conectes la previsualización a la base D1 de producción. `pnpm test` conserva las pruebas del sitio, del chatbot local, de rutas y del backend simulado.

La integración de Cloudflare añadida incluye `wrangler.toml`, scripts de preparación y preflight, `.gitignore` para archivos locales sensibles, headers y redirects de Pages. La estética, el panel y las Pages Functions existentes se mantienen.

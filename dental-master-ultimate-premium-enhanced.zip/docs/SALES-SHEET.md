# DENTAL MASTER ENTERPRISE — Hoja Comercial (One-Pager)

## Qué es

La solución web más completa del mercado para **clínicas dentales**: sitio público de alta conversión con 6 identidades visuales, CRM de pacientes, gestión de citas con anti-doble-reserva, motor de automatizaciones, asistente virtual seguro y panel de administración con roles. Todo en un paquete listo para personalizar en 2–4 horas.

## El problema que resolvemos

La mayoría de clínicas dentales conviven con:

- Webs antiguas sin versión móvil cuidada y con tiempos de carga de 8+ segundos
- Solicitudes de cita que llegan a un buzón sin seguimiento comercial (leads que se enfrían)
- Reseñas de Google desaprovechadas como palanca de captación
- Herramientas caras de suscripción mensual que no necesitan

## La solución en 10 pilares

1. **6 temas visuales** — una identidad que encaja con cada tipo de clínica (familiar, estética, implantes, ortodoncia, boutique, lujo).
2. **Diseño de alta conversión** — hero persuasivo, comparador antes/después interactivo, calculadora de financiación, pop-up de salida.
3. **Bilingüe nativo ES/EN** — cambio instantáneo para mercados con pacientes internacionales.
4. **CRM integrado** — cada formulario, botón de llamada, WhatsApp y clic UTM queda registrado en la canalización de 8 estados.
5. **Citas sin conflictos** — prevención de doble reserva en cliente y servidor.
6. **Automatizaciones** — confirmaciones, recordatorios, reseñas y reactivación sin intervención manual.
7. **Asistente IA seguro** — responde dudas 24/7 con guardrails médicos y escalado a WhatsApp.
8. **Panel de administración** — métricas del negocio en tiempo real accesibles por rol.
9. **Backend gratuito** — Cloudflare Pages + D1 SQLite: 0 €/mes en la capa gratuita.
10. **Calidad probada** — pruebas automatizadas del validador, backend, rutas y flujos de navegador antes de cada entrega.

## Para quién es

- **Agencias y freelancers** que quieren un producto web dental llave en mano con margen alto.
- **Clínicas independientes** que quieren una presencia profesional sin dependencia de terceros.
- **Redes de clínicas** que necesitan multi-sede, multi-especialista y control por roles.

## Modelo de precios sugerido (agencia)

| Servicio | Precio recomendado |
|---|---|
| Sitio + CRM demo configurado (personalización básica) | 1.200–2.000 € / $ |
| Activación backend Cloudflare + FAQ local + GA4 + páginas legales reales | +600–1.000 € / $ |
| Mantenimiento mensual (hosting, backups, contenidos, soporte) | 100–250 €/mes |

Con una única clínica el producto queda amortizado; cada clínica adicional es un proyecto de ~2–4 horas con margen superior al 80%.

## ROI de la clínica

Un solo tratamiento de implantes o Invisalign (2.500–5.000 €/$) captado gracias al sitio cubre el proyecto completo. Las clínicas reportan que pasar de una web antigua a esta solución multiplica las solicitudes entrantes por 2–4 en los primeros 90 días.

## Qué incluye la entrega

- Código fuente completo (sitio público + panel admin + backend Functions + D1 + suite automatizada)
- 6 temas CSS con más de 40 tokens cada uno
- 22 iconos SVG + 12 fotos optimizadas + video demo
- 7 guías paso a paso + centro de documentación interactivo
- Capturas de verificación visual

## Garantía de calidad

El producto incluye una suite de pruebas automáticas que validan la configuración, el backend y el flujo de navegación completo. La regla de entrega es simple: si alguna prueba falla, no se publica.

# DENTAL MASTER ENTERPRISE — Referencia de Campos Editables

Todos los valores de personalización se editan en **`siteData.js`**. La siguiente tabla recoge cada campo, su propósito y los valores de ejemplo. Tras editar, valida con `pnpm run test:validator` para asegurar que no quedan placeholders sin rellenar.

---

## 1. Identidad de la clínica (`clinic`)

| Campo | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `clinic.name` | texto | Sí | Nombre oficial de la clínica |
| `clinic.nameShort` | texto | No | Nombre corto para el logo/cabecera |
| `clinic.badge` | texto | No | Etiqueta sobre el título hero |
| `clinic.tagline` | objeto {es,en} | Sí | Titular principal del hero |
| `clinic.subtitle` | objeto {es,en} | No | Subtítulo descriptivo |
| `clinic.city` | texto | Sí | Ciudad |
| `clinic.country` | texto | Sí | País |
| `clinic.yearFounded` | texto | No | Año de fundación (verificable) |
| `clinic.license` | texto | No | Nº de registro/licencia sanitaria |

## 2. Contacto (`contact`)

| Campo | Tipo | Obligatorio | Descripción |
|---|---|---|---|
| `contact.phone` | texto | Sí | Teléfono sin símbolos, con código país (+34...) |
| `contact.phoneFormatted` | texto | No | Teléfono con formato visible |
| `contact.email` | email | Sí | Email de contacto público |
| `contact.address` | texto | Sí | Dirección completa |
| `contact.mapsUrl` | url | No | Enlace de Google Maps para el botón «Cómo llegar» |
| `contact.mapsEmbedUrl` | url | No | URL embed del iframe de mapa |

## 3. Multi-sede (`locations`) — NUEVO Enterprise

Array opcional. Cuando contiene al menos una sede, el wizard de cita muestra el selector de sede.

```js
locations: [
  { id: 'goya', name: 'Sede Goya · Calle Goya 45', phone: '+34910000001', address: 'Calle Goya 45, Madrid', city: 'Madrid', mapsUrl: 'https://maps.app.goo.gl/...' },
  { id: 'chamartin', name: 'Sede Chamartín · Paseo de la Castellana 180', phone: '+34910000002', address: 'Castellana 180, Madrid', city: 'Madrid', mapsUrl: 'https://maps.app.goo.gl/...' }
]
```

## 4. WhatsApp inteligente (`whatsapp`)

| Campo | Tipo | Descripción |
|---|---|---|
| `whatsapp.number` | dígitos (8-15) | Código país sin + |
| `whatsapp.messages` | objeto | Mensaje pre-escrito por sección y por idioma (general, veneers, etc.) |

## 5. Equipo médico (`team` y legacy `doctor`) — NUEVO Enterprise

El array `team` añade especialistas al selector del wizard; `doctor` (singular) se conserva por compatibilidad y alimenta la tarjeta del hero.

```js
team: [
  { id: 'dr-garcia', name: 'Dr. Alejandro García', role: { es: 'Implantología y cirugía oral', en: 'Implantology & oral surgery' }, credentials: 'Col. 28004561', photo: 'assets/images/team-garcia.jpg' },
  { id: 'dra-lopez', name: 'Dra. María López', role: { es: 'Ortodoncia invisible (Invisalign Provider)', en: 'Clear aligners (Invisalign Provider)' }, credentials: 'Col. 28004990', photo: 'assets/images/team-lopez.jpg' }
]
```

## 6. Estadísticas (`stats`)

Los números deben ser **verificables antes de publicar**. El producto bloquea por política la publicación de cifras inventadas.

## 7. Servicios (`services`)

Cada servicio requiere: `id`, `category` (cosmetic/ortho/implants/general), `icon` (ruta SVG), `tag` (opcional), `title` {es,en}, `desc` {es,en}, `price` orientativo, `popular` (boolean).

## 8. SEO (`seo`) — NUEVO Enterprise

| Campo | Descripción |
|---|---|
| `seo.title` {es,en} | Título de la página (≤ 60 caracteres recomendado) |
| `seo.description` {es,en} | Meta descripción (120-160 caracteres recomendado) |
| `seo.canonicalUrl` | URL canónica del sitio (incluye barra final) |
| `seo.ogImage` | Imagen para redes sociales (1200×630) |
| `seo.keywords` | Lista de palabras clave orientativas |

## 9. Asistente FAQ local (`aiAssistant`) — Ultimate

| Campo | Descripción |
|---|---|
| `aiAssistant.enabled` | Activa/desactiva el widget |
| `aiAssistant.name` | Nombre visible del asistente (por defecto «Sofía») |
| `aiAssistant.transferNumber` | WhatsApp para transferir consultas complejas |
| `aiAssistant.guardrailsNotes` | Texto del pie con los límites médicos |

El asistente funciona localmente en el navegador y usa `siteData.js` para responder. No tiene URL de API ni requiere claves o servicios externos.

## 10. Módulos (`features`) — NUEVO Enterprise

Interruptores para activar o desactivar secciones sin tocar código: `crm`, `automations`, `aiAssistant`, `multiLocation`, `financingCalculator`, `beforeAfterGallery`, `googleReviews`, `faq`, `darkThemeToggle`, `languageSwitch`.

## 11. Integraciones (`integrations`) — NUEVO Enterprise

IDs de servicios externos: GA4 (`G-XXXXXXXXXX`), GTM, meta de verificación de Google Search Console, claves de API para Resend/Twilio/calendarios. **Las claves secretas van exclusivamente en las variables de entorno de Cloudflare, nunca en este archivo.**

## 12. Ajustes técnicos (`settings`)

| Campo | Descripción |
|---|---|
| `settings.theme` | luxury-studio · modern-family · cosmetic · premium-implants · orthodontic · boutique |
| `settings.defaultLang` | `es` o `en` |
| `settings.defaultTheme` | `light` o `dark` |
| `settings.heroUseVideo` | `true` reproduce `assets/images/hero-bg.mp4` en el hero |
| `settings.currency` | Símbolo para precios y calculadora |

---

## Inventario de placeholders en la plantilla limpia

Si partes del `siteData.js` de la plantilla (no de un ejemplo), estos son los 81 marcadores entre corchetes que debes sustituir: `[NOMBRE_CLINICA]`, `[NOMBRE_CORTO]`, `[CIUDAD]`, `[PAIS]`, `[TELEFONO]`, `[TELEFONO_FORMATO]`, `[EMAIL_CLINICA]`, `[DIRECCION_COMPLETA]`, `[WHATSAPP_NUMERO]`, `[ENLACE_GOOGLE_MAPS]`, `[ENLACE_GOOGLE_RESEÑAS]`, `[NOMBRE_DOCTOR]`, `[PRECIO_*]`, `[INSTAGRAM_URL]`, `[FACEBOOK_URL]`, `[TIKTOK_URL]`, etc. Ejecuta `pnpm run test:validator` para ver la lista exacta pendiente en tu configuración.

## Recomendaciones para fotos (`assets/images/`)

| Archivo | Uso | Tamaño recomendado |
|---|---|---|
| `hero-smile.jpg` | Sonrisa protagonista del hero | 1400×1120 |
| `doctor-portrait.jpg` | Retrato del especialista principal | 900×1125 |
| `clinic-interior.jpg` | Interior de la clínica (también en Schema.org) | 1600×1066 |
| `smile-before-1.jpg` / `smile-after-1.jpg` | Caso 1 antes/después | 1200×800 |
| `smile-before-2.jpg` / `smile-after-2.jpg` | Caso 2 antes/después | 1200×800 |
| `cosmetic-smile.jpg`, `veneers-result.jpg` | Casos resultado final | 1200×800 |

Todas las imágenes actuales están en JPG optimizado (65–315 KB cada una) sin imágenes embebidas en base64.

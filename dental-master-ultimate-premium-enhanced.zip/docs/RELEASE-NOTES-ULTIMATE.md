# Notas de versión — Dental Master Ultimate

## Rediseño visual

Se añadió `ultimate.css` como capa visual sobre el diseño existente. Incluye tipografía editorial, espaciado y color refinados, sombras suaves, interacción de botones y cards, glassmorphism en componentes apropiados y tratamiento de modo oscuro. El panel administrativo ahora presenta métricas, pipeline visual y componentes del CRM, citas, automatizaciones, filtros y tablas con una estética SaaS consistente y adaptable.

## Asistente FAQ local

`modules/ai-assistant.js` reemplaza la dependencia remota por coincidencia local de palabras clave en español e inglés. Atiende preguntas habituales sobre precios, horarios, ubicación, proceso de reserva, seguros y urgencias. Muestra un indicador de escritura durante un segundo y deriva preguntas desconocidas a la llamada o al formulario. No solicita claves ni hace llamadas remotas de chat. La ruta histórica de `functions/api/ai-chat.js` queda desactivada y no la invoca el widget.

## Backend y datos

Se conservan las Pages Functions, el esquema D1 y la lógica de leads y citas. El adaptador usa las rutas públicas de Cloudflare Pages: `/api/leads` y `/api/appointments`; las funciones de origen se mantienen en `functions/api/`. Cuando el binding `DB` está configurado, las funciones guardan en D1. Sin backend, el producto continúa en modo estático con almacenamiento local de demostración.

## Pruebas

Se añadieron pruebas unitarias del asistente y del widget, incluida la demora de un segundo, idioma español/inglés, derivación de preguntas desconocidas y ausencia de peticiones de chat. También se prueba que el adaptador solicita las rutas `/api/*` correctas para leads y citas. Ejecuta `pnpm test` con el servidor local activo para la suite completa.

## Antes de publicar

Comprueba la URL del sitio, binding D1, credenciales y datos reales de la clínica. Sustituye todos los testimonios, precios y resultados clínicos de demostración por datos verificados y autorizados. El chatbot ofrece información general y no sustituye la evaluación profesional.

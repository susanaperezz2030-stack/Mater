# DENTAL MASTER ENTERPRISE — Seguridad y Privacidad en Salud

## 1. Alcance y posición del producto

Dental Master Enterprise es un **sistema de captación de pacientes y atención comercial**, no un sistema de información sanitaria (HIS/EHR). Los datos que gestiona son **de marketing y contacto**: nombre, teléfono, email, tratamiento de interés, preferencias de fecha y hora. Esta distinción es deliberada y debe mantenerse:

- **No almacenes historias clínicas, diagnósticos formales, imágenes médicas diagnósticas ni datos médicos sensibles** dentro de este producto ni en su base de datos D1/KV.
- Los datos protegidos de salud (PHI bajo HIPAA; datos de salud bajo el art. 9 del RGPD) deben gestionarse en un sistema clínico independiente y conforme a la normativa aplicable en la jurisdicción de la clínica.

## 2. Declaración sobre HIPAA (Estados Unidos)

**El uso de este producto no confiere por sí solo la conformidad HIPAA.**

Si la clínica opera en Estados Unidos y desea conectar este producto con sistemas que procesen Protected Health Information, debe cumplir, entre otras, las siguientes condiciones ajenas a este software:

1. Evaluar si la información captada constituye PHI en su caso (en formularios de cita preliminar sin datos clínicos suele no serlo, pero cada clínica debe validarlo con su asesor legal).
2. Suscribir **Business Associate Agreements (BAA)** con cada proveedor que trate datos (Cloudflare ofrece BAA bajo planes empresariales; proveedores como Formspree/Resend/Twilio requieren sus propios acuerdos según el plan).
3. Aplicar medidas técnicas de la regla de seguridad HIPAA (cifrado en tránsito y en reposo — Cloudflare cifra ambos por defecto; control de acceso basado en roles; registro de accesos).
4. Procedimientos organizativos: política de privacidad, designación de responsable, formación del personal, proceso ante incidentes y derecho de acceso del paciente.

## 3. RGPD / GDPR (Unión Europea)

1. **Base jurídica**: la gestión de citas solicitadas por el paciente se ampara en la ejecución de la solicitud; las comunicaciones comerciales exigen **consentimiento expreso** (el formulario incluye casilla de consentimiento).
2. **Minimización**: se piden solo los datos estrictamente necesarios para la cita.
3. **Páginas legales reales**: `aviso-legal.html`, `politica-privacidad.html` y `politica-cookies.html` deben completarse con los datos fiscales reales de la clínica antes de publicar.
4. **Cookies**: Google Analytics 4 está bloqueado hasta la aceptación explícita en el banner de cookies.
5. **Derechos ARCO+**: el texto legal informa del derecho de acceso, rectificación, supresión y portabilidad con dirección de contacto.
6. **Encargados**: Formspree (servidores con Cláusulas Contractuales Tipo) y Cloudflare (procesamiento en el edge).

## 4. Modelo de seguridad técnica implementado

| Mecanismo | Implementación |
|---|---|
| Cifrado en tránsito | HTTPS obligatorio vía Cloudflare; HSTS con preload en `_headers` |
| Autenticación | Cookies de sesión HMAC firmadas, HttpOnly, Secure, SameSite=Strict y con expiración de 8 h; usuarios configurados con hash PBKDF2 |
| Protección contra clickjacking | `X-Frame-Options: SAMEORIGIN` |
| Content Security Policy | CSP en `_headers` que restringe scripts a los CDNs utilizados |
| Separación de secretos | Claves de integraciones opcionales de email/SMS solo en variables de entorno del servidor; el cliente jamás las recibe |
| Integridad de reservas | Validación de campos en servidor, RBAC para leer/editar y unicidad atómica por fecha+franja+sede (HTTP 409) |
| Autorización API | Middleware server-side: CRM/admin privado por rol; solo POST de captación de lead/cita público; se rechaza origen cruzado |
| Asistente seguro | Guardrails médicos en el FAQ local del cliente; no hay endpoint de IA ni proveedor remoto |
| Código de terceros | Todos los CDNs provienen de proveedores reconocidos (cloudflare, unpkg, jsdelivr, Google Fonts) cargados sobre HTTPS |

## 5. Limitaciones conocidas del modo demo

- En modo estático puro, las credenciales del panel admin viven en código cliente y la autenticación es solo un simulador funcional (útil para demos comerciales, no para producción con datos reales). **Para producción con datos reales de varias personas del equipo, activa el backend de Cloudflare.**
- Los datos del CRM en modo estático están en el navegador del usuario y no se sincronizan entre dispositivos.
- El módulo de citas en modo estático previene conflictos dentro del mismo navegador; la prevención multi-usuario real requiere el backend D1.
- Las rutas públicas POST de leads y citas aún necesitan límites de frecuencia, Turnstile/anti-spam y monitoreo contra abuso.
- El cierre invalida la cookie del navegador, pero un token firmado robado permanece válido hasta que expire (8 horas); no hay revocación central por usuario.
- La gestión de usuarios del panel es solo local (`localStorage`); no crea cuentas en D1 ni debe considerarse una fuente de identidad.
- El modo de autenticación demo del endpoint está desactivado por defecto. Solo se habilita con `DEMO_MODE=true`; no habilitarlo en producción. La falta de `USERS`/`SESSION_SECRET` válido falla con HTTP 503.
- Esta actualización no se ha probado con el binding D1 real ni se ha aplicado una migración a una base existente; solo se probó contra SQLite en memoria.

**Bloqueo de datos reales:** antes de producción configura secretos y binding en staging, revisa y aplica migraciones tras copia de seguridad, añade mitigación de abuso para formularios y verifica flujos con D1 real. La tabla de usuarios del panel todavía no crea ni persiste identidades.

## 6. Lista de control antes de publicar con datos reales

- [ ] `siteData.js` sin ningún marcador `[PLACEHOLDER]`
- [ ] Datos fiscales reales en las tres páginas legales
- [ ] Variables de entorno de Cloudflare configuradas con claves reales (no de prueba)
- [ ] Usuarios demo eliminados o reemplazados por cuentas con contraseñas robustas
- [x] Autorización y roles validados en el servidor para lecturas/cambios administrativos; altas públicas limitadas a POST
- [x] Sesiones firmadas, expirables; contraseñas de cuentas configuradas requieren hash PBKDF2
- [ ] Revocación central de sesiones, MFA y limitación de intentos de acceso
- [ ] Límites de frecuencia/anti-spam en las rutas públicas
- [ ] El formulario de usuarios persiste en backend seguro (no solo `localStorage`)
- [ ] Dominio propio con SSL activo
- [ ] `pnpm test` (suite completa) en verde
- [ ] Asesoría legal/cumplimiento completada según la jurisdicción

# Auditoría integral de experiencia y diseño — RHD Dental Studio

**Alcance:** síntesis de siete auditorías estructuradas sobre portada y página larga, reserva pública, CRM, administración de citas, experiencia móvil/cookies y sistema visual/accesibilidad.  
**Propósito:** ordenar riesgos y mejoras en una hoja de ruta coherente P0/P1/P2, evitando duplicidades y distinguiendo evidencia observada de recomendaciones.  
**Fecha del informe:** 11 de noviembre de 2026.

> **Conclusión ejecutiva.** La plantilla tiene una base visual boutique sólida y cubre el recorrido clínico de extremo a extremo, pero todavía presenta señales de demo, datos contradictorios y estados operativos que pueden inducir a error. La prioridad no es añadir más adornos: primero hay que asegurar identidad, contacto, ubicación, claims y reserva; después corregir operación, responsive y accesibilidad; por último consolidar temas y elevar el acabado visual. No debe publicarse como clínica real hasta resolver los P0.

## Cómo leer este informe

- **Observación/evidencia:** lo que las auditorías reportan haber visto en capturas, HTML, CSS, JavaScript o pruebas existentes. La evidencia de código es inspección estática salvo cuando se indica captura/prueba; no implica que se haya ejecutado un flujo de producción.
- **Recomendación:** acción propuesta, no un estado que ya exista.
- **Severidad:** P0 bloquea publicación o implica riesgo crítico de confianza/operación; P1 es una corrección prioritaria antes de considerar el producto terminado; P2 mejora consistencia, mantenibilidad y acabado.
- **Esfuerzo:** estimación cualitativa basada en las auditorías; depende de datos reales, backend, diseño y QA.

## Resumen de los siete frentes

1. **Portada de escritorio:** jerarquía editorial atractiva y composición de dos columnas, pero teléfono y claims no verificados, imagen demasiado centrada en boca, banner de cookies intrusivo y elementos flotantes que compiten.
2. **Página larga:** buena cobertura de dudas y módulos de conversión, pero datos de negocio contradictorios, mapa de otra ciudad, horarios desalineados, métricas/casos y financiación con respaldo no demostrado, y repetición de siete tarjetas inmediatamente después del hero.
3. **Reserva pública:** wizard útil, pero el éxito se representa como cita confirmada aunque el registro queda `pending`; referencia/QR no son una credencial validable y hay riesgos de validación, fallos y duplicados.
4. **Dashboard/CRM:** arquitectura de KPI, pipeline y gestión de leads; sin embargo, el gráfico puede comunicar magnitudes incorrectas, falta contexto temporal, los estados están parcialmente en inglés y el CRM es frágil en pantallas estrechas.
5. **Administración de citas:** datos disponibles y filtros básicos, pero tarjetas densas, acciones incompatibles, reprogramación mediante `prompt` y lista sin orden cronológico explícito.
6. **Móvil, navegación flotante y cookies:** existe barra móvil, consideración parcial de safe areas y consentimiento básico, pero hit-areas pequeñas, panel IA potencialmente tapado por teclado, modales sin aislamiento suficiente y falta una vía persistente para preferencias.
7. **Temas y accesibilidad visual:** seis temas y tokens ofrecen una buena base; la activación de modo oscuro no coincide con algunos selectores, hay overrides globales `!important`, y faltan pruebas de contraste, teclado, reflow y movimiento reducido transversal.

## Matriz consolidada de hallazgos y prioridades

| ID | Hallazgo consolidado | Severidad | Impacto principal | Esfuerzo | Evidencia concreta reportada |
|---|---|---:|---|---|---|
| H1 | Datos de identidad/contacto y canal de reserva en estado de demo o contradictorios | **P0** | Leads perdidos, desconfianza, información operativa falsa | Medio; bajo si se dispone de datos maestros | `siteData.js` declara teléfono `+1 (555) 123-4567`, correo de dominio de plantilla, licencia `TX-DENT-20418`, `YOUR_FORM_ID` y `demoMode:true`; el HTML muestra aviso de demo. Portada repite `15551234567` y `123 Congress Avenue`. |
| H2 | Ubicación, mapa y horarios no coinciden entre fuentes | **P0** | Pacientes enviados a otra ciudad o fuera de horario; incoherencia local/SEO | Bajo–medio | El contenido anuncia Austin/123 Congress Avenue, mientras `mapsFrame` usa Miami y coordenadas `-80.299498,25.782545`. JSON-LD indica L–V 09:00–20:00 y sábado 10:00–14:00; `siteData.js` indica L–V 08:00–17:00, sábado 09:00–13:00 y urgencias dominicales. |
| H3 | Prueba social, credenciales, resultados y claims comerciales no validados o contradictorios | **P0** para validar/retirar antes de publicar; saneamiento P1 después | Confianza, reputación y potencial exposición legal/comercial | Bajo–medio; depende de registros | Se informan 4.9/5 y +520 reseñas, 500 reseñas de 5 estrellas, 98% de pacientes satisfechos, 12.000 procedimientos, 8.200 sonrisas y 14+/15+ años en distintos módulos. “Reseñas verificadas” no muestra fuente/fecha. Se anuncian urgencias en el día, 0% y aprobación inmediata sin condiciones visibles. |
| H4 | La reserva muestra confirmación que no corresponde al estado real y no maneja robustamente fallos | **P1** | Citas mal entendidas, duplicados, solicitudes perdidas y carga de soporte | Medio–alto | `app.js` guarda estado `pending` (≈línea 890), mientras la pantalla etiqueta `CONFIRMADA` (≈750); referencia derivada de `Date.now()/Math.random()` y QR descrito como patrón no escaneable. Se guarda antes del `fetch` Formspree (≈880–928); error de red solo alerta. El botón puede quedar deshabilitado si falla DMEStorage fuera del `finally`. |
| H5 | Validación y accesibilidad del wizard/modal de reserva incompletas | **P1** | Fricción y exclusión; solicitudes inválidas/incompletas | Bajo–medio | Se valida nombre/teléfono/email manualmente, pero no de forma consistente fecha no pasada, consentimiento, servicio ni formato de teléfono. `bookingModal` carece de `aria-modal` y gestión completa de foco; reset al abrir no está asegurado. |
| H6 | Operación interna puede inducir errores y desperdiciar tiempo | **P1** | Citas atendidas tarde, transiciones erróneas y datos sensibles expuestos | Medio | `appointments.js` no ordena explícitamente y una cita 2030 aparece antes que fechas de 2026; fila `Realizada` muestra Confirmar/Reprogramar; permite marcar futura como realizada. Las tarjetas concatenan teléfono/email/notas en texto de 9–10 px. Reprogramación solicita texto libre por `prompt`. |
| H7 | Panel/CRM carece de contexto y visualización fiable para decidir | **P1** | Lectura errónea del embudo y tareas prioritarias poco visibles | Medio | Captura reporta barras casi iguales pese a conteos diferentes; cero leads deja barras vacías sin explicación. Conversión 10% no tiene periodo ni denominador, aunque se calcula sobre todo el histórico. Listas sin encabezados claros y estados `pending`, `new`, `appointment_requested`; tabla CRM de nueve columnas. |
| H8 | Diseño responsive y overlays pueden ocultar controles o competir | **P1** | Abandono móvil y toques fallidos | Bajo–medio | A ≤520 px hay controles de 32–36 px; el asistente enfoca input y puede abrir teclado, pero no usa `visualViewport`; panel puede quedar tapado. Banner cookies y rail comparten zona; modal reserva no bloquea claramente fondo/scroll durante todo el flujo. No se pudo obtener captura real móvil. |
| H9 | Consentimiento de cookies no ofrece gestión persistente/granular | **P1** por solapamiento visible; **P2** para granularidad, según jurisdicción | Obstrucción de interfaz y control insuficiente de preferencias | Bajo–medio | Banner aparece tras 1,5 s y puede solaparse con rail inferior; no se encontró enlace persistente para reabrir preferencias. La elección es `all`/`necessary`; analytics carga solo con `all`. |
| H10 | Sistema de temas y modo oscuro se contradicen, con colores hard-coded | **P1** | Una parte de la UI ignora el tema y oscuro puede quedar incompleto | Medio | Temas usan selectores `:root[data-theme=...].dark`; app/tests aplican `body.dark`. `ultimate.css` fuerza blanco con `!important` (≈199–210), incluso sobre superficies temáticas. |
| H11 | Accesibilidad visual, teclado y movimiento carecen de validación transversal | **P1** para contraste/controles operables; mejoras avanzadas P2 | Legibilidad y acceso por teclado/lector de pantalla no demostrados | Medio | No hay ratios WCAG en pruebas; textos muted de 9–14 px y tarjetas de temas son `div` accionables solo por click. Suite comprueba cambio de `body.dark` y unicidad de acentos, no tokens/contraste. `prefers-reduced-motion` es parcial. |
| H12 | Composición premium tiene ruido y repetición que debilitan jerarquía | **P2** | Menos calma visual y menor claridad de CTA | Bajo–medio | Hero: titular ocupa cuatro líneas en captura 1400×900; cookie banner cubre chips; badge/tarjeta/launcher/SCROLL se superponen; lockup aparece como placa blanca. Siete tarjetas índice siguen inmediatamente al hero y repiten secciones largas. |
| H13 | Casos visuales/credenciales deben tener trazabilidad clínica | **P1** | Expectativas de resultado engañosas y riesgo reputacional | Medio–alto | `siteData.js` reutiliza `smile-before-1.jpg`/`smile-after-1.jpg` en dos casos; otros tienen solo after. Bloque se titula “Casos reales” sin evidencia visible de consentimiento, estandarización fotográfica o nota de variabilidad. Credencial “AACD Accredited” y antigüedad requieren verificación. |
| H14 | El acabado del tema/admin necesita consistencia de marca y pruebas | **P2** | Percepción de producto genérico y mantenimiento frágil | Medio | Panel muestra “Dental Master Enterprise” frente a RHD Dental Studio; tipos y escalas divergen, badges en inglés, tests no abarcan estados/temas/zoom y el nombre de clínica no es claramente configurable. |

### Relación entre prioridades

Los P0 se agrupan en una única tarea de **verdad del negocio**: no es eficiente pulir reseñas, mapa y formularios independientemente si no hay un dato maestro verificado. Para claims no documentados, la recomendación conservadora es **retirar u ocultar**, no inventar reemplazos cuantificados. H4–H5 deben tratarse como un único rediseño funcional del ciclo de reserva. H6–H7 forman el frente de operación interna. H8–H11 son una capa común de robustez y accesibilidad; evitar arreglos CSS aislados que vuelvan a ser pisados por overrides.

## Evaluación honesta de la promesa «USD 100.000.000.000»

La promesa mencionada equivale literalmente a **USD 100.000.000.000 (cien mil millones de dólares)**. En la información de auditoría suministrada **no hay contexto, contrato, oferta, tasación, ingreso, modelo financiero ni evidencia independiente** que permita determinar qué significa esa cifra. Por sí sola, **no equivale a precio, valoración, ingresos, ahorro, retorno ni valor garantizado**. Tampoco puede inferirse que la plantilla dental o el sitio valgan esa cantidad.

Si esa frase va a aparecer en el producto o material comercial, debe identificarse qué representa, quién la respalda, bajo qué supuestos, periodo y condiciones; si no se puede documentar, no presentarla como una promesa factual o garantía. Esta auditoría es de experiencia/diseño y calidad de implementación descrita; no es una valoración financiera ni due diligence.

## Hoja de ruta única

### Fase 0 — Bloqueo de publicación: verdad, confianza y contacto (P0)

**Objetivo:** que todo lo visible coincida con la clínica real y que el paciente pueda contactar/reservar por canales funcionales.

1. Crear un **registro maestro único** aprobado por el responsable de clínica: nombre legal/comercial, teléfono y `tel:`, correo, dirección, coordenadas, URL de mapa, horarios, licencia/credenciales, profesionales, canales de urgencia y Formspree/backend de producción. Usarlo para portada, página larga, footer, JSON-LD y panel.
2. Hasta recibir validación documental, retirar teléfono 555, dirección Austin/Miami, licencia de ejemplo, modo demo, reviews, años, métricas, urgencias, parking y claims de financiación. No sustituirlos por números “neutros” que parezcan hechos.
3. Probar el flujo real de contacto en escritorio y móvil: enlace telefónico, correo, envío, recepción, notificación, estado de error y destino de confirmación. Eliminar `YOUR_FORM_ID` y el aviso demo solo cuando el canal real esté probado.
4. Hacer revisión de consistencia de dirección, pin, horario visible/JSON-LD, nombre y enlaces de “Cómo llegar”. Confirmar la ubicación desde el dispositivo y no solo por texto.
5. Validar fuente y fecha de reseñas, denominador/periodo de métricas, credenciales, términos de financiación y disponibilidad de urgencias. Si no hay soporte, suprimir cada afirmación. Para fotos, verificar licencia/consentimiento y autorización de uso clínico.

**Salida de fase:** checklist de datos firmado; enlaces/contactos comprobados; cero placeholders; cero afirmaciones cuantificadas no sustentadas.

### Fase 1 — Reserva fiable y operación segura (P1)

**Objetivo:** que una solicitud no se confunda con una cita confirmada y sea recuperable ante fallos.

1. Cambiar la pantalla final a **“Solicitud recibida · pendiente de confirmación”** mientras el estado del backend sea `pending`; explicar que la franja es preferida, no hora asignada. Quitar etiqueta de confirmada y QR decorativo como credencial. Si se requiere pase, emitir referencia persistida, única y consultable.
2. Elegir una fuente de verdad para reservas. Persistir y notificar transaccionalmente o mantener explícito `notification pending` con reintento e idempotencia. En errores, decir si la solicitud sí quedó guardada, conservar datos y evitar duplicados.
3. Validar controles activos antes de cada paso/envío: fecha ≥ hoy, servicio, consentimiento, campos y teléfono normalizado con código de país. Mensajes inline y recuperables, no solo `alert`. Envolver todo guardado/envío en `try/catch/finally` para restaurar el CTA.
4. Reiniciar estado al iniciar una nueva solicitud; conservar datos solo dentro del mismo intento. Completar semántica del diálogo (`aria-modal`, foco inicial, tab trap, Escape si permitido, foco de retorno, fondo inerte, anuncio de errores y estado live).
5. Definir máquina explícita de estados de cita y matriz de transiciones válidas; ocultar acciones incompatibles, confirmar cancelación/reprogramación y evitar marcar realizada una cita futura sin confirmación/regla explícita.
6. Ordenar agenda por fecha/hora ascendente; separar próximas, historial y canceladas. Reemplazar prompts por panel de reprogramación con fecha/franja validada y conflicto inline. Hacer fecha/estado buscables, añadir contador y limpiar filtros.
7. Rediseñar tarjetas internas para jerarquía legible: fecha/hora y paciente primero; estado textual; tratamiento/profesional secundarios; contacto y notas ocultos o expandibles según rol. No mostrar notas clínicas por defecto.

### Fase 2 — Móvil, contenidos de confianza y sistema visual (P1)

1. Elevar hit-area de header/rail a **mínimo 44×44 CSS px**; los iconos pueden seguir siendo visualmente pequeños. Comprobar estados de foco y separación táctil.
2. Ajustar panel IA y modales con `visualViewport`, `100dvh`, safe areas y teclado móvil; retirar mínimos de altura que impidan encoger. Bloquear scroll del fondo durante el wizard y aislar el contenido.
3. Evitar solapamiento de banner de cookies y rail; ofrecer un acceso persistente a preferencias. Definir consentimiento por categorías si procede para la jurisdicción; mantener bloqueadas integraciones no esenciales hasta consentimiento adecuado.
4. Consolidar las reglas móviles duplicadas de `body padding-bottom`, altura y posición del rail. Aplicar safe area superior al overlay y verificar el último CTA/footer.
5. Alinear selector de modo oscuro con el elemento donde se definen tokens. Retirar `!important` global que blanquea tarjetas; migrar fondos, texto, líneas y sombras a tokens semánticos.
6. Medir contraste WCAG AA para texto normal (4.5:1), texto grande y componentes/indicadores (3:1) en todas las combinaciones tema claro/oscuro; corregir tokens `--muted` y estados.
7. Hacer opciones de tema controles nativos o radiogroup operable por teclado con estado anunciado. Añadir `prefers-reduced-motion` global y validar zoom/reflow.
8. Reescribir prueba social y sección de casos únicamente con material autenticado, casos emparejados comparables, consentimiento y nota “los resultados varían”. Condicionar financiación a elegibilidad y términos; la calculadora debe llamarse estimación no vinculante.

### Fase 3 — Pulido premium y claridad editorial (P2)

1. Replantear el hero con imagen propia/licenciada de rostro más completo o paciente en contexto clínico; confirmar consentimiento. Evitar dos fotos compitiendo: fondo neutral o interior menos oscurecido y una imagen protagonista coherente.
2. En desktop 1400×900, revisar tamaño/ancho de titular para apuntar a tres líneas sin forzar copy; liberar altura para CTA y evidencia real. Mantener propuesta concreta y alternativa de contacto.
3. Reducir banner de cookies a formato compacto que no cubra CTA ni señales de confianza; no sacrificar claridad de las acciones.
4. Dejar como máximo un elemento flotante en primer viewport, y solo si su prueba social está verificada. Reducir o posponer launcher y cue “SCROLL”.
5. Integrar el wordmark en paleta marfil/oro del header; corregir subtítulo diminuto/tracking excesivo. Convertir las siete tarjetas repetidas post-hero en índice breve de anclas o trasladarlas.
6. Mejorar dashboard: mostrar periodo/alcance y numerador/denominador (“1 de 10”), cabeceras, estados en español, acciones “Ver todas” y estado vacío explicativo. Corregir barras para respetar escala real y adaptar CRM a móvil mediante tarjetas o tabla navegable.
7. Configurar nombre/logo de clínica en el shell del admin; producto secundario. Normalizar tipografía, tamaños y densidad entre marketing y administración.
8. Ampliar pruebas visuales con matrices de tema, modo oscuro, formularios, foco/hover, viewport, zoom y capturas comparables.

## Criterios visuales y funcionales de aceptación

La aceptación es verificable; “se ve premium” no es un criterio suficiente.

### Confianza y contenido

- En toda la superficie pública se muestra **el mismo** teléfono, correo, dirección, pin y horario que aprobó la clínica; teléfono visible coincide con `href`.
- No aparece “demo”, `YOUR_FORM_ID`, teléfono 555 ni dato de plantilla. Cada cifra/credencial/caso tiene fuente y fecha o se ha eliminado.
- Mapa, dirección y JSON-LD apuntan a la misma ubicación/horario. No hay promesa de cita confirmada mientras backend mantenga `pending`.
- Claims de urgencias/financiación explican disponibilidad/elegibilidad y enlazan términos; ningún cálculo parece una oferta aprobada.

### Portada y página larga

- En captura a **1400×900**, CTA principal y una señal de confianza verificable quedan visibles sin que cookie banner, tarjetas, launcher o navegación las tapen.
- La fotografía permite reconocer contexto humano y no simula un resultado clínico sin prueba/consentimiento. El fondo no reduce legibilidad ni compite con el retrato.
- El lockup se integra con cabecera; no parece una placa blanca discordante. El índice bajo hero no duplica siete módulos completos.
- Titular legible en tres líneas objetivo en escritorio común, sin sacrificar escala accesible ni copy esencial.

### Reserva y administración

- El estado final coincide exactamente con el persistido y distingue solicitud de cita confirmada. Referencias son persistentes/consultables o no se presentan como identificadores.
- Fecha pasada, consentimiento ausente, servicio sin selección y teléfono inutilizable generan error inline y foco apropiado; el CTA siempre se recupera tras fallo.
- Falla de red no produce duplicado al reintentar; el usuario entiende si el registro se guardó.
- Agenda próxima está ordenada ascendentemente; ninguna cita realizada ofrece acciones incompatibles. Cambios dan feedback anunciado.
- Contactos/notas no quedan expuestos en tipografía minúscula o en tarjetas sin necesidad operativa.

### Responsive y accesibilidad

- QA manual y automatizado a 320, 375×812, 390 px, escritorio 1400×900 y paisaje; incluir teclado móvil, safe areas, banner de cookies, panel IA, wizard y final de página.
- Cada control táctil tiene hit-area ≥44×44 CSS px; no se pierden campos ni CTAs al abrir teclado.
- Modales aíslan fondo, conservan foco y scroll interno visible; foco vuelve al disparador.
- Contraste AA medido en textos/estados y en los seis temas, claro y oscuro. Pruebas de teclado y lector de pantalla cubren navegación, temas y modales.
- A 200% de zoom y 320 CSS px no hay pérdida de contenido/funcionalidad; movimiento no esencial se reduce con `prefers-reduced-motion`.

### Temas y panel

- En cada uno de los seis temas, fondos, superficies, texto, controles y estados cambian según tokens en claro/oscuro; no quedan tarjetas blancas inesperadas.
- Gráficos muestran escala, conteo y periodo; estados vacíos explican el resultado y permiten limpiar filtros. CRM puede utilizarse sin desplazamiento horizontal destructivo en móvil.
- Capturas de regresión cubren portada, wizard, panel, CRM y citas para cada estado/tema representativo; pruebas comprueban tokens, no solo que cambie una clase.

## Fortalezas que conviene conservar

- Propuesta de valor, tratamientos y CTA principal se comprenden rápido; existe alternativa telefónica.
- Estructura de dos columnas y lenguaje editorial aportan una base boutique; la paleta crema/oro y tarjetas se reutilizan.
- La página contempla objeciones típicas (casos, perfil, financiación, FAQ, ubicación), y CTAs aparecen en puntos relevantes.
- Hay wizard de reserva de tres pasos, fecha mínima inicial, prevención de doble reserva según almacenamiento, autocompletado, consentimiento y soporte de movimiento reducido parcial.
- CRM contempla búsqueda, filtros, asignación, seguimiento y exportación; el código escapa valores dinámicos. El panel ya tiene foco visible y base de tokens para seis identidades.
- El banner de cookies ofrece rechazar cookies no esenciales y analytics solo carga con aceptación `all`, según la lógica inspeccionada.

## Límites de esta evaluación

- Los hallazgos derivan de las siete auditorías recibidas. El comportamiento responsive móvil no se validó mediante captura real: se informa que no se encontró Puppeteer/Chrome ejecutable; se infiere de CSS/markup.
- La auditoría de reserva fue inspección estática; no se ejecutó envío real ni se verificó producción de DMEStorage/Formspree.
- La apariencia de barras puede depender de cascada CSS no inspeccionada completamente; confirmar estilos computados antes de cambiar lógica.
- No se verificaron licencias, consentimientos, reseñas, credenciales, términos financieros, disponibilidad ni datos maestros de una clínica real. En caso de ausencia, la recomendación es no publicar el claim.
- No se realizó auditoría jurídica, financiera, clínica o de seguridad completa. La cifra de USD 100.000.000.000 carece de evidencia y contexto en los datos entregados y no es una valoración.

## Decisión recomendada

**No publicar la versión actual como experiencia operativa de una clínica real hasta cerrar Fase 0.** Tras ello, resolver Fase 1 antes de captar reservas; ejecutar Fase 2 con pruebas de móvil y accesibilidad; y cerrar Fase 3 como refinamiento premium. El principio rector es simple: **verdad verificable primero, operación fiable después, acabado visual al final**.


## Estado de aplicación — 11 de noviembre de 2026

Se aplicó un primer paquete de mejoras independiente de los datos reales de la clínica:

- El modo oscuro añade la clase al elemento raíz que consume los tokens de los seis temas; las tarjetas públicas dejaron de forzar superficies blancas y ahora siguen los tokens del tema. El marco blanco sutil del mapa utiliza también la superficie/borde del tema.
- Las citas administrativas se ordenan por fecha y franja; la acción “Realizada” solo aparece para citas confirmadas cuya fecha ya llegó. Se mejoró el tamaño de lectura de contacto/notas y el tamaño táctil de acciones.
- El asistente móvil puede reducir su altura con el viewport dinámico; controles de la barra inferior alcanzan el área táctil mínima y el aviso de cookies se separa de la barra y considera el safe area.
- El modal de reserva declara semántica de diálogo y cada intento nuevo restablece datos y selecciones; se validan servicio, fecha no pasada y franja. El resultado ahora se titula como solicitud pendiente, aclara que fecha/hora son preferencias y ya no muestra una referencia aleatoria, un QR no escaneable ni una acción para añadir al calendario como si la cita estuviera confirmada.
- Las páginas de secciones se regeneraron desde la portada para evitar que conservaran un marcado antiguo. La suite completa pasó: **37/37 pruebas E2E** y las suites unitarias/de rutas, incluida D1 simulado (**34 pruebas de Functions**).

**Pendiente antes de publicar como clínica real:** no se recibieron nombre legal, dirección/coordenadas, teléfono, correo, horarios, credenciales, consentimiento/licencia de fotos ni fuentes de reseñas y claims. Por eso no se reemplazaron los datos ficticios de Austin/RHD, el teléfono 555 ni las cifras comerciales por valores inventados. Tampoco se verificó envío/recepción real del formulario ni entrega de correo. El paquete sigue siendo una plantilla en modo demo; los P0 de identidad/confianza siguen bloqueando publicación clínica hasta cargar y validar un registro maestro real.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const configPath = path.join(projectRoot, 'wrangler.toml');
const config = fs.readFileSync(configPath, 'utf8');
const errors = [];

if (!/^name\s*=\s*["']rhd-dental-group["']\s*$/m.test(config)) {
  errors.push('El nombre del proyecto debe coincidir con rhd-dental-group.');
}
if (!/^pages_build_output_dir\s*=\s*["']\.\/dist["']\s*$/m.test(config)) {
  errors.push('pages_build_output_dir debe apuntar a ./dist.');
}

const d1Marker = config.search(/^\[\[d1_databases\]\]\s*$/m);
if (d1Marker < 0) {
  errors.push('No aparece una configuración [[d1_databases]] con el binding de producción.');
} else {
  const tail = config.slice(d1Marker);
  const lines = tail.split(/\r?\n/);
  let end = 1;
  while (end < lines.length && !/^\s*\[/.test(lines[end])) end += 1;
  const d1Block = lines.slice(0, end).join('\n');
  if (!/^binding\s*=\s*["']DB["']\s*$/m.test(d1Block)) {
    errors.push('El binding de D1 debe llamarse DB, como lo esperan las Pages Functions.');
  }
  if (!/^database_name\s*=\s*["'][^"']+["']\s*$/m.test(d1Block)) {
    errors.push('Falta el nombre real de la base D1 en la configuración sincronizada.');
  }
  const databaseId = d1Block.match(/^database_id\s*=\s*["']([^"']+)["']\s*$/m)?.[1] ?? '';
  if (databaseId.length < 16 || /placeholder|database.?id|<|>/i.test(databaseId)) {
    errors.push('Falta el database_id real descargado desde el proyecto Pages de Cloudflare.');
  }
}

if (errors.length) {
  console.error('Despliegue detenido para no cambiar la configuración de D1 existente.');
  for (const error of errors) console.error(`- ${error}`);
  console.error('\nPrimero sincroniza la configuración real del proyecto:');
  console.error('  pnpm exec wrangler login');
  console.error('  pnpm exec wrangler pages download config rhd-dental-group');
  console.error('Conserva el bloque D1 con binding = "DB" y database_id real, y deja pages_build_output_dir = "./dist".');
  process.exit(1);
}

console.log('Cloudflare config OK: Pages output and existing D1 binding DB are present.');

import { randomBytes, pbkdf2 } from 'node:crypto';
import { promisify } from 'node:util';

const derive = promisify(pbkdf2);
const iterations = 310000;
let password = '';
process.stdout.write('Contraseña nueva (no se mostrará): ');
if (process.stdin.isTTY && typeof process.stdin.setRawMode === 'function') {
  process.stdin.setRawMode(true);
  process.stdin.resume();
  password = await new Promise((resolve) => {
    let value = '';
    const onData = (chunk) => {
      for (const char of chunk.toString()) {
        if (char === '\r' || char === '\n') {
          process.stdin.off('data', onData);
          process.stdin.setRawMode(false);
          process.stdout.write('\n');
          resolve(value);
          return;
        }
        if (char === '\u0003') {
          process.stdin.off('data', onData);
          process.stdin.setRawMode(false);
          process.stdout.write('\nCancelado.\n');
          process.exitCode = 130;
          resolve('');
          return;
        }
        if (char === '\u007f' || char === '\b') value = value.slice(0, -1);
        else value += char;
      }
    };
    process.stdin.on('data', onData);
  });
} else {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  password = Buffer.concat(chunks).toString('utf8').replace(/[\r\n]+$/, '');
  process.stdout.write('\n');
}
if (process.exitCode === 130) process.exit(130);
if (password.length < 14) throw new Error('Usa al menos 14 caracteres.');
const salt = randomBytes(16);
const hash = await derive(password, salt, iterations, 32, 'sha256');
console.log(`pbkdf2$${iterations}$${salt.toString('base64url')}$${hash.toString('base64url')}`);

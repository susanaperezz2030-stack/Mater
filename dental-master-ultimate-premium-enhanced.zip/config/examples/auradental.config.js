/**
 * Configuración de ejemplo completa — Aura Dental Studio
 * Todos los campos completos, sin corchetes de ejemplo.
 * Duplica este archivo como config/clinic.js para un nuevo cliente.
 */
const CLINIC_CONFIG = {
  schemaVersion: '1.0',

  clinic: {
    name: 'Aura Dental Studio',
    nameShort: 'Aura Dental',
    namePrefix: 'Clínica Dental Boutique',
    tagline: {
      es: 'La odontología de alta precisión que tu sonrisa merece.',
      en: 'High-precision dentistry your smile deserves.',
    },
    subtagline: {
      es: 'Diseño digital de sonrisas, carillas ultrafinas, implantes y ortodoncia invisible con tecnología 3D en Madrid.',
      en: 'Digital smile design, ultra-thin veneers, implants and clear aligners with 3D technology in Madrid.',
    },
    description: {
      es: 'Aura Dental Studio es una clínica boutique fundada en 2016 en Madrid, donde la tecnología 3D se une a la experiencia de un equipo médico especializado.',
      en: 'Aura Dental Studio is a boutique clinic founded in 2016 in Madrid, where 3D technology meets a specialist medical team.',
    },
    yearFounded: '2016',
    license: 'Lic. Sanitaria CS-10482',
    city: 'Madrid',
    country: 'España',
  },

  locations: [
    {
      id: 'goya',
      name: 'Aura Dental — Goya',
      phone: '+34919123456',
      phoneFormatted: '+34 919 123 456',
      email: 'goya@auradental.com',
      address: 'Calle de Goya 45, 1.º izq., 28001 Madrid',
      city: 'Madrid',
      mapsUrl: 'https://maps.app.goo.gl/placeholder',
      mapsEmbedUrl: '',
      hours: [
        { days: { es: 'Lunes a Viernes', en: 'Monday to Friday' }, time: '09:00 – 20:30' },
        { days: { es: 'Sábados', en: 'Saturdays' }, time: '10:00 – 14:00' },
      ],
    },
    {
      id: 'chamartin',
      name: 'Aura Dental — Chamartín',
      phone: '+34919654321',
      phoneFormatted: '+34 919 654 321',
      email: 'chamartin@auradental.com',
      address: 'Paseo de la Habana 82, 28036 Madrid',
      city: 'Madrid',
      mapsUrl: 'https://maps.app.goo.gl/placeholder',
      mapsEmbedUrl: '',
      hours: [
        { days: { es: 'Lunes a Viernes', en: 'Monday to Friday' }, time: '09:30 – 19:30' },
      ],
    },
  ],

  contact: {
    phone: '+34919123456',
    phoneFormatted: '+34 919 123 456',
    email: 'contacto@auradental.com',
    address: 'Calle de Goya 45, 1.º izq.',
    addressLine2: '28001 Madrid, España',
    mapsUrl: 'https://maps.app.goo.gl/placeholder',
    mapsEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.88390629729!2d-3.6826500846200216!3d40.4225339793649!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd42289f6b9fbb09%3A0x6b8d4f40d7c2a7e7!2sCalle%20de%20Goya%2C%2028001%20Madrid!5e0!3m2!1ses!2ses',
  },

  whatsapp: {
    number: '34670000000',
    messages: {
      general: {
        es: 'Hola Aura Dental, me gustaría agendar una primera cita de valoración.',
        en: 'Hello Aura Dental, I would like to book a first consultation.',
      },
      emergency: {
        es: 'Hola Aura Dental, tengo una urgencia dental y necesito atención hoy.',
        en: 'Hello Aura Dental, I have a dental emergency and need care today.',
      },
    },
  },

  team: [
    {
      id: 'sofia-morales',
      name: 'Dra. Sofía Morales',
      role: {
        es: 'Directora Médica & Especialista en Estética Dental',
        en: 'Medical Director & Cosmetic Dentistry Specialist',
      },
      credentials: 'DDS, PhD · Fellow AACD · 14 años de experiencia',
      specialty: 'Estética dental, carillas y diseño de sonrisa',
      bio: {
        es: 'Formada en Madrid y Nueva York, combina odontología mínimamente invasiva con escaneo 3D para resultados naturales.',
        en: 'Trained in Madrid and New York, she combines minimally invasive dentistry with 3D scanning for natural results.',
      },
      photo: 'assets/images/doctor-portrait.jpg',
      locations: ['goya', 'chamartin'],
    },
    {
      id: 'javier-ruiz',
      name: 'Dr. Javier Ruiz',
      role: {
        es: 'Especialista en Implantología & Rehabilitación Oral',
        en: 'Implantology & Oral Rehabilitation Specialist',
      },
      credentials: 'DDS · Máster en Implantología · 11 años de experiencia',
      specialty: 'Implantes y All-on-4',
      bio: {
        es: 'Cirugía guiada por ordenador y rehabilitación con cerámica de circonio de alta precisión.',
        en: 'Computer-guided surgery and rehabilitation with high-precision zirconia ceramics.',
      },
      photo: 'assets/images/doctor-alt.jpg',
      locations: ['goya'],
    },
    {
      id: 'ana-vega',
      name: 'Dra. Ana Vega',
      role: {
        es: 'Especialista en Ortodoncia Invisible',
        en: 'Clear Orthodontics Specialist',
      },
      credentials: 'DDS · Invisalign Platinum Provider',
      specialty: 'Alineadores invisibles y ortodoncia infantil',
      bio: {
        es: 'Más de 900 casos de ortodoncia invisible tratados con planificación digital 3D.',
        en: 'Over 900 clear-aligner cases treated with 3D digital planning.',
      },
      photo: 'assets/images/clinic-reception.jpg',
      locations: ['chamartin'],
    },
  ],

  services: [
    {
      id: 'whitening',
      icon: 'assets/icons/icon-whitening.svg',
      tag: { es: 'Más popular', en: 'Most popular' },
      title: { es: 'Blanqueamiento Dental LED', en: 'LED Teeth Whitening' },
      desc: {
        es: 'Aclara hasta 8 tonos en una sesión con tecnología no invasiva que respeta el esmalte.',
        en: 'Lightens up to 8 shades in a single session with non-invasive enamel-safe tech.',
      },
      price: 'Desde 199 €',
      duration: '45–60 min',
      popular: true,
      category: 'cosmetic',
    },
    {
      id: 'veneers',
      icon: 'assets/icons/icon-veneers.svg',
      tag: { es: 'Diseño de sonrisa', en: 'Smile design' },
      title: { es: 'Carillas de Porcelana', en: 'Porcelain Veneers' },
      desc: {
        es: 'Láminas ultrafinas que corrigen forma, color y posición con resultados hipernaturales.',
        en: 'Ultra-thin shells correcting shape, color and alignment with hyper-natural results.',
      },
      price: 'Desde 490 €/diente',
      duration: '2–3 sesiones',
      popular: true,
      category: 'cosmetic',
    },
    {
      id: 'invisalign',
      icon: 'assets/icons/icon-invisalign.svg',
      tag: { es: 'Ortodoncia invisible', en: 'Clear aligners' },
      title: { es: 'Alineadores Invisibles', en: 'Clear Aligners' },
      desc: {
        es: 'Corrige tu sonrisa de forma cómoda y discreta con planificación 3D y seguimiento continuo.',
        en: 'Discreet and comfortable smile correction with 3D planning and ongoing monitoring.',
      },
      price: 'Desde 1.890 €',
      duration: '6–18 meses',
      popular: true,
      category: 'ortho',
    },
    {
      id: 'implants',
      icon: 'assets/icons/icon-implants.svg',
      tag: { es: 'Rehabilitación', en: 'Rehabilitation' },
      title: { es: 'Implantes Dentales & All-on-4', en: 'Dental Implants & All-on-4' },
      desc: {
        es: 'Recupera piezas perdidas con titanio biocompatible y corona personalizada.',
        en: 'Restore missing teeth with biocompatible titanium and a customized crown.',
      },
      price: 'Desde 890 €',
      duration: '1–2 horas',
      popular: false,
      category: 'implant',
    },
    {
      id: 'general',
      icon: 'assets/icons/icon-general.svg',
      tag: { es: 'Prevención', en: 'Prevention' },
      title: { es: 'Limpieza y Revisión Preventiva', en: 'Cleaning & Preventive Checkup' },
      desc: {
        es: 'Profilaxis ultrasónica, radiografía digital y plan de cuidado personalizado.',
        en: 'Ultrasonic prophylaxis, digital X-rays and a personalized care plan.',
      },
      price: 'Desde 79 €',
      duration: '40 min',
      popular: false,
      category: 'general',
    },
    {
      id: 'rootcanal',
      icon: 'assets/icons/icon-rootcanal.svg',
      tag: { es: 'Sin dolor', en: 'Pain-free' },
      title: { es: 'Endodoncia Microscópica', en: 'Microscopic Root Canal' },
      desc: {
        es: 'Salva tu diente natural con tecnología microscópica y anestesia computerizada.',
        en: 'Save your natural tooth with microscopy and computer-guided anesthesia.',
      },
      price: 'Desde 350 €',
      duration: '60–90 min',
      popular: false,
      category: 'general',
    },
    {
      id: 'pediatric',
      icon: 'assets/icons/icon-pediatric.svg',
      tag: { es: 'Odontopediatría', en: 'Pediatric' },
      title: { es: 'Odontología Infantil y Familiar', en: 'Pediatric & Family Dentistry' },
      desc: {
        es: 'Entorno lúdico sin miedo con selladores, flúor y ortodoncia preventiva.',
        en: 'Fear-free environment with sealants, fluoride and preventive orthodontics.',
      },
      price: 'Desde 95 €',
      duration: '30–45 min',
      popular: false,
      category: 'general',
    },
    {
      id: 'emergency',
      icon: 'assets/icons/icon-emergency.svg',
      tag: { es: 'Atención prioritaria', en: 'Priority care' },
      title: { es: 'Urgencias Dentales en el Día', en: 'Same-Day Dental Emergencies' },
      desc: {
        es: 'Dolor agudo o rotura de piezas con atención prioritaria el mismo día.',
        en: 'Acute pain or tooth damage with priority same-day care.',
      },
      price: 'Desde 110 €',
      duration: 'Inmediata',
      popular: false,
      category: 'general',
    },
  ],

  financing: {
    badge: '0% INTERÉS',
    badgeEN: '0% INTEREST',
    headline: {
      es: 'Financia tu tratamiento sin intereses',
      en: 'Finance your treatment interest-free',
    },
    subheadline: {
      es: 'Hasta 24 cuotas sin comisiones de apertura ni estudio. Aprobación en minutos.',
      en: 'Up to 24 installments with no opening fees. Approval in minutes.',
    },
    bullets: {
      es: ['Aprobación en clínica en 5 minutos', 'Hasta 24 cuotas al 0% TAE', 'Compatible con tus seguros', 'Sin costes ocultos'],
      en: ['Approval at the clinic in 5 minutes', 'Up to 24 installments at 0% APR', 'Compatible with your insurance', 'No hidden fees'],
    },
    partners: ['Cetelem', 'Sequra', 'CareCredit'],
    calculator: { defaultAmount: 2400, minAmount: 300, maxAmount: 12000, months: [6, 12, 18, 24], defaultMonths: 12 },
  },

  stats: [
    { number: 98, suffix: '%', label: { es: 'Pacientes satisfechos', en: 'Satisfied patients' } },
    { number: 10, suffix: '+', label: { es: 'Años de experiencia', en: 'Years of experience' } },
    { number: 12000, suffix: '+', label: { es: 'Procedimientos realizados', en: 'Procedures performed' } },
    { number: 500, suffix: '+', label: { es: 'Reseñas 5 estrellas', en: '5-star reviews' } },
  ],

  gallery: {
    featuredCase: {
      before: 'assets/images/smile-before-1.jpg',
      after: 'assets/images/smile-after-1.jpg',
      title: { es: 'Diseño integral de sonrisa con 10 carillas de porcelana', en: 'Full smile design with 10 porcelain veneers' },
      treatment: { es: 'Carillas de porcelana + blanqueamiento', en: 'Porcelain veneers + whitening' },
      sessions: { es: '2 sesiones · 3 semanas', en: '2 sessions · 3 weeks' },
    },
    cases: [
      {
        before: 'assets/images/smile-before-2.jpg',
        after: 'assets/images/smile-after-2.jpg',
        title: { es: 'Ortodoncia invisible + recontorneado estético', en: 'Clear aligners + aesthetic recontouring' },
        treatment: { es: 'Alineadores · 11 meses', en: 'Aligners · 11 months' },
        patient: 'Caso #2407',
      },
      {
        before: 'assets/images/smile-before-1.jpg',
        after: 'assets/images/smile-after-1.jpg',
        title: { es: 'Rehabilitación estética completa superior', en: 'Complete upper aesthetic rehabilitation' },
        treatment: { es: 'Implantes + coronas de circonio', en: 'Implants + zirconia crowns' },
        patient: 'Caso #1893',
      },
      {
        after: 'assets/images/cosmetic-smile.jpg',
        title: { es: 'Resultado final tras 6 carillas mínimamente invasivas', en: 'Final result after 6 minimally invasive veneers' },
        treatment: { es: 'Carillas ultrafinas sin tallado', en: 'Ultra-thin no-prep veneers' },
        patient: 'Caso #3011',
      },
      {
        after: 'assets/images/veneers-result.jpg',
        title: { es: 'Detalle de adaptación marginal y textura natural', en: 'Marginal fit detail and natural texture' },
        treatment: { es: 'Macrofotografía clínica', en: 'Clinical macrophotography' },
        patient: 'Caso #D-2407',
      },
    ],
  },

  testimonials: [
    {
      author: 'Carolina V.',
      city: 'Madrid',
      rating: 5,
      date: { es: 'Hace 2 semanas', en: '2 weeks ago' },
      treatment: { es: 'Diseño de sonrisa', en: 'Smile design' },
      text: {
        es: 'La mejor decisión que he tomado. El resultado es tan natural que nadie nota las carillas, pero todos me dicen que estoy radiante.',
        en: 'Best decision I have made. The result is so natural nobody can tell they are veneers, yet everyone says I am glowing.',
      },
      avatar: 'CV',
    },
    {
      author: 'Martín S.',
      city: 'Madrid',
      rating: 5,
      date: { es: 'Hace 1 mes', en: '1 month ago' },
      treatment: { es: 'Alineadores invisibles', en: 'Clear aligners' },
      text: {
        es: 'Tenía pánico al dentista y me trataron con una delicadeza increíble. En 10 meses mi sonrisa quedó perfecta.',
        en: 'I was terrified of dentists and they treated me with incredible gentleness. My smile was perfect in 10 months.',
      },
      avatar: 'MS',
    },
    {
      author: 'Elena R.',
      city: 'Madrid',
      rating: 5,
      date: { es: 'Hace 3 semanas', en: '3 weeks ago' },
      treatment: { es: 'Blanqueamiento LED', en: 'LED whitening' },
      text: {
        es: 'El blanqueamiento fue rápido y sin sensibilidad. Instalaciones que parecen un spa y equipo puntual.',
        en: 'The whitening was fast with zero sensitivity. Spa-like facilities and a punctual team.',
      },
      avatar: 'ER',
    },
  ],

  google: {
    rating: '4.9',
    totalReviews: '520',
    businessUrl: 'https://g.page/placeholder',
    badgeText: { es: 'Basado en 520+ reseñas verificadas en Google', en: 'Based on 520+ verified Google reviews' },
  },

  faqs: [
    {
      q: { es: '¿La primera cita de valoración es gratuita?', en: 'Is the first consultation free?' },
      a: { es: 'Sí. Incluye exploración clínica completa, radiografía digital y propuesta de tratamiento sin compromiso.', en: 'Yes. It includes a full clinical examination, digital X-rays and a treatment proposal with no obligation.' },
    },
    {
      q: { es: '¿Los tratamientos duelen? Tengo miedo al dentista.', en: 'Do the treatments hurt? I am afraid of the dentist.' },
      a: { es: 'Usamos anestesia computerizada casi indolora, técnicas mínimamente invasivas y atención relajada; también disponemos de sedación consciente.', en: 'We use virtually painless computer-assisted anesthesia, minimally invasive techniques and relaxed care; conscious sedation is also available.' },
    },
    {
      q: { es: '¿Cuánto dura un tratamiento de diseño de sonrisa con carillas?', en: 'How long does a smile design with veneers take?' },
      a: { es: 'Se completa habitualmente en 2–3 sesiones a lo largo de 3–4 semanas con previsualización digital 3D.', en: 'Usually 2–3 sessions over 3–4 weeks with a 3D digital preview.' },
    },
    {
      q: { es: '¿Trabajan con seguros dentales?', en: 'Do you accept dental insurance?' },
      a: { es: 'Colaboramos con las principales aseguradoras y gestionamos reembolsos para pólizas de libre elección.', en: 'We work with major insurers and process out-of-network reimbursements.' },
    },
    {
      q: { es: '¿Cómo funciona la financiación?', en: 'How does financing work?' },
      a: { es: 'Aprobación en la propia clínica en minutos, de 6 a 24 cuotas sin comisiones. Solo se necesita documento de identidad y cuenta bancaria.', en: 'Approval at the clinic within minutes, 6–24 installments with no fees. Only an ID and bank account are required.' },
    },
    {
      q: { es: '¿Ofrecen citas en el mismo día para urgencias?', en: 'Do you offer same-day emergency appointments?' },
      a: { es: 'Sí, reservamos franjas diarias exclusivas para urgencias con cita prioritaria.', en: 'Yes, daily slots are reserved exclusively for priority emergency visits.' },
    },
  ],

  hours: [
    { days: { es: 'Lunes a Viernes', en: 'Monday to Friday' }, time: '09:00 – 20:30' },
    { days: { es: 'Sábados', en: 'Saturdays' }, time: '10:00 – 14:00' },
    { days: { es: 'Domingos', en: 'Sundays' }, time: { es: 'Solo urgencias con cita', en: 'Emergencies by appointment' } },
  ],

  social: {
    instagram: 'https://instagram.com/placeholder',
    facebook: 'https://facebook.com/placeholder',
    tiktok: 'https://tiktok.com/@placeholder',
    googleBusiness: 'https://g.page/placeholder',
  },

  seo: {
    title: {
      es: 'Aura Dental Studio — Diseño de Sonrisa e Implantes en Madrid',
      en: 'Aura Dental Studio — Smile Design & Implants in Madrid',
    },
    description: {
      es: 'Aura Dental Studio, clínica boutique en Madrid. Carillas, Invisalign, implantes y blanqueamiento con tecnología 3D. Primera valoración gratuita.',
      en: 'Aura Dental Studio, boutique dental clinic in Madrid. Veneers, Invisalign, implants and whitening with 3D technology. Free first consultation.',
    },
    siteUrl: 'https://www.auradental.com',
    canonicalUrl: 'https://www.auradental.com/',
    ogImage: 'assets/images/hero-smile.jpg',
    keywords: ['clínica dental madrid', 'diseño de sonrisa', 'carillas', 'invisalign', 'implantes dentales'],
  },

  aiAssistant: {
    enabled: true,
    name: 'Sofía',
    transferNumber: '+34919123456',
    guardrailsNotes: 'El asistente nunca diagnostica ni sustituye al odontólogo.',
  },

  form: {
    formspreeId: '',
    demoMode: true,
  },

  exitPopup: {
    enabled: true,
    delaySeconds: 0,
    mobileDelaySeconds: 45,
    title: { es: '¿Te vas sin tu valoración gratuita?', en: 'Leaving without your free assessment?' },
    subtitle: {
      es: 'Deja tu nombre y teléfono y te reservamos una primera cita de diagnóstico con radiografía digital 100% sin coste.',
      en: 'Leave your details and we will hold a first diagnosis visit with digital X-ray 100% free of charge.',
    },
    cta: { es: 'Reclamar mi cita gratuita', en: 'Claim my free appointment' },
  },

  settings: {
    defaultLang: 'es',
    defaultTheme: 'light',
    theme: 'luxury-studio',
    heroUseVideo: false,
    currency: '€',
  },

  features: {
    crm: true,
    automations: true,
    aiAssistant: true,
    multiLocation: true,
    financingCalculator: true,
    beforeAfterGallery: true,
    googleReviews: true,
    faq: true,
    darkThemeToggle: true,
    languageSwitch: true,
  },

  integrations: {
    googleAnalyticsId: '',
    googleTagManagerId: '',
    googleSearchConsoleMeta: '',
    googleMapsApiKey: '',
    formspreeId: '',
    resendApiKey: '',
    twilio: { sid: '', auth: '', from: '' },
    googleCalendar: { enabled: false },
    outlookCalendar: { enabled: false },
  },
};

if (typeof module !== 'undefined' && module.exports) module.exports = CLINIC_CONFIG;

/**
 * Dental Master Enterprise — Configuration Validator
 * Validates a clinic configuration object against the schema and returns
 * { ok, errors: [], warnings: [], placeholders: [] }.
 * Usable in browser and Node.js.
 */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const WA_RE = /^[0-9]{8,15}$/;
const PHONE_CLEAN = (p) => (p || '').replace(/[^0-9]/g, '');

export function validate(cfg) {
  const errors = [];
  const warnings = [];
  const placeholders = [];

  if (!cfg || typeof cfg !== 'object') {
    return { ok: false, errors: ['Configuration must be a non-null object'], warnings, placeholders };
  }

  // Required top-level blocks
  for (const b of ['clinic', 'contact', 'services']) {
    if (!cfg[b]) errors.push(`Missing block: "${b}"`);
  }

  // Clinic
  const c = cfg.clinic || {};
  if (!c.name) errors.push('clinic.name is required');
  if (!c.city) errors.push('clinic.city is required');
  if (!c.country) errors.push('clinic.country is required');
  if (!c.nameShort) warnings.push('clinic.nameShort is recommended for logo display');
  if (!c.tagline) warnings.push('clinic.tagline is recommended for the hero section');

  // Contact
  const ct = cfg.contact || {};
  if (!ct.phone) errors.push('contact.phone is required (digits only with country code)');
  else if (PHONE_CLEAN(ct.phone).length < 8) errors.push('contact.phone looks too short (<8 digits)');
  if (!ct.email) errors.push('contact.email is required');
  else if (!EMAIL_RE.test(ct.email)) errors.push(`contact.email "${ct.email}" is not a valid email`);
  if (!ct.address) errors.push('contact.address is required');
  if (!ct.mapsUrl) warnings.push('contact.mapsUrl recommended for the "Get directions" button');

  // WhatsApp
  const wa = cfg.whatsapp || {};
  if (wa.number) {
    if (!WA_RE.test(String(wa.number).replace(/[^0-9]/g, ''))) errors.push('whatsapp.number must be digits only (8-15 digits, country code included)');
  } else {
    warnings.push('whatsapp.number is empty — WhatsApp buttons will not work');
  }

  // Services
  const svc = cfg.services;
  if (!Array.isArray(svc) || svc.length === 0) errors.push('services must be a non-empty array');
  else {
    svc.forEach((s, i) => {
      if (!s.id) errors.push(`services[${i}].id is required`);
      if (!s.title) errors.push(`services[${i}].title is required`);
    });
  }

  // Team (optional array, doctor is legacy)
  if (cfg.team && !Array.isArray(cfg.team)) errors.push('team must be an array');
  if (cfg.locations && !Array.isArray(cfg.locations)) errors.push('locations must be an array');

  // SEO
  const seo = cfg.seo;
  if (seo) {
    if (seo.description && seo.description.es && seo.description.es.length < 50) warnings.push('seo.description.es shorter than 50 chars — weak for search');
  } else warnings.push('seo block missing — template uses defaults');

  // Form
  const f = cfg.form || {};
  if (f.formspreeId === 'YOUR_FORM_ID' && f.demoMode !== true) warnings.push('form.formspreeId is the placeholder "YOUR_FORM_ID"; appointment submissions will fail in production');

  // Placeholder scan
  function scan(v, path) {
    if (v == null) return;
    if (typeof v === 'string') {
      const ms = v.match(/\[[A-Z0-9_]+\]/g);
      if (ms) ms.forEach((m) => placeholders.push({ path, placeholder: m }));
    } else if (typeof v === 'object') {
      for (const k of Object.keys(v)) scan(v[k], path ? `${path}.${k}` : k);
    }
  }
  scan(cfg, '');

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    placeholders,
    summary: `${errors.length} error(s), ${warnings.length} warning(s), ${placeholders.length} placeholder(s) remaining`,
  };
}

const Validator = { validate, EMAIL_RE, WA_RE };
export default Validator;
export { EMAIL_RE, WA_RE };
if (typeof window !== 'undefined') window.DentalValidator = Validator;
